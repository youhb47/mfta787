<template>
    <div class="heyisnone">
      <div class="row m-0">
        <!-- b header -->
        <Header
          :BooleanTimer="false"
          :BooleanNumQuiz="true"
          :BooleanTagSave="true"
        />
        <!-- e header -->
  
        <div class="col-12 p-0 position-relative">
          <!-- b loader -->
          <Loader v-if="$root.loader" />
          <!-- e loader -->
  
          <!-- b quiz -->
          <Single />
          <!-- e quiz -->
        </div>
  
        <!-- b footer -->
        <Footer HerePage="quiz" :BooleanNext="true" :BooleanAfter="true" />
        <!-- e footer -->
      </div>      
    </div>
  </template>
    
    <script>
    import jQuery from 'jquery'
  import Header from "./Header";
  import Single from "./Single";
  import Footer from "./Footer";
  import Loader from "../aps/Loader";
  
  export default {
    name: "EndQuiz",
    components: {
      Header,
      Single,
      Footer,
      Loader,
    },
    data() {
      return {
        number_page: this.$root.quiz_number
      };
    },
    methods: {
      async run() {
        await this.$root.appSave()
        if (this.$root.quiz_revision == 1) {
          this.date = this.$root.thatdatea
        } else if (this.$root.quiz_revision == 2) {
          this.date = this.$root.thatdateb
        } else if (this.$root.quiz_revision == 3) {
          this.date = this.$root.thatdatec
        } else if (this.$root.quiz_revision == 4) {
          this.date = this.$root.thatdated
        }
        this.floader();
        this.$root.updateSave()
      },
      floader() {
        setInterval(() => {
          this.$root.loader = false;
        }, 500);
      },
        dragElement(event) {
            var elmnt = document.getElementById(event)
            var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
            if (document.getElementById(elmnt.id + "header")) {
                // if present, the header is where you move the DIV from:
                document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
            } else {
                // otherwise, move the DIV from anywhere inside the DIV:
                elmnt.onmousedown = dragMouseDown;
            }

            function dragMouseDown(e) {
                e = e || window.event;
                e.preventDefault();
                // get the mouse cursor position at startup:
                pos3 = e.clientX;
                pos4 = e.clientY;
                document.onmouseup = closeDragElement;
                // call a function whenever the cursor moves:
                document.onmousemove = elementDrag;
            }

            function elementDrag(e) {
                e = e || window.event;
                e.preventDefault();
                // calculate the new cursor position:
                pos1 = pos3 - e.clientX;
                pos2 = pos4 - e.clientY;
                pos3 = e.clientX;
                pos4 = e.clientY;
                // set the element's new position:
                elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
                elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
            }

            function closeDragElement() {
                // stop moving when mouse button is released:
                document.onmouseup = null;
                document.onmousemove = null;
            }
            },
        openModal(event) {
            jQuery(event).attr('class', 'modal fade show');
            jQuery(event).attr('style', 'display: block; padding-left: 0px;');
        },
        closeModal(event) {
            jQuery(event).attr('class', 'modal fade');
            jQuery(event).attr('style', '');
        },
        poplow () {
          this.$root.popsendtime = false
          this.$root.updateSave()
          closeModal('#statictime')
        }
    },
    mounted() {
      this.run();
    },
    watch: {
      '$root.quiz_number': "run",
    },
  };
  </script>


// WEBPACK FOOTER //
// src/components/end/Quiz.vue