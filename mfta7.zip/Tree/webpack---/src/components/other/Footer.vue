<template>
<div class="p-0">
<div class="
        row
        footer
        w-100
        m-0
        w-100
        py-1
        px-3
        quiz_footer
        justify-content-between
        align-items-center
        bg-DarkBlueOldColor
        justify-content-center
        position-fixed
    ">
    <div class="py-0 col-4 d-flex justify-content-start">
        <button @click="openendmodal" :disabled="$root.loader" 
        class="rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white"
        data-bs-toggle="modal" data-bs-target="#staticBackdrop">
            <h6 class="cursor_pointer my-0">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                إنهاء المراجعة
            </h6>
        </button>
    </div>
    <div class="py-0 d-flex justify-content-end col-8">
        <button @click="allrevision" :disabled="$root.loader" class="rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link">
            <h6 class="cursor_pointer my-0">
                <i class="fa-solid fa-bars"></i>
                مراجعة الكل
            </h6>
        </button>
        <button @click="nonerevision" :disabled="$root.loader" class="rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link">
            <h6 class="cursor_pointer my-0">
                <!-- <i class="fa-solid fa-xmark"></i> -->
                <i class="fa-regular fa-circle-xmark"></i>
                مراجعة الغير مكتمل
            </h6>
        </button>
        <button @click="tagsrevision" :disabled="$root.loader" class="rounded-0 border-end border-2 btn btn-link py-2 text-decoration-none text-white">
            <h6 class="cursor_pointer my-0">
                <i class="fa-solid fa-flag"></i>
                مراجعة المميز بعلامة
            </h6>
        </button>
    </div>

    </div>
    
    
<div class="modal fade" @mousedown="dragElement('staticBackdrop')" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" id="staticBackdropheader">
        <div class="modal-content border-0 rounded-0">
            <div class="modal-header py-1">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">
                    إنهاء المراجعة
                </h1>
                <button type="button" class="btn fs-4 p-0 text-white" @click="closeModal('#staticBackdrop')">
                    <i class="fa-regular fa-rectangle-xmark"></i>
                </button>
            </div>
            <div class="modal-body row">
                <div class="col-1">
                    <img src="@/assets/icon/warning.png" >
                </div>
                <div class="col-11">
                    <p>
                        الرجاء التأكيد على رغبتك في إنهاء هذه
                        المراجعة . إذا نقرت فوق "نعم" ، لن تكون
                        هناك إمكانية للعودة إلى هذه المراجعة
                        واإلجابة على األسئلة )عدد االسئلة-
                        {{ xspx() }}
                        .التي لم تكتمل
                    </p>
                </div>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" @click="closeModal('#staticBackdrop')" class="btn text-white rounded-0 border-1 border-white">لا</button>
                <button type="button" @click="closeModal('#staticBackdrop'), openModal('#staticTowdrop')" 
                class="btn text-white rounded-0 border-1 border-white">نعم</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" @mousedown="dragElement('staticTowdrop')" id="staticTowdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" id="staticTowdropheader">
        <div class="modal-content border-0 rounded-0">
            <div class="modal-header py-1">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">
                    إنهاء المراجعة
                </h1>
                <button type="button" class="btn fs-4 p-0 text-white" @click="closeModal('#staticTowdrop')">
                    <i class="fa-regular fa-rectangle-xmark"></i>
                </button>
            </div>
            <div class="modal-body row">
                <div class="col-1">
                    <img src="@/assets/icon/warning.png" >
                </div>
                <div class="col-11">
                    <p>
                        هل أنت متأكد أنك تريد إنهاء هذه
                        المراجعة؟
                    </p>
                </div>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" @click="closeModal('#staticTowdrop')" 
                class="btn text-white rounded-0 border-1 border-white">لا</button>
                <button type="button" @click="endnextlist" 
                class="btn text-white rounded-0 border-1 border-white">نعم</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" @mousedown="dragElement('statictagsquiz')"  id="statictagsquiz" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" id="statictagsquizheader">
        <div class="modal-content border-0 rounded-0">
        <div class="modal-header py-1">
            <h1 class="modal-title fs-5" id="staticBackdropLabel">
                الأسئلة المميزة بعلامة
            </h1>
            <button type="button" class="btn fs-4 p-0 text-white" @click="closeModal('#statictagsquiz')">
                <i class="fa-regular fa-rectangle-xmark"></i>
            </button>
        </div>
        <div class="modal-body row">
            <div class="col-1">
                <img src="@/assets/icon/information.png" >
            </div>
            <div class="col-11">
                <p>
                    ليس هناك إي اسئلة مميزة بعلامة لمراجعتها
                </p>
            </div>
        </div>
        <div class="modal-footer justify-content-center">
            <button type="button" @click="closeModal('#statictagsquiz')" class="btn text-white rounded-0 border-1 border-white">
            حسناُ
            </button>
        </div>
        </div>
    </div>
</div>

<div class="modal fade" @mousedown="dragElement('staticnonequiz')" id="staticnonequiz" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" id="staticnonequizheader">
        <div class="modal-content border-0 rounded-0">
        <div class="modal-header py-1">
            <h1 class="modal-title fs-5" id="staticBackdropLabel">
                الأسئلة الغير مكتملة
            </h1>
            <button type="button" class="btn fs-4 p-0 text-white" @click="closeModal('#staticnonequiz')">
                <i class="fa-regular fa-rectangle-xmark"></i>
            </button>
        </div>
        <div class="modal-body row">
            <div class="col-1">
                <img src="@/assets/icon/information.png" >
            </div>
            <div class="col-11">
                <p>
                    ليس هناك إي اسئلة غير مكتملة لمراجعتها
                </p>
            </div>
        </div>
        <div class="modal-footer justify-content-center">
            <button type="button" @click="closeModal('#staticnonequiz')" class="btn text-white rounded-0 border-1 border-white">
            حسناُ
            </button>
        </div>
        </div>
    </div>
</div>

</div>
</template>

<script>
import jQuery from 'jquery'

export default {
    name: "Header",
    props: {
        next: Boolean,
    },
    data() {
        return {
            totalnone : 0,
            popture: true
        };
    },
    methods: {
        run() {
            this.$root.totalnone = this.xspx()
            this.totalnone = this.xspx()
        },
        dragElement(event) {
            var elmnt = document.getElementById(event)
            var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
            if (document.getElementById(elmnt.id + "header")) {
                // if present, the header is where you move the DIV from:
                document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
            } else {
                // otherwise, move the DIV from anywhere inside the DIV:
                elmnt.onmousedown = dragMouseDown;
            }

            function dragMouseDown(e) {
                e = e || window.event;
                e.preventDefault();
                // get the mouse cursor position at startup:
                pos3 = e.clientX;
                pos4 = e.clientY;
                document.onmouseup = closeDragElement;
                // call a function whenever the cursor moves:
                document.onmousemove = elementDrag;
            }

            function elementDrag(e) {
                e = e || window.event;
                e.preventDefault();
                // calculate the new cursor position:
                pos1 = pos3 - e.clientX;
                pos2 = pos4 - e.clientY;
                pos3 = e.clientX;
                pos4 = e.clientY;
                // set the element's new position:
                elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
                elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
            }

            function closeDragElement() {
                // stop moving when mouse button is released:
                document.onmouseup = null;
                document.onmousemove = null;
            }
            },
            // الاسئلة الغير مكتملة
            xspx() {
                var arv;
                var arr = [];
                let rev = this.$root.quiz_revision
                let qiz = this.$root.quiz_total
                let tol = this.$root.quiz_total
                for (let key = ((qiz * rev) - qiz); key < (tol * rev); key++) {
                    if (this.vmg(key, rev)) {
                        arv = {id: key}
                        arr.push(arv);
                    }
                }
                if      (rev == 1) {this.$root.quiz_none.a = arr}
                else if (rev == 2) {this.$root.quiz_none.b = arr}
                else if (rev == 3) {this.$root.quiz_none.c = arr}
                else if (rev == 4) {this.$root.quiz_none.d = arr}
                return arr.length
            },
        // التأكد إذا كان السؤال غير مكتمل او لا
        vmg (value, number) {
            let arr;
            let rev = number
            if (rev == 1) {
                arr = this.$root.quiz_joab.a
            } else if (rev == 2) {
                arr = this.$root.quiz_joab.b
            } else if (rev == 3) {
                arr = this.$root.quiz_joab.c
            } else if (rev == 4) {
                arr = this.$root.quiz_joab.d
            }
            for (let key = 0; key < arr.length; key++) {
                if (Number(arr[key].id) == Number(value)) {
                    return false
                }
            }
            return true
        },
        openModal(event) {
            this.totalnonecheck()
            jQuery(event).attr('class', 'modal fade show');
            jQuery(event).attr('style', 'display: block; padding-left: 0px;');
        },
        closeModal(event) {
            jQuery(event).attr('class', 'modal fade');
            jQuery(event).attr('style', '');
        },
        openendmodal () {
            if (this.xspx() == 0) {
                this.openModal('#staticTowdrop')
            }
            else {
                this.openModal('#staticBackdrop')
            }
        },
        endnextlist() {
            this.closeModal()
            let qr = this.$root.quiz_revision
            this.$root.quiz_faek = 'separation'
            this.$root.quiz_number = 0
            this.$root.timer = this.$root.loadtimer
            if (qr == 1) {
                this.$root.quiz_revision = 2
                this.$root.quiz_viwe[0] = 1
                this.$root.quiz_total = this.$root.total[this.$root.quiz_revision-1]
                this.$root.updateSave()
                this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
            } else if (qr == 2) {
                this.$root.quiz_revision = 3
                this.$root.quiz_viwe[2] = 1
                this.$root.quiz_total = this.$root.total[this.$root.quiz_revision-1]
                this.$root.updateSave()
                this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
            } else if (qr == 3) {
                this.$root.quiz_revision = 4
                this.$root.quiz_viwe[3] = 1
                this.$root.quiz_total = this.$root.total[this.$root.quiz_revision-1]
                this.$root.updateSave()
                this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
            } else if (qr == 4) {
                this.$root.quiz_faek = "end"
                this.$root.quiz_revision = 5
                this.$root.quiz_total = this.$root.total[0]
                this.$root.updateSave()
                // this.$router.push('/end').catch(err => {})
                this.$router.push({ name: 'End', path: '/end' })
            }
        },
        allrevision() {
            this.$root.quiz_faek = 'revision_quiz'
            this.$root.revision = 0
            this.$root.quiz_number = 1
            this.$root.faek_total = this.$root.total[this.$root.quiz_revision-1]
            this.$root.updateSave()
            this.$router.push({ name: 'Revision Quiz', params: { id: this.$root.app_rand } })
        },
        tagsrevision() {
            var arr = [];
            let rev = this.$root.quiz_revision
            this.$root.quiz_faek = 'revision_quiz'
            if      (rev == 1) {arr = this.$root.quiz_tags.a}
            else if (rev == 2) {arr = this.$root.quiz_tags.b}
            else if (rev == 3) {arr = this.$root.quiz_tags.c}
            else if (rev == 4) {arr = this.$root.quiz_tags.d}

            this.$root.revision = 2
            this.$root.quiz_number = 1
            this.$root.faek_total = arr.length
            this.$root.updateSave()
            if (arr.length == 0) this.openModal('#statictagsquiz')
            else this.$router.push({ name: 'Revision Quiz', params: { id: this.$root.app_rand } })
            
        },
        nonerevision() {
            var arr = [];
            let rev = this.$root.quiz_revision
            this.$root.quiz_faek = 'revision_quiz'
            if      (rev == 1) {arr = this.$root.quiz_none.a}
            else if (rev == 2) {arr = this.$root.quiz_none.b}
            else if (rev == 3) {arr = this.$root.quiz_none.c}
            else if (rev == 4) {arr = this.$root.quiz_none.d}

            this.$root.revision = 1
            this.$root.quiz_number = 1
            this.$root.faek_total = arr.length
            this.$root.updateSave()
            if (arr.length == 0) this.openModal('#staticnonequiz')
            else this.$router.push({ name: 'Revision Quiz', params: { id: this.$root.app_rand } })
        },
        totalnonecheck() {
            this.totalnone = this.xspx()
        }
    },
    mounted() {
        this.run()
    },
    watch: {
        'this.$root.totalnone' : 'run',
        '$root.quiz_none': 'run'
    }
};
</script>



// WEBPACK FOOTER //
// src/components/other/Footer.vue