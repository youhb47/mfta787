<template>
    <div class="m-0 p-0">
        <DragCol dir="ltr" style="width: 100%; height: max-content">
            <template #left>
                <div class="sp_style pt-3 px-3 fontsizequiz">
                    <h4 class="quiz_description_1 text-danger fontsizequiz">
                        استيعاب المقروء
                    </h4>
                    <h5 class="quiz_description_2 text-danger fontsizequiz">
                        السؤال التالي يتعلق بالنص المرفق , بعد السؤال هناك أربع اختيارات ,
                        واحد منها صحيح المطلوب , هو قراءة النص بعناية , ثم اختيار الإجابة
                        الصحيحة
                    </h5>
                    <h5 class="quiz_description_2 fontsizequiz">
                        {{ quiz.questions[number_quiz].paragraph }}
                    </h5>
                </div>
            </template>
            <template #right>
                <div class="sp_style pt-3 px-3 fontsizequiz">
                    <div class="sp_in_sp">
                        <h4 class="quiz_description_1 mb-3">
                            <p :inner-html.prop="quiz.questions[number_quiz].name"></p>
                        </h4>
                        <form ref="anyName">
                            <div v-for="(value, index) in quiz.questions[number_quiz].options" :key="index" 
                            class="form-check form-group mt-1 me-4 mb-3">
                                <input class="form-check-input float-end ms-2" type="radio" :disabled="true"
                                name="exampleRadios" :id="'exampleRadios' + number_quiz + 'q' + index" 
                                :value="'option' + number_quiz + 'q' + index" :checked="joab[index]"/>
                                <label class="form-check-label" :for="'exampleRadios' + number_quiz + 'q' + index">
                                    {{ value.name }}
                                    <div class="float-start" v-if="check_quiz(index) != null" :inner-html.prop="check_quiz(index)"></div>
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
            </template>
        </DragCol>
    </div>
    </template>
    
    <script>
    import {
        DragCol,
        DragRow,
        ResizeCol,
        ResizeRow,
        Resize
    } from "vue-resizer";
    
    export default {
        name: "Single",
        components: {
            DragCol,
            DragRow,
            ResizeCol,
            ResizeRow,
            Resize
        },
        data() {
            return {
                page  : this.$root.quiz_number,
                quiz  : this.$root.quizs,
                joab  : [false, false, false, false],
                number_quiz : 0
            };
        },
        methods: { 
            async run() {
                await this.$root.appSave()
                let rev    = this.$root.revision
                this.page  = (this.$root.quiz_number - 1)
                this.quiz  = this.$root.quizs
                let qev = this.$root.rev_faek
                let tol = this.$root.quiz_total
                this.checkedis()
                if (rev == 1) {
                    this.quizs_none()
                } else if (rev == 2) {
                    this.quizs_tags()
                } else {
                    if (qev != 1) {
                        this.number_quiz  = ((this.$root.quiz_number - 1) + (tol * (qev - 1)))
                        this.$root.faek_num  = ((this.$root.quiz_number - 1) + (tol * (qev - 1)))
                    } else {
                        this.number_quiz  = (this.$root.quiz_number - 1)
                        this.$root.faek_num  = (this.$root.quiz_number - 1)
                    }
                }
                this.$root.updateSave()
            },
            // معرفة رقم السؤال الحقيقي
            rnp(i) {
                let rev = this.$root.rev_faek
                let tol = this.$root.total[rev-1]
                if (rev != 1) {
                    return (i + (tol * rev-1))
                } else {
                    return i
                }
            },
            // هل الأجابة صحيحة ؟
            check_quiz(joab) {
                let tbu = this.number_quiz
                let qiz = this.$root.quizs 
                
                if (qiz.questions[tbu].options[joab].is_true) {
                    return '<i class="fa-solid fa-check" style="float: right;color:green"></i>'
                }
            },
            quizs_tags() {
                let arr;
                let np = this.page;
                let rev = this.$root.rev_faek
                if      (rev == 1) {arr = this.$root.quiz_tags.a}
                else if (rev == 2) {arr = this.$root.quiz_tags.b}
                else if (rev == 3) {arr = this.$root.quiz_tags.c}
                else if (rev == 4) {arr = this.$root.quiz_tags.d}
                this.number_quiz = arr[np].id
                this.$root.faek_num = arr[np].id
                // this.$root.updateSave()
            },
            quizs_none() {
                let arr;
                let np = this.page;
                let rev = this.$root.rev_faek
                if      (rev == 1) {arr = this.$root.quiz_none.a}
                else if (rev == 2) {arr = this.$root.quiz_none.b}
                else if (rev == 3) {arr = this.$root.quiz_none.c}
                else if (rev == 4) {arr = this.$root.quiz_none.d}
                this.number_quiz = arr[np].id
                this.$root.faek_num = arr[np].id
                // this.$root.updateSave()
            },
            async checkedis() {
                this.joab = await [false, false, false, false];
                let int   = this.number_quiz
                let rev = this.$root.rev_faek;
                let arr;
                if (rev == 1) {
                    arr  = this.$root.quiz_joab.a;
                } else if (rev == 2) {
                    arr  = this.$root.quiz_joab.b;
                } else if (rev == 3) {
                    arr  = this.$root.quiz_joab.c;
                } else if (rev == 4) {
                    arr  = this.$root.quiz_joab.d;
                }
                let Qjb   = this.joab;
                for (let key = 0; key < arr.length; key++) {
                    if(arr[key].id == int) {
                        Qjb[arr[key].joab] = true
                    }
                }
                this.joab = Qjb
            }
        },
        mounted() {
            this.run()
        },
        watch: {
            '$root.quiz_number': 'run'
        }
    };
    </script>
    


// WEBPACK FOOTER //
// src/components/end/Single.vue