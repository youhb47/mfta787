<template>
  <div class="heyisnone">
    <Header :BooleanTimer="false" :BooleanNumQuiz="false" :BooleanTagSave="false" />
    <Loader v-if="$root.loader"/>
    <div class="col-12 p-0 position-relative bodybody">
        <div class="col-12 p-0 text-center pt-3">
            <!--  -->
            <img src="../assets/icon/pearson.png" width="300" >
              <h3>
                مرحبا بك في اختبارات أكاديمية الحوت على الحاسب اآللي
              </h3>
              <p>
                سيتم بدء اإلختبار عند ضغط زر التالي في أسفل الشاشة
              </p>
              <p>
                إضغط زر التالي للمتابعة
              </p>
        </div>
    </div>

    <Footer HerePage="start" :BooleanNext="true" :BooleanAfter="false"/>
  </div>
</template>

<script>
import Header from "./aps/Header";
import Footer from "./aps/Footer";
import Loader from "./aps/Loader";

export default {
  name: "Start",
  components: {
    Header,
    Footer,
    Loader
  }
};
</script>


// WEBPACK FOOTER //
// src/components/Start.vue