// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from "vue";
import App from "./App";
import router from "./router";
import axios from "axios";
import Cookies from "js-cookie";
import jQuery from "jquery";
import "./assets/icons.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "./assets/style.css";

Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: "#app",
  router,
  components: {
    App,
  },
  template: "<App/>",
  data() {
    return {
      // app id
      appid: "63b58009c3b56b6177be8d60",
      // عدد الاسئلة في كل قسم
      page_total: 15,
      // الاسئلة من api
      quizs: [],
      // الأجابات المحفوظة
      quiz_joab: {
        a: [],
        b: [],
        c: [],
        d: [],
      },
      // الأسئلة المميزة بعلامة
      quiz_tags: {
        a: [],
        b: [],
        c: [],
        d: [],
      },
      // الاسئلة الغير مكتملة
      quiz_none: {
        a: [],
        b: [],
        c: [],
        d: [],
      },
      // تحرير الوقت
      // مدة السؤال بثانية
      seconds: 90,

      // صفحة بين الاقسام
      sapa_time: {
        minute: 0,
        seconds: 10,
      },
      // مدة الاجابة على الاسئلة في كل قسم
      quiz_time: {
        minute: 5,
        seconds: 2,
      },

      ///////////////////////////////
      // لا تغير شئ تحت هذا الكومنت //
      ///////////////////////////////

      // رقم السؤال الاول
      quiz_number: 0,
      // رقم القسم الحالي
      quiz_revision: 1,

      // faek
      faek_total: 12,
      faek_num: 0,

      // revision
      // 0 > مراجعة الكل
      // 1 > مراجعة الغير مكتمل
      // 2 > مراجعة المميز بعلامة
      revision: 0,
      // شاشة التحميل
      loader: false,

      pops: true,
      // الوقت الفعلي
      timer: "00:00",
      loadtimer: '<i class="fas fa-sync fa-spin"></i>',

      // الوقت المزيف
      faek_time: {
        minute: 6,
        seconds: 6,
      },
      app_rand: "",
      quiz_faek: "start",

      // حجم الخط
      fontsizequiz: 18,
      checkrefrsh: false,

      thatdatea: 0,
      thatdateb: 0,
      thatdatec: 0,
      thatdated: 0,

      addtimers: false,
      popsendtime: true,
      quiz_total: 0,
      total: [0, 0, 0, 0],
      random: "",
      totalnone: 0,
      quiz_viwe: [0, 0, 0, 0],
      isnext: "",
      rev_faek: 0,
    };
  },
  methods: {
    async run() {
      await this.appSave();
      this.random = this.cookeiesRandom(22);
      this.timer = this.loadtimer;
      this.loader = true;
      await axios
        .get("//ahmedapi.alhutacademy.com/quiz/63b58009c3b56b6177be8d60")
        .then(async (response) => {
          this.quizs = response.data;
          this.loader = false;
          this.totaler();
        });
    },
    async appSave() {
      let check = Cookies.get("appquiz");
      if (!check) {
        let rand = this.appid;
        router.push("/" + rand).catch((err) => {});
        Cookies.set("appquiz", rand, { expires: 360 });
        Cookies.set("quiz_faek", this.quiz_faek, { expires: 360 });
        Cookies.set("quiz_joab", JSON.stringify(this.quiz_joab), {
          expires: 360,
        });
        Cookies.set("quiz_tags", JSON.stringify(this.quiz_tags), {
          expires: 360,
        });
        Cookies.set("quiz_none", JSON.stringify(this.quiz_none), {
          expires: 360,
        });
        Cookies.set("quiz_number", this.quiz_number, { expires: 360 });
        Cookies.set("quiz_revision", this.quiz_revision, { expires: 360 });
        Cookies.set("faek_total", this.faek_total, { expires: 360 });
        Cookies.set("faek_num", this.faek_num, { expires: 360 });
        Cookies.set("faek_time", JSON.stringify(this.faek_time), {
          expires: 360,
        });
        Cookies.set("timer", this.timer, { expires: 360 });
        Cookies.set("revision", this.revision, { expires: 360 });
        Cookies.set("fontsizequiz", this.fontsizequiz, { expires: 360 });
        Cookies.set("popsendtime", this.popsendtime, { expires: 360 });
        Cookies.set("quiz_viwe", JSON.stringify(this.quiz_viwe), {
          expires: 360,
        });
      } else {
        let appquiz = String(Cookies.get("appquiz"));
        this.app_rand = appquiz;
        this.quiz_faek = String(Cookies.get("quiz_faek"));
        this.quiz_joab = await JSON.parse(Array(Cookies.get("quiz_joab")));
        this.quiz_tags = await JSON.parse(Array(Cookies.get("quiz_tags")));
        this.quiz_none = await JSON.parse(Array(Cookies.get("quiz_none")));
        this.quiz_number = Number(Cookies.get("quiz_number"));
        this.quiz_revision = Number(Cookies.get("quiz_revision"));
        this.faek_total = Number(Cookies.get("faek_total"));
        this.faek_num = Number(Cookies.get("faek_num"));
        this.faek_time = await JSON.parse(Array(Cookies.get("faek_time")));
        this.timer = String(Cookies.get("timer"));
        this.revision = Number(Cookies.get("revision"));
        this.fontsizequiz = Number(Cookies.get("fontsizequiz"));
        this.popsendtime = Number(Cookies.get("popsendtime"));
        this.quiz_viwe = await JSON.parse(Array(Cookies.get("quiz_viwe")));

        this.thatdatea = Number(Cookies.get("thatdatea"));
        this.thatdateb = Number(Cookies.get("thatdateb"));
        this.thatdatec = Number(Cookies.get("thatdatec"));
        this.thatdated = Number(Cookies.get("thatdated"));

        let xnow = new Date().getTime();
        if (!this.checkrefrsh) {
          if (this.quiz_faek != "end") {
            if (
              xnow > this.thatdatea + 1000 * 15 &&
              xnow < this.thatdateb + 1000 * 15
            ) {
              this.$root.quiz_revision = 2;
              this.$root.quiz_faek = "separation";
              this.$root.quiz_number = 0;
              this.$root.updateSave();
              this.$root.checkdate();
              router.push("/separation/" + appquiz).catch((err) => {});
            } else if (
              xnow > this.thatdateb + 1000 * 15 &&
              xnow < this.thatdatec + 1000 * 15
            ) {
              this.$root.quiz_revision = 3;
              this.$root.quiz_faek = "separation";
              this.$root.quiz_number = 0;
              this.$root.updateSave();
              this.$root.checkdate();
              router.push("/separation/" + appquiz).catch((err) => {});
            } else if (
              xnow > this.thatdatec + 1000 * 15 &&
              xnow < this.thatdated + 1000 * 15
            ) {
              this.$root.quiz_revision = 4;
              this.$root.quiz_faek = "separation";
              this.$root.quiz_number = 0;
              this.$root.updateSave();
              this.$root.checkdate();
              router.push("/separation/" + appquiz).catch((err) => {});
            } else if (xnow > this.thatdated + 1000 * 15) {
              this.$root.quiz_faek = "end";
              this.$root.quiz_number = 0;
              this.$root.updateSave();
              router.push("/end").catch((err) => {});
            }
          }
        }
        let fsq = this.fontsizequiz;
        jQuery("style#one").html(
          ".fontsizequiz {font-size: " + fsq + "px!important;}"
        );
      }

      let appquix = await String(Cookies.get("appquiz"));
      if (this.quiz_faek == "start")
        router.push("/" + appquix).catch((err) => {});
      else if (this.quiz_faek == "end")
        router.push({ name: "End", path: "/end" }).catch((err) => {});
    },
    updateSave() {
      Cookies.set("quiz_faek", this.quiz_faek);
      Cookies.set("quiz_joab", JSON.stringify(this.quiz_joab));
      Cookies.set("quiz_tags", JSON.stringify(this.quiz_tags));
      Cookies.set("quiz_none", JSON.stringify(this.quiz_none));
      if (this.checkrefrsh) {
        if (this.addtimers) {
          /////////////////////////////////
          var xnow = new Date().getTime();
          this.thatdatea = this.addMinutes(
            xnow,
            this.seconds * this.quiz_total * 1
          );
          this.thatdateb = this.addMinutes(
            xnow,
            this.seconds * this.quiz_total * 2
          );
          this.thatdatec = this.addMinutes(
            xnow,
            this.seconds * this.quiz_total * 3
          );
          this.thatdated = this.addMinutes(
            xnow,
            this.seconds * this.quiz_total * 4
          );
          /////////////////////////////////

          Cookies.set("thatdatea", this.thatdatea, { expires: 360 });
          Cookies.set("thatdateb", this.thatdateb, { expires: 360 });
          Cookies.set("thatdatec", this.thatdatec, { expires: 360 });
          Cookies.set("thatdated", this.thatdated, { expires: 360 });
          this.addtimers = false;
        }
        Cookies.set("quiz_number", this.quiz_number);
        Cookies.set("popsendtime", this.popsendtime);
        Cookies.set("fontsizequiz", this.fontsizequiz);
        Cookies.set("faek_total", this.faek_total);
        if (
          this.quiz_faek != "revision" &&
          this.quiz_faek != "quiz" &&
          this.quiz_faek != "end"
        ) {
          Cookies.set("quiz_revision", this.quiz_revision);
        }
        Cookies.set("faek_num", this.faek_num);
        Cookies.set("faek_time", JSON.stringify(this.faek_time));
        Cookies.set("quiz_viwe", JSON.stringify(this.quiz_viwe));
      }
      Cookies.set("timer", this.timer);
      Cookies.set("revision", this.revision);
      this.checkrefrsh = true;
      this.appSave();
    },
    checkdate() {
      let rev = this.$root.quiz_revision;
      let xnow = new Date().getTime();
      if (rev == 2) {
        /////////////////////////////////
        this.thatdateb = this.addMinutes(
          xnow,
          this.seconds * this.quiz_total * 1
        );
        this.thatdatec = this.addMinutes(
          xnow,
          this.seconds * this.quiz_total * 2
        );
        this.thatdated = this.addMinutes(
          xnow,
          this.seconds * this.quiz_total * 3
        );
        /////////////////////////////////
        Cookies.set("thatdateb", this.thatdateb);
        Cookies.set("thatdatec", this.thatdatec);
        Cookies.set("thatdated", this.thatdated);
      } else if (rev == 3) {
        /////////////////////////////////
        this.thatdatec = this.addMinutes(
          xnow,
          this.seconds * this.quiz_total * 1
        );
        this.thatdated = this.addMinutes(
          xnow,
          this.seconds * this.quiz_total * 2
        );
        /////////////////////////////////
        Cookies.set("thatdatec", this.thatdatec);
        Cookies.set("thatdated", this.thatdated);
      } else if (rev == 4) {
        /////////////////////////////////
        this.thatdated = this.addMinutes(
          xnow,
          this.seconds * this.quiz_total * 1
        );
        /////////////////////////////////
        Cookies.set("thatdated", this.thatdated);
      }
    },
    cookeiesRandom: function (length) {
      let result = "";
      const characters =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      const charactersLength = characters.length;
      let counter = 0;
      while (counter < length) {
        result += characters.charAt(
          Math.floor(Math.random() * charactersLength)
        );
        counter += 1;
      }
      return result;
    },
    addMinutes(xdate, minutes) {
      const xtime = xdate + minutes * 1000;
      const dateCopy = new Date(xtime).getTime();
      return dateCopy;
    },
    getmin(countDownDate) {
      var now = new Date().getTime();
      var distance = countDownDate - now;
      var min = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      return min;
    },
    totaler() {
      this.quiz_total = this.page_total;
      let qtl = this.quiz_total;
      let xlg = this.quizs.questions.length;
      let xth = qtl * 4 - xlg;
      this.total = [qtl, qtl, qtl, qtl - xth];
    },
  },
  mounted() {
    this.run();
  },
  watch: {
    $route: "run",
  },
});

// WEBPACK FOOTER //
// ./src/main.js
