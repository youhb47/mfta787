<template>
    <div class="
            row
            footer
            w-100
            m-0
            w-100
            py-1
            px-3
            quiz_footer
            justify-content-between
            align-items-center
            bg-DarkBlueOldColor
            justify-content-center
        ">
        <div class="py-0 col-4 d-flex justify-content-start">
                <button 
                class="rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white">
                    <h6 class="cursor_pointer my-0 fontsizequiz">
                        <i class="fa-solid fa-circle-info"></i>
                        المعادلات
                    </h6>
                </button>
            <button @click="end_revision" :disabled="this.$root.loader" class="rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white">
                <h6 class="cursor_pointer my-0 fontsizequiz">
                    العودة للمراجعة
                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                </h6>
            </button>
        </div>
        <div class="py-0 d-flex justify-content-end col-8">
            <button @click="backlist" :disabled="this.$root.loader" 
            v-if="page_number != 1 && page_number != null"
            class="rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link">
                <h6 class="cursor_pointer my-0 fontsizequiz">
                    <i class="fa-solid fa-arrow-right"></i>
                    السابق
                </h6>
            </button>
            <button @click="nextlist" :disabled="$root.loader" 
            class="rounded-0 border-end border-2 btn btn-link py-2 text-decoration-none text-white">
                <h6 class="cursor_pointer my-0 fontsizequiz">
                    التالي
                    <i class="fa-solid fa-arrow-left"></i>
                </h6>
            </button>
        </div>
    </div>
    </template>
    
    <script>
    export default {
        name: "Header",
        props: {
            BooleanNext: Boolean,
            BooleanAfter: Boolean,
            HerePage: String
        },
        data() {
            return {
                page_number  : this.$root.quiz_number,
                numberQuizOrPage: this.$root.quiz_number,
            };
        },
        methods: {
            run() {
                this.page_number = this.$root.quiz_number
            },
            end_revision() {
                this.$root.quiz_faek = 'revision'
                this.$root.updateSave()
                this.$router.push({ name: 'Revision', params: { id: this.$root.app_rand } }).catch(err => {})
            },
            nextlist() {
                let np = this.page_number
                let qt = this.$root.faek_total
                
                this.$root.loader = true
                if (np > (qt - 1)) {
                    this.$router.push({ name: 'Revision', params: { id: this.$root.app_rand } }).catch(err => {})
                } else {
                    this.$root.quiz_number = (this.$root.quiz_number + 1)
                    this.$router.push({ name: 'Revision Quiz', params: { id: this.$root.app_rand } }).catch(err => {})
                }
                this.$root.updateSave()
            },
            backlist () {
                this.$root.loader = true
                this.$root.quiz_number = (this.$root.quiz_number - 1)
                this.$router.push({ name: 'Revision Quiz', params: { id: this.$root.app_rand } }).catch(err => {})
                this.$root.updateSave()
            }
        },
        watch: {
            '$root.quiz_number': function() {
                this.run()
            }
        }
    };
    </script>
    


// WEBPACK FOOTER //
// src/components/revision/Footer.vue