<template>
    <div class="m-0 p-0">
        <DragCol dir="ltr" style="width: 100%; height: max-content">
            <template #left>
                <div class="sp_style pt-3 px-3 fontsizequiz">
                    <h4 class="quiz_description_1 text-danger fontsizequiz">
                        استيعاب المقروء
                    </h4>
                    <h5 class="quiz_description_2 text-danger fontsizequiz">
                        السؤال التالي يتعلق بالنص المرفق , بعد السؤال هناك أربع اختيارات ,
                        واحد منها صحيح المطلوب , هو قراءة النص بعناية , ثم اختيار الإجابة
                        الصحيحة
                    </h5>
                    <h5 class="quiz_description_2 fontsizequiz">
                        {{ quiz.questions[number_quiz].paragraph }}
                    </h5>
                </div>
            </template>
            <template #right>
                <div class="sp_style pt-3 px-3 fontsizequiz">
                    <div class="sp_in_sp">
                        <h4 class="quiz_description_1 mb-3">
                            <p :inner-html.prop="quiz.questions[number_quiz].name"></p>
                        </h4>
                        <form ref="anyName">
                            <div v-for="(value, index) in quiz.questions[number_quiz].options" :key="index" 
                            class="form-check form-group mt-1 me-4 mb-3">
                                <input class="form-check-input float-end ms-2" type="radio" 
                                name="exampleRadios" :id="'exampleRadios' + number_quiz + 'q' + index" 
                                :value="'option' + number_quiz + 'q' + index" 
                                @click="checkbox(number_quiz, index)" :checked="joab[index]"/>
                                <label class="form-check-label" :for="'exampleRadios' + number_quiz + 'q' + index">
                                    {{ value.name }}
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
            </template>
        </DragCol>
    </div>
    </template>
    
    <script>
    import {
        DragCol,
        DragRow,
        ResizeCol,
        ResizeRow,
        Resize
    } from "vue-resizer";
    
    export default {
        name: "Single",
        components: {
            DragCol,
            DragRow,
            ResizeCol,
            ResizeRow,
            Resize
        },
        data() {
            return {
                page  : this.$root.quiz_number,
                quiz  : this.$root.quizs,
                joab  : [false, false, false, false],
                number_quiz : 0
            };
        },
        methods: { 
            async run() {
                await this.$root.appSave()
                let rev    = this.$root.revision
                this.page  = (this.$root.quiz_number - 1)
                this.quiz  = this.$root.quizs
                let qev = this.$root.quiz_revision
                let tol = this.$root.quiz_total
                this.checkedis()
                if (rev == 1) {
                    this.quizs_none()
                } else if (rev == 2) {
                    this.quizs_tags()
                } else {
                    if (qev != 1) {
                        this.number_quiz  = ((this.$root.quiz_number - 1) + (tol * (qev - 1)))
                        this.$root.faek_num  = ((this.$root.quiz_number - 1) + (tol * (qev - 1)))
                    } else {
                        this.number_quiz  = (this.$root.quiz_number - 1)
                        this.$root.faek_num  = (this.$root.quiz_number - 1)
                    }
                }
                this.$root.updateSave()
            },
            quizs_tags() {
                let arr;
                let np = this.page;
                let rev = this.$root.quiz_revision
                if      (rev == 1) {arr = this.$root.quiz_tags.a}
                else if (rev == 2) {arr = this.$root.quiz_tags.b}
                else if (rev == 3) {arr = this.$root.quiz_tags.c}
                else if (rev == 4) {arr = this.$root.quiz_tags.d}
                this.number_quiz = arr[np].id
                this.$root.faek_num = arr[np].id
                // this.$root.updateSave()
            },
            quizs_none() {
                let arr;
                let np = this.page;
                let rev = this.$root.quiz_revision
                if      (rev == 1) {arr = this.$root.quiz_none.a}
                else if (rev == 2) {arr = this.$root.quiz_none.b}
                else if (rev == 3) {arr = this.$root.quiz_none.c}
                else if (rev == 4) {arr = this.$root.quiz_none.d}
                this.number_quiz = arr[np].id
                this.$root.faek_num = arr[np].id
                // this.$root.updateSave()
            },
            checkbox(i, b) {
                let barr = true
                let int = i, bnt = b
                let rev = this.$root.quiz_revision;
                let arr = {id: i, joab: bnt};
                let QJ;
                if (rev == 1) {
                    QJ  = this.$root.quiz_joab.a;
                } else if (rev == 2) {
                    QJ  = this.$root.quiz_joab.b;
                } else if (rev == 3) {
                    QJ  = this.$root.quiz_joab.c;
                } else if (rev == 4) {
                    QJ  = this.$root.quiz_joab.d;
                }
                for (let key = 0; key < QJ.length; key++) {
                    if(QJ[key].id == int) {
                        QJ[key].joab = bnt;
                        barr = false
                        break;
                    }
                }
                if (barr) {
                    QJ.push(arr);
                }
                if (rev == 1) {
                    this.$root.quiz_joab.a = QJ;
                } else if (rev == 2) {
                    this.$root.quiz_joab.b = QJ;
                } else if (rev == 3) {
                    this.$root.quiz_joab.c = QJ;
                } else if (rev == 4) {
                    this.$root.quiz_joab.d = QJ;
                }
                this.checkedis()
                this.$root.updateSave()
            },
            async checkedis() {
                this.joab = await [false, false, false, false];
                let int   = this.number_quiz
                let rev = this.$root.quiz_revision;
                let arr;
                if (rev == 1) {
                    arr  = this.$root.quiz_joab.a;
                } else if (rev == 2) {
                    arr  = this.$root.quiz_joab.b;
                } else if (rev == 3) {
                    arr  = this.$root.quiz_joab.c;
                } else if (rev == 4) {
                    arr  = this.$root.quiz_joab.d;
                }
                let Qjb   = this.joab;
                for (let key = 0; key < arr.length; key++) {
                    if(arr[key].id == int) {
                        Qjb[arr[key].joab] = true
                    }
                }
                this.joab = Qjb
            }
        },
        mounted() {
            this.run()
        },
        watch: {
            '$root.quiz_number': 'run'
        }
    };
    </script>
    


// WEBPACK FOOTER //
// src/components/revision/Single.vue