<template>
    <div class="heyisnone">
        <div class="row m-0">
            <!-- b header -->
            <Header
                :BooleanTimer="true"
                :BooleanNumQuiz="false"
                :BooleanTagSave="false"
            />
            <!-- e header -->
            <div>
            </div>
            <div class="col-12 p-0 position-relative overflow-hidden">
                <!-- b loader -->
                <Loader v-if="this.$root.loader"/>
                <!-- e loader -->
                <div class="row mb-6 revision-cards">
                    <div class="col-12 p-0">
                        <h5 class="text-center py-2">
                            قسم المراجعة
                        </h5>
                        <div class="backGrd py-2 px-4 text-end text-white px-4">
                            إرشادات
                        </div>
                        <div class="text-end py-2 px-2 mx-4">
                            <p>
                                فيما يلي ملخص لإجابتك يمكنك مراجعة أسئلتك بثلاث (3) طرق مختلفة
                            </p>
                            <p>
                                الأزرار الموجودة في الركن السفلي الأيسر تطابق هذه الخيارات:
                            </p>
                            <ul>
                                <li>
                                    قم بمراحعة كل أسئلتك و إجاباتك
                                </li>
                                <li>
                                    قم بمراجعة أسئلتك الغير مكتملة
                                </li>
                                <li>
                                    قم بمراجعة الأسئلة المميزة بعلامة المراجعة
                                </li>
                            </ul>
                            <p>
                                يمكنك ايضا النقر فوق رقم سؤال لربطه مباشرة بموقعه في الاختبار
                            </p>
                        </div>
                        <div class="backGrd py-2 px-4 text-end text-white">
                            الباب 
                            {{ quiz_revision }}
                            جزء الحالي

                            <div class="float-start">
                                (غير مكتمل/غير مرئي {{ xspx() }} )
                            </div>
                        </div>
                    </div>
                    <button type="button" class="quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2" 
                    v-for="index of $root.total[quiz_revision-1]" :key="index" @click="btn(index)">
                        <img :src="otg(rnp(index))">
                        سؤال {{ index }}
                        <div class="text-danger float-start">
                            {{ oop(rnp(index)) }}
                        </div>
                    </button>
                </div>
            </div>

            <!-- b footer -->
            <Footer/>
            <!-- e footer -->
        </div>
        <div class="modal fade" @mousedown="dragElement('statictime')" id="statictime" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog" id="statictimeheader">
                <div class="modal-content border-0 rounded-0">
                <div class="modal-header py-1">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">
                        <i class="fa-regular fa-clock"></i>
                        تبقى خمس دقائق
                    </h1>
                <button type="button" class="btn fs-4 p-0 text-white" @click="closeModal('#statictime')">
                    <i class="fa-regular fa-rectangle-xmark"></i>
                </button>
                </div>
                <div class="modal-body row">
                    <div class="col-1">
                        <img src="@/assets/icon/information.png" >
                    </div>
                    <div class="col-11">
                        <p>
                            لديك 5 دقائق فقط لإنهاء هذا القسم
                        </p>
                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" @click="closeModal('#statictime')" class="btn btn-secondary rounded-0 border-1 border-white">
                    حسناُ
                    </button>
                </div>
                </div>
            </div>
        </div>
        <div class="modal fade" @mousedown="dragElement('staticendtime')" id="staticendtime" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog" id="staticendtimeheader">
                <div class="modal-content border-0 rounded-0">
                <div class="modal-header py-1">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">
                        <i class="fa-regular fa-clock"></i>
                        انتهى الوقت
                    </h1>
                <button type="button" class="btn fs-4 p-0 text-white" @click="closeModal('#staticendtime')">
                    <i class="fa-regular fa-rectangle-xmark"></i>
                </button>
                </div>
                <div class="modal-body row">
                    <div class="col-1">
                        <img src="@/assets/icon/information.png" >
                    </div>
                    <div class="col-11">
                        <p>
                          إنتهت المدة المسموحة لحل القسم - إضغط موافق للمتابعة
                        </p>
                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" @click="nextlist()" class="btn btn-secondary rounded-0 border-1 border-white">
                    موافق
                    </button>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
import jQuery from 'jquery'
// import xtimer from "../xtimer";
import xdate from "../xdate";
import Header from "./aps/Header";
import Footer from "./other/Footer";
import Loader from "./aps/Loader";

import TgImage from "../assets/icon/15.png";
import TsImage from "../assets/icon/13.png";

export default {
  name: "Revision",
  components: {
    Header,
    Footer,
    Loader,
  },
  data() {
    return {
        TgImage: TgImage,
        TsImage: TsImage,
        page    : this.$route.params.id,
        minute: 5,
        seconds: 5,
        date: this.$root.thatdatea,
        timer: this.$root.timer,
        plus: false,
        plustime: '00:10',
        quiz_joab   : [],
        quiz_revision : 0,
        totalnone: 0,
    };
  },
  methods: {
    // بداية التشغيل
    async run() {
        await this.$root.appSave();
        xdate.xstop();
        if (this.$root.quiz_revision == 1) {

        this.date = this.$root.thatdatea
        this.$root.quiz_viwe[0] = 1;

        } else if (this.$root.quiz_revision == 2) {

        this.date = this.$root.thatdateb
        this.$root.quiz_viwe[1] = 1;

        } else if (this.$root.quiz_revision == 3) {

        this.date = this.$root.thatdatec
        this.$root.quiz_viwe[2] = 1;

        } else if (this.$root.quiz_revision == 4) {

        this.date = this.$root.thatdated
        this.$root.quiz_viwe[3] = 1;

        }

        this.minute  = Number(this.$root.faek_time.minute)
        this.seconds = Number(this.$root.faek_time.seconds)
        this.timer   = this.$root.timer

        this.floader();
        xdate.xstart(this);

        this.quiz_revision = this.$root.quiz_revision
        this.$root.quiz_number = 1
        this.$root.faek_total = this.$root.quiz_total
        this.xsp();

        this.$root.updateSave();
        this.thistime();
    },
    // معرفة رقم السؤال الحقيقي
    rnp(i) {
        let rev = this.$root.quiz_revision
        let tol = this.$root.quiz_total
        if (rev != 1) {
            return ((i - 1) + (tol * (rev - 1)))
        } else {
            return (i - 1)
        }
    },
    // شاشة التوقف عن التحميل
    floader() {
      setInterval(() => {
        this.$root.loader = false
      }, 2000)
    },
    // رسالة الظهور الغير مكتمل
    oop(value) {
        let arr;
        let rev = this.$root.quiz_revision
        if (rev == 1) {
            arr = this.$root.quiz_joab.a
        } else if (rev == 2) {
            arr = this.$root.quiz_joab.b
        } else if (rev == 3) {
            arr = this.$root.quiz_joab.c
        } else if (rev == 4) {
            arr = this.$root.quiz_joab.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (arr[key].id == value) {
                return ''
            }
        }
        return 'غير مكتمل'
    },
    // التأكد إذا كان السؤال غير مكتمل او لا
    vmg (value) {
        let arr;
        let rev = this.$root.quiz_revision
        if (rev == 1) {
            arr = this.$root.quiz_joab.a
        } else if (rev == 2) {
            arr = this.$root.quiz_joab.b
        } else if (rev == 3) {
            arr = this.$root.quiz_joab.c
        } else if (rev == 4) {
            arr = this.$root.quiz_joab.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (arr[key].id == value) {
                return false
            }
        }
        return true
    },
    // الاسئلة الغير مكتملة
    xsp() {
        var arv;
        var arr = [];
        let rev = this.$root.quiz_revision
        let qiz = this.$root.quiz_total
        let tol = this.$root.quiz_total
        for (let key = ((qiz * rev) - qiz); key < (rev == 4 ? this.ddv() : tol * rev); key++) {
            if (this.vmg(key)) {
                arv = {id: key}
                arr.push(arv);
            }
        }
        if      (rev == 1) {this.$root.quiz_none.a = arr}
        else if (rev == 2) {this.$root.quiz_none.b = arr}
        else if (rev == 3) {this.$root.quiz_none.c = arr}
        else if (rev == 4) {this.$root.quiz_none.d = arr}
        this.$root.updateSave()
        this.tnc();
    },
    // الاسئلة الغير مكتملة
    xspx() {
        var arv;
        var arr = [];
        let rev = this.$root.quiz_revision
        let qiz = this.$root.quiz_total
        let tol = this.$root.quiz_total
        for (let key = ((qiz * rev) - qiz); key < (rev == 4 ? this.ddv() : tol * rev); key++) {
            if (this.vmg(key)) {
                arv = {id: key}
                arr.push(arv);
            }
        }
        if      (rev == 1) {this.$root.quiz_none.a = arr}
        else if (rev == 2) {this.$root.quiz_none.b = arr}
        else if (rev == 3) {this.$root.quiz_none.c = arr}
        else if (rev == 4) {this.$root.quiz_none.d = arr}
        return arr.length
    },
    ddv () {
        return (this.$root.total[0] + this.$root.total[1] + this.$root.total[2] + this.$root.total[3])
    },
    // السؤال المميز بعلامة
    otg (value) {
        let arr;
        let rev = this.$root.quiz_revision
        if (rev == 1) {
            arr = this.$root.quiz_tags.a
        } else if (rev == 2) {
            arr = this.$root.quiz_tags.b
        } else if (rev == 3) {
            arr = this.$root.quiz_tags.c
        } else if (rev == 4) {
            arr = this.$root.quiz_tags.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (arr[key].id == value) {
                if (arr[key].tag) {
                    return this.TsImage
                }
            }
        }
        return this.TgImage
    },
    // معرفة إذا كان السؤال مميز بعلامة
    uod (value) {
        let arr;
        let rev = this.$root.quiz_revision
        if (rev == 1) {
            arr = this.$root.quiz_tags.a
        } else if (rev == 2) {
            arr = this.$root.quiz_tags.b
        } else if (rev == 3) {
            arr = this.$root.quiz_tags.c
        } else if (rev == 4) {
            arr = this.$root.quiz_tags.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (arr[key].id == value) {
                if (arr[key].tag) {
                    return true
                }
            }
        }
        return false
    },
    // الاسئلة المميزة بعلامة
    ueq() {
        var arv;
        var arr = [];
        let rev = this.$root.quiz_revision
        let qiz = this.$root.quiz_total
        for (let key = ((qiz * rev) - qiz); key < (qiz * rev); key++) {
            if (this.uod(key)) {
                arv = {id: key}
                arr.push(arv);
            }
        }
        if      (rev == 1) {this.$root.quiz_tags.a = arr}
        else if (rev == 2) {this.$root.quiz_tags.b = arr}
        else if (rev == 3) {this.$root.quiz_tags.c = arr}
        else if (rev == 4) {this.$root.quiz_tags.d = arr}
    },
    // زر الانتقال الى السؤال الفعلي
    btn(i) {
        this.$root.quiz_faek = 'revision_quiz'
        this.$root.revision = 0
        this.$root.quiz_number = i
        this.$root.faek_total = this.$root.total[this.$root.quiz_revision-1]
        // this.$router.push('/revision/' + i)
        this.$root.updateSave()
        this.$router.push({ name: 'Revision Quiz', params: { id: this.$root.app_rand } })
    },
    nextlist() {
          let qr = this.$root.quiz_revision
          this.$root.quiz_faek = 'separation'
          this.$root.quiz_number = 0
          if (qr == 1) {
              this.$root.quiz_revision = 2
              this.$root.updateSave()
              this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
          } else if (qr == 2) {
              this.$root.quiz_revision = 3
              this.$root.updateSave()
              this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
          } else if (qr == 3) {
              this.$root.quiz_revision = 4
              this.$root.updateSave()
              this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
          } else if (qr == 4) {
              this.$root.quiz_faek = "end"
              this.$root.quiz_revision = 5
              this.$root.updateSave()
              this.$router.push({ name: 'End', path: '/end' }).catch(err => {})
          }
          this.plus = false
    },
        dragElement(event) {
            var elmnt = document.getElementById(event)
            var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
            if (document.getElementById(elmnt.id + "header")) {
                // if present, the header is where you move the DIV from:
                document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
            } else {
                // otherwise, move the DIV from anywhere inside the DIV:
                elmnt.onmousedown = dragMouseDown;
            }

            function dragMouseDown(e) {
                e = e || window.event;
                e.preventDefault();
                // get the mouse cursor position at startup:
                pos3 = e.clientX;
                pos4 = e.clientY;
                document.onmouseup = closeDragElement;
                // call a function whenever the cursor moves:
                document.onmousemove = elementDrag;
            }

            function elementDrag(e) {
                e = e || window.event;
                e.preventDefault();
                // calculate the new cursor position:
                pos1 = pos3 - e.clientX;
                pos2 = pos4 - e.clientY;
                pos3 = e.clientX;
                pos4 = e.clientY;
                // set the element's new position:
                elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
                elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
            }

            function closeDragElement() {
                // stop moving when mouse button is released:
                document.onmouseup = null;
                document.onmousemove = null;
            }
            },
        openModal(event) {
            jQuery(event).attr('class', 'modal fade show');
            jQuery(event).attr('style', 'display: block; padding-left: 0px;');
        },
        closeModal(event) {
            jQuery(event).attr('class', 'modal fade');
            jQuery(event).attr('style', '');
        },
        thistime() {
          if (this.minute <= 0 && this.seconds <= 0) {
            xdate.xstop();
            jQuery('p#clock').html('<i class="fa-regular fa-clock"></i> انتهى الوقت')
          }
        },
        async tnc() {
            var arr;
            var rev = this.$root.quiz_revision;
            if (rev == 1) {
                arr = this.$root.quiz_none.a
            } else if (rev == 2) {
                arr = this.$root.quiz_none.b
            } else if (rev == 3) {
                arr = this.$root.quiz_none.c
            } else if (rev == 4) {
                arr = this.$root.quiz_none.d
            }
            this.totalnone = this.xspx()
        }
  },
  mounted() {
    this.run();
  },
  created() {
    this.run();
  },
  watch: {
    'totalnone' : function() {
        this.$root.totalnone = this.totalnone
    },
    '$root.quiz_number': "run",
    'timer': function () {
        if (this.timer != "00:00" && this.plustime == "00:10") {  
            this.$root.faek_time.minute  = this.minute
            this.$root.faek_time.seconds = this.seconds
            this.$root.timer = this.timer
            if (this.minute < 5) {
            if (this.$root.pops && this.$root.popsendtime) {
                this.$root.pops = false
                this.openModal('#statictime')
            }
            jQuery('p#clock').attr('style', 'color:yellow !important;')
            }
        }
        if (this.minute <= 0 && this.seconds <= 0) {
            xdate.xstop();
            this.plus = true
            if (this.plus) {this.plustime = this.timer}
            setTimeout(() => {
                this.nextlist()
            }, 10000);
            if (this.plustime != '00:00') {
                this.openModal('#staticendtime')
            }
            this.thistime()
        }
        },
  }
};
</script>


// WEBPACK FOOTER //
// src/components/Revision.vue