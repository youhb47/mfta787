import Vue from "vue";
import Router from "vue-router";
import Start from "@/components/Start";
import Separation from "@/components/Separation";
import Quiz from "@/components/Quiz";
import Revision from "@/components/Revision";
import RevisionQuiz from "@/components/revision/Quiz";
import End from "@/components/End";
import EndQuiz from "@/components/end/Quiz";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      name: "Start",
      component: Start,
    },
    {
      path: "/:str",
      name: "Start tow",
      component: Start,
    },
    {
      path: "/separation/:id",
      name: "Separation",
      component: Separation,
    },
    {
      path: "/quiz/:id",
      name: "Quiz",
      component: Quiz,
    },
    {
      path: "/revision/:id",
      name: "Revision",
      component: Revision,
    },
    {
      path: "/revision/:id",
      name: "Revision Quiz",
      component: RevisionQuiz,
    },
    {
      path: "/end",
      name: "End",
      component: End,
    },
    {
      path: "/end/:id",
      name: "EndQuiz",
      component: EndQuiz,
    },
  ],
});

// WEBPACK FOOTER //
// ./src/router/index.js
