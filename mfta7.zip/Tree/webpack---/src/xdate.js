// xdate
let xintl;

let xstart = (that) => {
  var countDownDate = that.date;
  xintl = setInterval(function () {
    // Get today's date and time
    var now = new Date().getTime();

    // Find the distance between now and the count down date
    var distance = countDownDate - now;

    // Time calculations for days, hours, minutes and seconds
    // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hor = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var min = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var sec = Math.floor((distance % (1000 * 60)) / 1000);
    // alert(days)
    if (hor == 0 && min == 0 && sec == 0) {
      that.timer = "00:00";
    } else {
      that.minute = min;
      that.seconds = sec;
      var tttr =
        (min < 10 ? "0" + min : min) + ":" + (sec < 10 ? "0" + sec : sec);
      if (hor != 0)
        that.timer = hor < 10 ? "0" + hor + ":" + tttr : hor + ":" + tttr;
      else that.timer = tttr;
    }
  }, 1000);
};

let xstop = () => {
  clearInterval(xintl);
};

var xdate = {
  xstart: xstart,
  xstop: xstop,
};

export default xdate;

// WEBPACK FOOTER //
// ./src/xdate.js
