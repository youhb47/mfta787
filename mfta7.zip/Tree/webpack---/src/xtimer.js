//xtimer.js

let zinter;

let xstart = (that) => {
  var min = that.minute;
  var sec = that.seconds;
  zinter = setInterval(() => {
    if (min == 0 && sec == 0) {
      that.timer = "00:00";
    } else {
      if (sec < 11) {
        if (sec == 0) {
          min = min - 1;
          sec = 59;
        } else {
          sec = "0" + (sec - 1);
        }
      } else {
        sec = sec - 1;
      }
      that.minute = min;
      that.seconds = sec;
      that.timer = (min < 10 ? "0" + min : min) + ":" + sec;
    }
  }, 1000);
};

let xstop = () => {
  clearInterval(zinter);
};

var xtimer = {
  xstart: xstart,
  xstop: xstop,
};

export default xtimer;

// WEBPACK FOOTER //
// ./src/xtimer.js
