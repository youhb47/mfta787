<template>
    <div class="heyisnone">
        <div class="row m-0">
            <!-- b header -->
            <Header
                :BooleanTimer="false"
                :BooleanNumQuiz="false"
                :BooleanTagSave="false"
            />
            <!-- e header -->
            <div>
            </div>
            <div class="col-12 p-0 position-relative overflow-hidden">
                <!-- b loader -->
                <Loader v-if="this.$root.loader"/>
                <!-- e loader -->
                <div class="row mb-6 revision-cards">
                    <div class="col-12 p-0">
                        <h3 class="text-center py-2">
                            شكراً لك
                        </h3>
                        <div class="row">
                            <div class="backGrd py-2 px-4 text-end text-white">
                                الاحصائيات ونتيجة النهائية
                            </div>
                            <button type="button" class="quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2">
                                عدد الاسئلة الأختبار
                                <div class="text-danger float-start">
                                    ( {{ ($root.total[0] + $root.total[1] + $root.total[2] + $root.total[3]) }} )
                                </div>
                            </button>
                            <button type="button" class="quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2">
                                غير مكتمل
                                <div class="text-danger float-start">
                                    ( {{ (xtotalnone(1) + xtotalnone(2) + xtotalnone(3) + xtotalnone(4)) }} )
                                </div>
                            </button>
                            <button type="button" class="quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2">
                                الأجابات الصحيحة
                                <div class="text-danger float-start">
                                    ( {{ (tcquiz(1) + tcquiz(2) + tcquiz(3) + tcquiz(4)) }} )
                                </div>
                            </button>
                            <button type="button" class="quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2">
                                الأجابات الخاطئة
                                <div class="text-danger float-start">
                                    ( {{ (xtotalfalse(1) +  xtotalfalse(2) + xtotalfalse(3) + xtotalfalse(4)) }} )
                                </div>
                            </button>
                            <button type="button" class="quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2">
                                الأسئلة المميزة بالعلامة
                                <div class="text-danger float-start">
                                    ( {{ (xtotaltags(1) +  xtotaltags(2) + xtotaltags(3) + xtotaltags(4)) }} )
                                </div>
                            </button>
                            <button type="button" class="quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2">
                                عدد الأقسام
                                <div class="text-danger float-start">
                                    ( 4 )
                                </div>
                            </button>
                        </div>
                            <hr>
                        <div v-for="rev of 4" :key="rev">
                                <div class="backGrd py-2 px-4 text-end text-white">
                                    الباب 
                                    {{ rev }}
                                    جزء الحالي

                                    <div class="float-start">
                                        (غير مكتمل/غير مرئي {{ xtotalnone(rev) }} )
                                    </div>
                                </div>
                            <button type="button" class="quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2" 
                            v-for="index of $root.total[rev-1]" :key="index" @click="btn(index, rev)">
                                <div class="float-end" style="width: 25px;" :inner-html.prop="check_quiz(rnp(index, rev), rev)"></div>
                                <img :src="otg(rnp(index, rev), rev)">
                                سؤال {{ index }}
                                <div class="text-danger float-start">
                                    {{ oop(rnp(index, rev), rev) }}
                                </div>
                            </button>
                            <div class="quizmobi btn rounded-0 col-12 text-end py-2 px-4 border-bottom border-start border-2"
                            style="background: #dee2e6;">
                                <b class="text-success float-end">
                                    الأجابات الصحيحة : {{ tcquiz(rev) }}
                                </b>
                                <b class="text-danger float-start">
                                    الأجابات الخاطئة : {{ xtotalfalse(rev) }}
                                </b>
                            </div>
                            <hr>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
import jQuery from 'jquery'
import xdate from "../xdate";
import Header from "./aps/Header";
import Footer from "./other/Footer";
import Loader from "./aps/Loader";

import TgImage from "../assets/icon/15.png";
import TsImage from "../assets/icon/13.png";

export default {
  name: "Revision",
  components: {
    Header,
    Footer,
    Loader,
  },
  data() {
    return {
        TgImage: TgImage,
        TsImage: TsImage,
        page    : this.$route.params.id,
        minute: 5,
        seconds: 5,
        date: this.$root.thatdatea,
        timer: this.$root.timer,
        plus: false,
        plustime: '00:10',
        quiz_joab   : [],
        quiz_revision : 0,
        totalnone: 0
    };
  },
  methods: {
    // بداية التشغيل
    async run() {
        await this.$root.appSave();
        xdate.xstop();
        this.floader();
        this.$root.quiz_number = 1
        this.$root.faek_total = this.$root.quiz_total
        this.xsp();
        this.$root.updateSave();
    },
    // معرفة رقم السؤال الحقيقي
    rnp(i, n) {
        let rev = n
        let tol = this.$root.quiz_total
        if (rev != 1) {
            return ((i - 1) + (tol * (rev - 1)))
        } else {
            return (i - 1)
        }
    },
    // شاشة التوقف عن التحميل
    floader() {
      setInterval(() => {
        this.$root.loader = false
      }, 2000)
    },
    // هل الأجابة صحيحة ؟
    check_quiz(value, number) {
        let arx = [];
        let rev = number
        let qiz = this.$root.quizs 
        if (rev == 1) {
            arx = this.$root.quiz_joab.a
        } else if (rev == 2) {
            arx = this.$root.quiz_joab.b
        } else if (rev == 3) {
            arx = this.$root.quiz_joab.c
        } else if (rev == 4) {
            arx = this.$root.quiz_joab.d
        }
        for (let key = 0; key < arx.length; key++) {
            if (Number(arx[key].id) == Number(value)) {
                if (qiz.questions[key].options[arx[key].joab].is_true) {
                    return '<i class="fa-solid fa-check" style="float: right;color:green"></i>'
                }
            }
        }
        return '<i class="fa-solid fa-xmark" style="float: right;color:red"></i>'
    },     
    tcquiz(number) {
        let arx = [];
        let num = 0;
        let rev = number;
        let qiz = this.$root.quizs;
        if (rev == 1) {
            arx = this.$root.quiz_joab.a;
        } else if (rev == 2) {
            arx = this.$root.quiz_joab.b;
        } else if (rev == 3) {
            arx = this.$root.quiz_joab.c;
        } else if (rev == 4) {
            arx = this.$root.quiz_joab.d;
        }
        for (let key = 0; key < arx.length; key++) {
            if (Boolean(qiz.questions[key].options[arx[key].joab].is_true) == true) {
                num++;
                // return qiz.questions[key].options[arx[key].joab].is_true
            }
        }
        return num;
    },
    xtotalfalse(number) {
        let arx = [];
        let num = 0;
        let rev = number;
        let qiz = this.$root.quizs;
        if (rev == 1) {
            arx = this.$root.quiz_joab.a;
        } else if (rev == 2) {
            arx = this.$root.quiz_joab.b;
        } else if (rev == 3) {
            arx = this.$root.quiz_joab.c;
        } else if (rev == 4) {
            arx = this.$root.quiz_joab.d;
        }
        for (let key = 0; key < arx.length; key++) {
            if (Boolean(qiz.questions[key].options[arx[key].joab].is_true) != true) {
                num++;
                // return qiz.questions[key].options[arx[key].joab].is_true
            }
        }
        return num;
    },
    // رسالة الظهور الغير مكتمل
    oop(value, number) {
        let arr;
        let rev = number
        if (rev == 1) {
            arr = this.$root.quiz_joab.a
        } else if (rev == 2) {
            arr = this.$root.quiz_joab.b
        } else if (rev == 3) {
            arr = this.$root.quiz_joab.c
        } else if (rev == 4) {
            arr = this.$root.quiz_joab.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (Number(arr[key].id) == Number(value)) {
                return ''
            }
        }
        return 'غير مكتمل'
    },
    // التأكد إذا كان السؤال غير مكتمل او لا
    vmg (value, number) {
        let arr;
        let rev = number
        if (rev == 1) {
            arr = this.$root.quiz_joab.a
        } else if (rev == 2) {
            arr = this.$root.quiz_joab.b
        } else if (rev == 3) {
            arr = this.$root.quiz_joab.c
        } else if (rev == 4) {
            arr = this.$root.quiz_joab.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (Number(arr[key].id) == Number(value)) {
                return false
            }
        }
        return true
    },
    // الاسئلة الغير مكتملة
    xsp() {
        var arv;
        var arr = [];
        let rev = this.$root.quiz_revision
        let qiz = this.$root.quiz_total
        let tol = this.$root.quiz_total
        for (let key = ((qiz * rev) - qiz); key < (rev == 4 ? this.ddv() : tol * rev); key++) {
            if (this.vmg(key, rev)) {
                arv = {id: key}
                arr.push(arv);
            }
        }
        if      (rev == 1) {this.$root.quiz_none.a = arr}
        else if (rev == 2) {this.$root.quiz_none.b = arr}
        else if (rev == 3) {this.$root.quiz_none.c = arr}
        else if (rev == 4) {this.$root.quiz_none.d = arr}
        this.$root.updateSave()
    },
        // الاسئلة الغير مكتملة
        xspx(num) {
        var arv;
        var arr = [];
        let rev = num
        let qiz = this.$root.quiz_total
        let tol = this.$root.quiz_total
        for (let key = ((qiz * rev) - qiz); key < (rev == 4 ? this.ddv() : tol * rev); key++) {
            if (this.vmg(key, rev)) {
                arv = {id: key}
                arr.push(arv);
            }
        }
        if      (rev == 1) {this.$root.quiz_none.a = arr}
        else if (rev == 2) {this.$root.quiz_none.b = arr}
        else if (rev == 3) {this.$root.quiz_none.c = arr}
        else if (rev == 4) {this.$root.quiz_none.d = arr}
        
        return arr
    },
    ddv () {
        return (this.$root.total[0] + this.$root.total[1] + this.$root.total[2] + this.$root.total[3])
    },
    // السؤال المميز بعلامة
    otg (value, number) {
        let arr;
        let rev = number
        if (rev == 1) {
            arr = this.$root.quiz_tags.a
        } else if (rev == 2) {
            arr = this.$root.quiz_tags.b
        } else if (rev == 3) {
            arr = this.$root.quiz_tags.c
        } else if (rev == 4) {
            arr = this.$root.quiz_tags.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (arr[key].id == value) {
                if (arr[key].tag) {
                    return this.TsImage
                }
            }
        }
        return this.TgImage
    },
    xtotaltags(number) {
        let arr;
        let num = 0;
        let rev = number
        if (rev == 1) {
            arr = this.$root.quiz_tags.a
        } else if (rev == 2) {
            arr = this.$root.quiz_tags.b
        } else if (rev == 3) {
            arr = this.$root.quiz_tags.c
        } else if (rev == 4) {
            arr = this.$root.quiz_tags.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (Boolean(arr[key].tag) == true) {
                num++;
            }
        }
        return num;
    },
    // معرفة إذا كان السؤال مميز بعلامة
    uod (value, number) {
        let arr;
        let rev = number
        if (rev == 1) {
            arr = this.$root.quiz_tags.a
        } else if (rev == 2) {
            arr = this.$root.quiz_tags.b
        } else if (rev == 3) {
            arr = this.$root.quiz_tags.c
        } else if (rev == 4) {
            arr = this.$root.quiz_tags.d
        }
        for (let key = 0; key < arr.length; key++) {
            if (arr[key].id == value) {
                if (arr[key].tag) {
                    return true
                }
            }
        }
        return false
    },
    // الاسئلة المميزة بعلامة
    ueq() {
        var arv;
        var arr = [];
        let rev = this.$root.quiz_revision
        let qiz = this.$root.quiz_total
        for (let key = ((qiz * rev) - qiz); key < (qiz * rev); key++) {
            if (this.uod(key, rev)) {
                arv = {id: key}
                arr.push(arv);
            }
        }
        if      (rev == 1) {this.$root.quiz_tags.a = arr}
        else if (rev == 2) {this.$root.quiz_tags.b = arr}
        else if (rev == 3) {this.$root.quiz_tags.c = arr}
        else if (rev == 4) {this.$root.quiz_tags.d = arr}
    },
    // زر الانتقال الى السؤال الفعلي
    btn(i, n) {
        this.$root.quiz_faek = 'end_quiz'
        this.$root.rev_faek = n
        this.$root.revision = 0
        this.$root.quiz_number = i
        this.$root.faek_total = this.$root.total[n-1]
        this.$root.updateSave()
        this.$router.push({ name: 'EndQuiz', params: { id: this.$root.app_rand } }).catch(err => {})
    },
    openModal(event) {
        jQuery(event).attr('class', 'modal fade show');
        jQuery(event).attr('style', 'display: block; padding-left: 0px;');
    },
    closeModal(event) {
        jQuery(event).attr('class', 'modal fade');
        jQuery(event).attr('style', '');
    },
    xtotalnone(rev) {
        return this.xspx(rev).length
    }
  },
  mounted() {
    this.run();
  },
  created() {
    this.run();
  },
  watch: {
    'totalnone' : function() {
        this.$root.totalnone = this.totalnone
    },
    '$root.quiz_number': "run",
  }
};
</script>


// WEBPACK FOOTER //
// src/components/End.vue