<template>
    <div 
    class="
            row
            footer
            w-100
            m-0
            w-100
            py-1
            quiz_footer
            justify-content-between
            align-items-center
            bg-DarkBlueOldColor
            justify-content-center
        ">
        <div class="py-0 col-4 d-flex justify-content-start">
                <button v-if="page_number != null && BooleanAfter" 
                class="rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white">
                    <h6 class="cursor_pointer my-0">
                        <i class="fa-solid fa-circle-info"></i>
                        المعادلات
                    </h6>
                </button>
        </div>
        <div class="py-0 d-flex justify-content-end col-8">
            <button 
            v-if="page_number != 1 && page_number != null && BooleanAfter" 
            @click="backlist" :disabled="$root.loader" 
            class="rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link">
                <h6 class="cursor_pointer my-0">
                    <i class="fa-solid fa-arrow-right"></i>
                    السابق
                </h6>
            </button>
            <button 
            v-if="BooleanNext" 
            @click="nextlist" :disabled="$root.loader"
            class="rounded-0 border-end border-2 btn btn-link py-2 text-decoration-none text-white">
                <h6 class="cursor_pointer my-0">
                    التالي
                    <i class="fa-solid fa-arrow-left"></i>
                </h6>
            </button>
        </div>

    </div>
    </template>
    
    <script>
    import xtimer from "./../../xtimer";
    
    export default {
        name: "Header",
        props: {
            BooleanNext: Boolean,
            BooleanAfter: Boolean,
            HerePage: String
        },
        data() {
            return {
                page_number  : this.$root.quiz_number,
                numberQuizOrPage: this.$root.quiz_number,
            };
        },
        methods: {
            run() {
                this.page_number = this.$root.quiz_number
            },
            nextlist() {
                let hp = this.HerePage
                let np = this.page_number
                let qt = this.$root.total[this.$root.quiz_revision-1]
                this.$root.isnext = this.$root.cookeiesRandom(22)
                if (hp == 'start') {
                    this.$root.timer = this.$root.loadtimer
                    this.$root.quiz_revision = 1
                    this.$root.quiz_faek = "separation"
                    this.$root.updateSave()
                    this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
                } else if (hp == 'separation') {
                    this.$root.timer = this.$root.loadtimer
                    this.$root.quiz_viwe[0] = 1
                    this.$root.quiz_faek = "quiz"
                    this.$root.faek_time.minute  = this.$root.quiz_time.minute
                    this.$root.faek_time.seconds = this.$root.quiz_time.minute
                    this.$root.quiz_number = (this.$root.quiz_number + 1)
                    this.$root.addtimers = true
                    this.$root.checkrefrsh = true
                    this.$root.updateSave()
                    this.$root.checkdate()
                    this.$router.push('/quiz/' + this.$root.app_rand).catch(err => {})
                    xtimer.xstop();
                } else if (hp == 'quiz') {
                    this.$root.loader = true
                    if (np > (qt - 1)) {
                        this.$root.quiz_faek = "revision"
                        this.$root.updateSave()
                        this.$router.push('/revision/'+ this.$root.app_rand)
                    } else {
                        this.$root.quiz_faek = "quiz"
                        this.$root.quiz_number = (this.$root.quiz_number + 1)
                        this.$root.updateSave()
                        this.$router.push('/quiz/' + this.$root.app_rand).catch(err => {})
                    }
                }

            },
            backlist () {
                let hp = this.HerePage
                this.$root.isnext = this.$root.cookeiesRandom(22)
                if (hp == 'quiz') {
                    this.$root.loader = true
                    this.$root.quiz_number = (this.$root.quiz_number - 1)
                    this.$root.updateSave()
                    this.$router.push('/quiz/' + this.$root.app_rand).catch(err => {})
                }
            }
        },
        watch: {
            '$root.quiz_number': function() {
                this.run()
            }
        }
    };
    </script>
    


// WEBPACK FOOTER //
// src/components/aps/Footer.vue