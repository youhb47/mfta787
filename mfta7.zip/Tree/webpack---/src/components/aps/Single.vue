<template>
<div class="m-0 p-0">
<DragCol dir="ltr" style="width: 100%; height: max-content">
    <template #left>
        <div class="sp_style pt-3 px-3">
            <h4 class="quiz_description_1 text-danger fontsizequiz">
                استيعاب المقروء
            </h4>
            <h5 class="quiz_description_2 text-danger fontsizequiz">
                السؤال التالي يتعلق بالنص المرفق , بعد السؤال هناك أربع اختيارات ,
                واحد منها صحيح المطلوب , هو قراءة النص بعناية , ثم اختيار الإجابة
                الصحيحة
            </h5>
            <h5 class="quiz_description_2 fontsizequiz">
                {{ name }}
            </h5>
        </div>
    </template>
    <template #right>
        <div class="sp_style pt-3 px-3" @onscroll="setscrolldown">
            <div class="sp_in_sp">
                <h4 class="quiz_description_1 mb-3 fontsizequiz">
                    <p :inner-html.prop="ask"></p>
                </h4>
                <form ref="anyName" class="fontsizequiz">
                    <div v-for="(value, index) in option" :key="index" 
                    class="form-check form-group mt-1 me-4 mb-3">
                        <input class="form-check-input float-end ms-2" type="radio" 
                        name="exampleRadios" :id="'exampleRadios' + page + 'q' + index" 
                        :value="'option' + page + 'q' + index" 
                        @click="checkbox(page, index)" :checked="joab[index]"/>
                        <label class="form-check-label" :for="'exampleRadios' + page + 'q' + index">
                            {{ value.name }}
                        </label>
                    </div>
                </form>
            </div>
        </div>
    </template>
</DragCol>
</div>
</template>

<script>
import jquery from "jquery";
import {
DragCol,
DragRow,
ResizeCol,
ResizeRow,
Resize
} from "vue-resizer";

export default {
name: "Single",
components: {
    DragCol,
    DragRow,
    ResizeCol,
    ResizeRow,
    Resize
},
data() {
    return {
        page  : 0,
        quiz  : [],
        joab  : [false, false, false, false],
        name  : '',
        ask   : '',
        option: []
    };
},
methods: {
    run() {
        if (this.$root.quiz_number != 0){
            let rev = this.$root.quiz_revision
            let tol = this.$root.quiz_total
            let qnr = this.$root.quiz_number
            this.$root.appSave()
            if (rev != 1) {
                this.page  = ((qnr - 1) + (tol * (rev - 1)))
            } else {
                this.page  = (qnr - 1)
            }
            this.quiz  = this.$root.quizs
            this.name  = this.quiz.questions[this.page].paragraph
            this.ask   = this.quiz.questions[this.page].name
            this.option= this.quiz.questions[this.page].options
            this.checkedis()

            // var scrollBottom = jquery('.sp_style').scrollTop() + jquery('.sp_style').height();
            // var scrollBottom = jquery(window).scrollTop() + jquery(window).height();
            // alert(scrollBottom)
        }
    },
    setscrolldown() {
        let sh = jquery('.drager_left').scrollHeight
        // alert(sh)
    },
    checkbox(i, b) {
        let barr = true
        let int = i, bnt = b
        let rev = this.$root.quiz_revision;
        let arr = {id: i, joab: bnt};
        let QJ;
        if (rev == 1) {
            QJ  = this.$root.quiz_joab.a;
        } else if (rev == 2) {
            QJ  = this.$root.quiz_joab.b;
        } else if (rev == 3) {
            QJ  = this.$root.quiz_joab.c;
        } else if (rev == 4) {
            QJ  = this.$root.quiz_joab.d;
        }
        for (let key = 0; key < QJ.length; key++) {
            if(QJ[key].id == int) {
                QJ[key].joab = bnt;
                barr = false
                break;
            }
        }
        if (barr) {
            QJ.push(arr);
        }
        if (rev == 1) {
            this.$root.quiz_joab.a = QJ;
        } else if (rev == 2) {
            this.$root.quiz_joab.b = QJ;
        } else if (rev == 3) {
            this.$root.quiz_joab.c = QJ;
        } else if (rev == 4) {
            this.$root.quiz_joab.d = QJ;
        }
        this.quizj = QJ
        this.checkedis()
        this.$root.updateSave()
    },
    checkedis() {
        this.joab = [false, false, false, false];
        let int   = this.page
        let rev = this.$root.quiz_revision;
        let arr;
        if (rev == 1) {
            arr  = this.$root.quiz_joab.a;
        } else if (rev == 2) {
            arr  = this.$root.quiz_joab.b;
        } else if (rev == 3) {
            arr  = this.$root.quiz_joab.c;
        } else if (rev == 4) {
            arr  = this.$root.quiz_joab.d;
        }
        let Qjb   = this.joab;
        for (let key = 0; key < arr.length; key++) {
            if(arr[key].id == int) {
                Qjb[arr[key].joab] = true
            }
        }
        this.joab = Qjb
    },
    run2() {
        if (this.$root.quiz_number != 0 && this.$root.loader == false) this.run()
    }
},
mounted() {
    this.run()
},
watch: {
    '$root.quizs.questions' : function() {
        if(this.$root.quiz_number != 0) {
            this.run()
        }},
    '$root.isnext': function() {
        if(this.$root.quiz_number != 0) {
            this.run()
        }}
}
};
</script>



// WEBPACK FOOTER //
// src/components/aps/Single.vue