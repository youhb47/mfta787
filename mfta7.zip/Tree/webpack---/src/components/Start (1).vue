var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"heyisnone"},[_c('Header',{attrs:{"BooleanTimer":false,"BooleanNumQuiz":false,"BooleanTagSave":false}}),_vm._v(" "),(_vm.$root.loader)?_c('Loader'):_vm._e(),_vm._v(" "),_vm._m(0),_vm._v(" "),_c('Footer',{attrs:{"HerePage":"start","BooleanNext":true,"BooleanAfter":false}})],1)}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"col-12 p-0 position-relative bodybody"},[_c('div',{staticClass:"col-12 p-0 text-center pt-3"},[_c('img',{attrs:{"src":require("../assets/icon/pearson.png"),"width":"300"}}),_vm._v(" "),_c('h3',[_vm._v("\n              مرحبا بك في اختبارات أكاديمية الحوت على الحاسب اآللي\n            ")]),_vm._v(" "),_c('p',[_vm._v("\n              سيتم بدء اإلختبار عند ضغط زر التالي في أسفل الشاشة\n            ")]),_vm._v(" "),_c('p',[_vm._v("\n              إضغط زر التالي للمتابعة\n            ")])])])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-b12bab5e","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/Start.vue
// module id = null
// module chunks = 