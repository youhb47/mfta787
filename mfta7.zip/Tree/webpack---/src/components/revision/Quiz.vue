<template>
    <div class="heyisnone">
      <div class="row m-0">
        <!-- b header -->
        <Header
          :BooleanTimer="true"
          :BooleanNumQuiz="true"
          :BooleanTagSave="true"
        />
        <!-- e header -->
  
        <div class="col-12 p-0 position-relative">
          <!-- b loader -->
          <Loader v-if="$root.loader" />
          <!-- e loader -->
  
          <!-- b quiz -->
          <Single />
          <!-- e quiz -->
        </div>
  
        <!-- b footer -->
        <Footer HerePage="quiz" :BooleanNext="true" :BooleanAfter="true" />
        <!-- e footer -->
      </div>      
      <div class="modal fade" @mousedown="dragElement('statictime')" id="statictime" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog" id="statictimeheader">
                <div class="modal-content border-0 rounded-0">
                <div class="modal-header py-1">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">
                        <i class="fa-regular fa-clock"></i>
                        تبقى خمس دقائق
                    </h1>
                </div>
                <div class="modal-body row">
                    <div class="col-1">
                        <img src="@/assets/icon/information.png" >
                    </div>
                    <div class="col-11">
                        <p>
                            لديك 5 دقائق فقط لإنهاء هذا القسم
                        </p>
                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" @click="poplow" class="btn btn-secondary rounded-0 border-1 border-white">
                    حسناُ
                    </button>
                </div>
                </div>
            </div>
        </div>

        
      <div class="modal fade" @mousedown="dragElement('staticendtime')" id="staticendtime" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog" id="staticendtimeheader">
                <div class="modal-content border-0 rounded-0">
                <div class="modal-header py-1">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">
                        <i class="fa-regular fa-clock"></i>
                        انتهى الوقت
                    </h1>
                </div>
                <div class="modal-body row">
                    <div class="col-1">
                        <img src="@/assets/icon/information.png" >
                    </div>
                    <div class="col-11">
                        <p>
                          إنتهت المدة المسموحة لحل القسم - إضغط موافق للمتابعة
                        </p>
                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" @click="nextlist" class="btn btn-secondary rounded-0 border-1 border-white">
                    موافق
                    </button>
                </div>
                </div>
            </div>
        </div>
    </div>
  </template>
    
    <script>
    import jQuery from 'jquery'
  // import xtimer from "../../xtimer";
  import xdate from "../../xdate";
  import Header from "./Header";
  import Single from "./Single";
  import Footer from "./Footer";
  import Loader from "../aps/Loader";
  
  export default {
    name: "Quiz",
    components: {
      Header,
      Single,
      Footer,
      Loader,
    },
    data() {
      return {
        number_page: this.$root.quiz_number,
        minute: 5,
        seconds: this.$root.faek_time.seconds,
        date: this.$root.thatdatea,
        timer: this.$root.timer
      };
    },
    methods: {
      async run() {
        await xdate.xstop();
        await this.$root.appSave()
        if (this.$root.quiz_revision == 1) {
          this.date = this.$root.thatdatea
        } else if (this.$root.quiz_revision == 2) {
          this.date = this.$root.thatdateb
        } else if (this.$root.quiz_revision == 3) {
          this.date = this.$root.thatdatec
        } else if (this.$root.quiz_revision == 4) {
          this.date = this.$root.thatdated
        }
        this.floader();
        xdate.xstart(this);
        this.$root.updateSave()
        this.thistime()
      },
      floader() {
        setInterval(() => {
          this.$root.loader = false;
        }, 500);
      },
    nextlist() {
      if (this.timer == "00:00") {
          xdate.xstop();
            let qr = this.$root.quiz_revision
            this.$root.quiz_faek = 'separation'
            this.$root.quiz_number = 0
            if (qr == 1) {
                this.$root.quiz_revision = 2
                this.$root.updateSave()
                this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
            } else if (qr == 2) {
                this.$root.quiz_revision = 3
                this.$root.updateSave()
                this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
            } else if (qr == 3) {
                this.$root.quiz_revision = 4
                this.$root.updateSave()
                this.$router.push('/separation/' + this.$root.app_rand).catch(err => {})
            } else if (qr == 4) {
                this.$root.quiz_faek = "end"
                this.$root.quiz_revision = 5
                this.$root.updateSave()
                this.$router.push({ name: 'End', path: '/end' }).catch(err => {})
            }
      }
    },
        dragElement(event) {
            var elmnt = document.getElementById(event)
            var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
            if (document.getElementById(elmnt.id + "header")) {
                // if present, the header is where you move the DIV from:
                document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
            } else {
                // otherwise, move the DIV from anywhere inside the DIV:
                elmnt.onmousedown = dragMouseDown;
            }

            function dragMouseDown(e) {
                e = e || window.event;
                e.preventDefault();
                // get the mouse cursor position at startup:
                pos3 = e.clientX;
                pos4 = e.clientY;
                document.onmouseup = closeDragElement;
                // call a function whenever the cursor moves:
                document.onmousemove = elementDrag;
            }

            function elementDrag(e) {
                e = e || window.event;
                e.preventDefault();
                // calculate the new cursor position:
                pos1 = pos3 - e.clientX;
                pos2 = pos4 - e.clientY;
                pos3 = e.clientX;
                pos4 = e.clientY;
                // set the element's new position:
                elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
                elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
            }

            function closeDragElement() {
                // stop moving when mouse button is released:
                document.onmouseup = null;
                document.onmousemove = null;
            }
            },
        openModal(event) {
            jQuery(event).attr('class', 'modal fade show');
            jQuery(event).attr('style', 'display: block; padding-left: 0px;');
        },
        closeModal(event) {
            jQuery(event).attr('class', 'modal fade');
            jQuery(event).attr('style', '');
        },
        thistime() {
          if (this.minute == 0 && this.seconds == 0) {
            xdate.xstop();
            jQuery('p#clock').html('<i class="fa-regular fa-clock"></i> انتهى الوقت')
          }
        },
        poplow () {
          this.$root.popsendtime = false
          this.$root.updateSave()
          closeModal('#statictime')
        }
    },
    mounted() {
      this.run();
    },
    watch: {
      '$root.quiz_number': "run",
      'timer': function () {
        this.$root.faek_time.minute  = this.minute
        this.$root.faek_time.seconds = this.seconds
        this.$root.timer = this.timer
      if (this.minute < 5) {
        if (this.$root.pops && this.$root.popsendtime) {
          this.$root.pops = false
          this.openModal('#statictime')
        }
        this.thistime()
        jQuery('p#clock').attr('style', 'color:yellow !important;')
      }
      
      if (this.timer == "00:00") {
        this.openModal('#staticendtime')
      }
        this.$root.updateSave()
      },
    },
  };
  </script>


// WEBPACK FOOTER //
// src/components/revision/Quiz.vue