webpackJsonp(
  [1],
  {
    "+MlX": function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAK6wAACusBgosNWgAAABh0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzT7MfTgAAABZ0RVh0Q3JlYXRpb24gVGltZQAwMy8wNC8wOK6M4pgAAAjMSURBVFiFpZdrjFXVFcd/e+9z7mNmmAFmhhkQpCMoIA9RMTGIVlONURMVnymp6cvYmLZ+aBMpVtvYGlCTJk0T0y98aIuxrYDYGNvU2ho1EKtERYuOvIUCAwzM8557ztl7r90PZ+YyYGwwrmTlnNx79vr/93+t/VgqhMC5mpr54CJmdKwyXW0rvQ/zS6UICOS5xxjV648NbeFo/3Ph0G//c84xz4WAuuYXt03tnnLfZfNmLF86t3vahbM6zPSpLZRjA0BqPUdPjbL7YL9/f0/f8Xd3Hdk2cGxgQ3j9Z3/5UgTUNY9fN3l6+9O3rliw7K6vXszCni6iWFPPhdQKLgQICq0C5cjQVNI459m57xib3/iIl7b2bh/sO/lweP3nr31hAur6tWuvuuKiNT+69yoWzplO33DKYGIRFForjFYoIADeB5wIXgStYGpTTHdrhZ37+vj181vZ9s7udeHVRx45JwJf+/rj+rXhpudX3XT5nT+8ewUnapbjIxlaK8qRITaKyGhiozFa4SWQO8GJ4LxgvZC5gIjQ1VpmWnPMM5u28qe/v7v5xsnunr8+u0Ym4kVnM3p9tHnjt2+/8o5VN1/B9kPDWBEqsaGkFFYCYWzW5XLEwGiKl8CkpjK2nmF9wPqAl+K563iN/UZx323LKZVLd2546d8bgTs/VwF105Nrb7v+sjWrbl1O79FhjFZUIkNkFLHRjZlXyzGvv/0x1EYIQSFNLVx9xTySNMdJwI4p4XwgtR4vgYtntPLHl97i5X+9t07+tvqRzxCIbnhixYJFc9588Bs3sP9UHaMV5agALFwRaU1zU5m3d+xlYdXy0O3LAPjNi9v5oBaxbEkPo0neSIVtpETwEuhpb2L9c6/Su3PfCvePR7cC6ILHL5k0te2Za1dcQm9/wmjuSJ2QWKFuPYkt3hMnjGSegf4BHrhxcUO5B25czODJAUYyoW5PezIWI3XCaOboPZFw9VVLmDR18jN8uJ4GgcrN0S0XzJ21RFomcXw4HQP3JLmnZoUk9yS5UMt9QUgU+48NNgjs7xskEUVqhZr1DU9y34iTOuH4cIqvtjDngvMuqfyk/5ZGEVZaWu7vOn8GB08lRAQkQBwFYhOIpXhGXoiMxkrOrDmzWbPxfb67oocQYP3W/cyafxGDSYZ1fqwYJ6TBCdZ7ch84fKpG98xu9u49dD/wspq9cu1C6Zzx2sIrL+9MJFCKNKXxvI/VQKRPL72AIijFSJJx4MARQNHTM4PO1ipJmuMlTFiSAes91gm5L37Delo0fPDOjhN64Ni10ZBE32xvau5IMk8qQu4NJSNEkabkDZEpZh7rgPOWk598wqKZU4gzx4JWAyhO7dnFh9U2Zs4+jzSzZ6yEiY4TtLUkSlNuauo40W++FalSvBJTUkmSYRWID6SRJvaBWBeKxKZIQ+48w4llXkeVh269FFAA9O7v464/fEBzt8NlHgnF7HPnycfAxQnaebRzeAGlY6XjeGU0ULNzpwRFPclwWiNxgMgQRZpYa0IOXsAFECA770Iee3U39y6fQ1dH29hi1vTVHCN9oyjn0SpgFEQaQoDgBZxD5Q7jPE4EEcVALZ8boQ3WBVTd4o0m+IA3Qj1AXUBCQKti242MwsSgSzEjdUtXYzeBzHkkdbjcFpuQCBKgRKBFQVUJsfc469He46yA1kRoTW4F6hnOGOqJowZYpSE2YAyxCUjQSFAoHMGdsZ2jAOcFbz3Be5wEvA8E78msI7OesgjNOlAhEDlP7hoEIHWCG02pK43TZiwFhkBAQsCKwemA1gpEYbyg1JlnSO6FYD04IYigvGCcQ3mP9kJwjpr15N5TEcFGgFZEnS2lPUMic8upQGwwUWgABwkoEYIRRCu81iBFTifiK6UQL5BbtHNoEZT3KC9o71FO0M6hnCdYh7WeekuJzpbSHl2x9S2iCVopjLVo6wp3Dm0tOnfoLMfkDpNZyGwRaIIEAdDOozKLzsfdnY41Ia5xDqU03hAqNt2i50f136uQ97tqFZNmxYe5K4JMGGxyW3iWo70/U38Fyvnif+sw42BnE3EOU89wzU0obP/8uP47/cqzj+6sJENb05Yq2kmhgnOYMRLjwAWh4l05z5lFoNDeozOLzvLGuALcnlY0d2gv1NuaqSRDW1/Z8NOPNMC0bGi9uFFsVxdRrT4BbIIaWY7JLDrPCwJnWaFAPvbtacKN8bkjqiXk06fjfY1p2fD6xmm4d9OUl5tPHN4x2t1OKJUx9fQ0+3EVrMNYi9RysiSlWo4b4M3VmDxJkSQjGvtuYtq0dZh6SqhUGJnRSfOJwzv2bOp8uUEg8D1m28Ef6CP7GL50STEgzdD5hDzmFp9kdEY1Hr93CTPaJzUIzOxo47G7FzOtVMclKTo7nQI1Hss6hi9fij66j9l28PvwnUK5iVey6SufXtvXs3hNua2Ltje2gQIpl4uK14rUCbNnlbj+0vMZSnLGhyoFbU0l/vneQQ58mlKNDIiACCbLURIYuHYF2chxuvd/uO7oloc/eyUbt447frX55IVL74gndzH5zW1Ew6P4aoVgNGhN5jyjmftsDYRAcymiEhuCFAePSVJcawuD164gHzxG++73X+h/4ceffykFoHej7ljz6fMney6+U31lPq07dtK0aw/Ke3wpBmMIenwFjHcGoAIQAso6dJ4TjKE+70KGli4i7O+l/cBHm/vXzb6H+XfL/ycwZt23P7n25NRZa9zCpUTB0PzxbioHD2FGaigpYgRdHHcqhOLY0xrX0kw6exa1BRfhtBDtfI/2U/9d1/fi6nNrTCbawnueuu6QVJ6uTe9ZJudfAJUmSsOjxCdPEQ2NoLMcCEi5jGubhG2fgm2dREgT9MG9NB85sH1WlD6888+rv3hrNtHm3vXUbSdC+b60rWO5m9IxTVonGypViMb6GucgraOHB3080H+8PNS/rVNlG/ZsWv3lmtOz7co7Hl102FZWSam68mjdzw+6IKDEMb1qenVe33JenD731gtPnHN7/j9rjK5Ot/7g1gAAAABJRU5ErkJggg==";
    },
    "0vKA": function (t, e, i) {
      "use strict";
      var o = {
          name: "Resize",
          props: {
            sliderWidth: { type: Number, default: 20 },
            height: { type: Number, default: 400 },
            width: { type: Number, default: 400 },
            sliderColor: { type: String, default: "#6f808d" },
            sliderBgColor: { type: String, default: "#1f2e3a" },
            sliderHoverColor: { type: String, default: "#6f808d" },
            sliderBgHoverColor: { type: String, default: "#16222a" },
          },
          data: function () {
            return {
              reWidth: this.width,
              reHeight: this.height,
              isDragging: !1,
            };
          },
          methods: {
            mobileResizeRow: function (t) {
              (document.body.style.overflow = "hidden"),
                (document.body.style.overscrollBehaviorY = "contain"),
                (t = t || window.event).stopPropagation();
              var e = t.changedTouches[0].clientY,
                i = this.reHeight,
                o = 0,
                s = 0,
                n = this;
              (this.isDragging = !0),
                this.$emit("isDraggingRow", this.isDragging),
                (document.ontouchmove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).stopPropagation(),
                    (o = t.changedTouches[0].clientY),
                    (s = parseInt(i - (e - o))) <= 20
                      ? (n.reHeight = 20)
                      : (n.reHeight = s);
                  n.$emit("draggingRow", n.reHeight);
                }),
                (document.ontouchend = function () {
                  (n.isDragging = !1),
                    n.$emit("isDraggingRow", n.isDragging),
                    (document.body.style.overflow = ""),
                    (document.body.style.overscrollBehaviorY = ""),
                    (document.ontouchmove = null),
                    (document.ontouchend = null);
                });
            },
            resizeRow: function (t) {
              (t = t || window.event).preventDefault(), t.stopPropagation();
              var e = t.clientY,
                i = this.reHeight,
                o = 0,
                s = 0,
                n = this;
              (this.isDragging = !0),
                this.$emit("isDraggingRow", this.isDragging),
                (document.onmousemove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).preventDefault(),
                    t.stopPropagation(),
                    (o = t.clientY),
                    (s = parseInt(i - (e - o))) <= 20
                      ? (n.reHeight = 20)
                      : (n.reHeight = s);
                  n.$emit("draggingRow", n.reHeight);
                }),
                (document.onmouseup = function () {
                  (n.isDragging = !1),
                    n.$emit("isDraggingRow", n.isDragging),
                    (document.onmouseup = null),
                    (document.onmousemove = null);
                });
            },
            mobileResizeCol: function (t) {
              (t = t || window.event).stopPropagation();
              var e = t.changedTouches[0].clientX,
                i = this.reWidth,
                o = 0,
                s = 0,
                n = this;
              (this.isDragging = !0),
                this.$emit("isDraggingCol", this.isDragging),
                (document.ontouchmove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).stopPropagation(),
                    (o = t.changedTouches[0].clientX),
                    (s = parseInt(i - (e - o))) <= 20
                      ? (n.reWidth = 20)
                      : (n.reWidth = s);
                  n.$emit("draggingCol", n.reWidth);
                }),
                (document.ontouchend = function () {
                  (n.isDragging = !1),
                    n.$emit("isDraggingCol", n.isDragging),
                    (document.ontouchmove = null),
                    (document.ontouchend = null);
                });
            },
            resizeCol: function (t) {
              (t = t || window.event).preventDefault(), t.stopPropagation();
              var e = t.clientX,
                i = this.reWidth,
                o = 0,
                s = 0,
                n = this;
              (this.isDragging = !0),
                this.$emit("isDraggingCol", this.isDragging),
                (document.onmousemove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).preventDefault(),
                    t.stopPropagation(),
                    (o = t.clientX),
                    (s = parseInt(i - (e - o))) <= 20
                      ? (n.reWidth = 20)
                      : (n.reWidth = s);
                  n.$emit("draggingCol", n.reWidth);
                }),
                (document.onmouseup = function () {
                  (n.isDragging = !1),
                    n.$emit("isDraggingCol", n.isDragging),
                    (document.onmouseup = null),
                    (document.onmousemove = null);
                });
            },
          },
        },
        s = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              {
                staticClass: "resize",
                style: { height: t.reHeight + "px", width: t.reWidth + "px" },
              },
              [
                i("div", { staticClass: "resize_body" }, [t._t("default")], 2),
                t._v(" "),
                i("div", {
                  staticClass: "slider_row",
                  style: { height: t.sliderWidth + "px" },
                  on: {
                    "&touchstart": function (e) {
                      return t.mobileResizeRow.apply(null, arguments);
                    },
                    mousedown: t.resizeRow,
                  },
                }),
                t._v(" "),
                i("div", {
                  staticClass: "slider_col",
                  style: { width: t.sliderWidth + "px" },
                  on: {
                    "&touchstart": function (e) {
                      return t.mobileResizeCol.apply(null, arguments);
                    },
                    mousedown: t.resizeCol,
                  },
                }),
              ]
            );
          },
          staticRenderFns: [],
        };
      var n = i("VU/8")(
        o,
        s,
        !1,
        function (t) {
          i("oAf7");
        },
        null,
        null
      );
      e.a = n.exports;
    },
    "4R21": function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAYAAADE6YVjAAAACXBIWXMAAAsTAAALEwEAmpwYAAAF8WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDMgNzkuMTY0NTI3LCAyMDIwLzEwLzE1LTE3OjQ4OjMyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjIuMSAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIzLTAxLTEyVDIwOjE3OjAzKzAyOjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIzLTAxLTEyVDIwOjE3OjAzKzAyOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMy0wMS0xMlQyMDoxNzowMyswMjowMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDozMDJmNWMzZi1jNGVkLWRmNDMtOTY2NS02OWNjMWZiNDk0ZTciIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDpmNWU4NzZiNi1lNTA3LTMxNDctOGQ4NS0xMjE2N2FkZjI1NTciIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpiNDgxMDRkMS0xOTkzLTdlNDAtOWYwMS1mOTYxNjNhYTQ4NjkiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmI0ODEwNGQxLTE5OTMtN2U0MC05ZjAxLWY5NjE2M2FhNDg2OSIgc3RFdnQ6d2hlbj0iMjAyMy0wMS0xMlQyMDoxNzowMyswMjowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDIyLjEgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDozMDJmNWMzZi1jNGVkLWRmNDMtOTY2NS02OWNjMWZiNDk0ZTciIHN0RXZ0OndoZW49IjIwMjMtMDEtMTJUMjA6MTc6MDMrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMi4xIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7IgMe/AAAA2ElEQVRIie2VrQoCQRSFvxEXfAN9ilUQrIpR9CV8JYNgNG80Wq1i1WCwmA1ikOUYdsP+zarIKMgemHLvzHxw750zRhKuVXNOeALpAXPgAFyAExAAkyd3bnIRSUVrqXKtJfULzrUknbNxY+nJDWi8UIlNvO5AFxjE50xy06cQm1KQnze+glSQz1QvyYnooQXAEWgCI2AMeG9RLLaylTSUZApyvqSVpNBiOeGrtuIRWYVNhshAp4AfV2QPLIAZ0E5tdvCf7IBOMvA/01VBfg65ZgMuRjinr5TrAYXzzi2DkrArAAAAAElFTkSuQmCC";
    },
    I9NY: function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAYAAADE6YVjAAAACXBIWXMAAAsTAAALEwEAmpwYAAAF8WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDMgNzkuMTY0NTI3LCAyMDIwLzEwLzE1LTE3OjQ4OjMyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjIuMSAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIzLTAxLTEyVDIwOjE2OjU0KzAyOjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIzLTAxLTEyVDIwOjE2OjU0KzAyOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMy0wMS0xMlQyMDoxNjo1NCswMjowMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1MmIzZGY3ZS04ZjQ2LWNhNDYtOWY0NS05OGQ2NDMxMDk3YmQiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDpkM2UxNzNkYi1hZWU4LWI1NDEtYWJjZi04ZWU4NGZmNDc0ODgiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo2NjRlMTc0MS0wMThlLTk4NDItYWMxMi1lOTA2MDQ4Zjc1ZjYiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjY2NGUxNzQxLTAxOGUtOTg0Mi1hYzEyLWU5MDYwNDhmNzVmNiIgc3RFdnQ6d2hlbj0iMjAyMy0wMS0xMlQyMDoxNjo1NCswMjowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDIyLjEgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1MmIzZGY3ZS04ZjQ2LWNhNDYtOWY0NS05OGQ2NDMxMDk3YmQiIHN0RXZ0OndoZW49IjIwMjMtMDEtMTJUMjA6MTY6NTQrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMi4xIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5rPE3xAAAB4UlEQVRIie2WQWsTQRiGny/Zdtu0jTUuaUzaVIKlXvTQFjyKKOgPEDyJelTQUy+CPYgnPSgqetQfoHgSQSH2IuJB0UvxUJUaisYUG43Z3bhd9vNSYdumSYpWIfjCHOb9PuaZ4Z2BEVVlsxXZdAJg1DPl7F0O66eTFt6kxY+RGL7hEQm+YBYXMO88kPTUegue0reVWzfOxZtCjuvcuxzVXNgzCaJ9+Jkd2OfT6p6eJ3bhoWy/Hu45oJ/39OH3tHSSLHYO4BkWr6SfCh2YBOzmG2NaJoObyOBeG1b74lc63wTgx/FHU7iWwdqM60J+6YkkWVqOrUaUp1g8l23s0xKjfCdFLZ6itrfRGk0h9eQj5GWAPANkcchiEwE+0s0xnfszkLAKxCgQa9r3V65w+0AaZjJClWG1SeBRxeCD9DBLL/YGo2zYfVQLK+ZjWgbgJVt5LClqRH8PokCRrkqJrrxHZMZAswm8g4M46XHKjGuZFyR4Lf0ECLu0sjFImU73Pb1TLtGr05IMwrVDWjwyhHNzECc5wSITurhmcy1BZthiTUvSqVd7JKl7+7V0f57uExbeZJylIUGlSsdCCfPKTqqXW4KsBwjVA+D28lihMzp7abXXPu/kP+TfQnzEX+1J23yJfgKE/57ADH6GPAAAAABJRU5ErkJggg==";
    },
    JSUG: function (t, e, i) {
      t.exports = i.p + "static/img/pearson.298b266.png";
    },
    Jyjj: function (t, e) {},
    LVeW: function (t, e) {},
    NHnr: function (t, e, i) {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 });
      var o = i("mvHQ"),
        s = i.n(o),
        n = i("Xxa5"),
        a = i.n(n),
        r = i("exGp"),
        u = i.n(r),
        c = i("7+uW"),
        l = {
          render: function () {
            var t = this.$createElement,
              e = this._self._c || t;
            return e("div", { attrs: { id: "app" } }, [e("router-view")], 1);
          },
          staticRenderFns: [],
        },
        d = i("VU/8")({ name: "App" }, l, !1, null, null, null).exports,
        h = i("/ocq"),
        m = i("7t+N"),
        p = i.n(m),
        v = i("4R21"),
        f = i.n(v),
        _ = i("j8xc"),
        g = i.n(_),
        b = {
          name: "Header",
          props: {
            BooleanTimer: Boolean,
            BooleanNumQuiz: Boolean,
            BooleanTagSave: Boolean,
          },
          data: function () {
            return {
              TgImage: f.a,
              TsImage: g.a,
              xselected: 18,
              number_page: this.$root.quiz_number,
            };
          },
          methods: {
            run: function () {
              (this.number_page = this.$root.quiz_number),
                (this.xselected = this.$root.fontsizequiz),
                this.arrSave();
            },
            funSave: function () {
              var t = !0,
                e = void 0,
                i = this.$root.quiz_revision,
                o = this.$root.quiz_total,
                s = {
                  id: (e =
                    1 != i
                      ? this.$root.quiz_number - 1 + o * (i - 1)
                      : this.$root.quiz_number - 1),
                  tag: !0,
                },
                n = void 0;
              1 == i
                ? (n = this.$root.quiz_tags.a)
                : 2 == i
                ? (n = this.$root.quiz_tags.b)
                : 3 == i
                ? (n = this.$root.quiz_tags.c)
                : 4 == i && (n = this.$root.quiz_tags.d);
              for (var a = 0; a < n.length; a++)
                if (n[a].id == e) {
                  n[a].tag ? (n[a].tag = !1) : (n[a].tag = !0), (t = !1);
                  break;
                }
              t && n.push(s),
                1 == i
                  ? (this.$root.quiz_tags.a = n)
                  : 2 == i
                  ? (this.$root.quiz_tags.b = n)
                  : 3 == i
                  ? (this.$root.quiz_tags.c = n)
                  : 4 == i && (this.$root.quiz_tags.d = n),
                this.arrSave();
            },
            tag: function () {
              var t = void 0,
                e = void 0,
                i = this.$root.quiz_revision,
                o = this.$root.quiz_total;
              (t =
                1 != i
                  ? this.$root.quiz_number - 1 + o * (i - 1)
                  : this.$root.quiz_number - 1),
                1 == i
                  ? (e = this.$root.quiz_tags.a)
                  : 2 == i
                  ? (e = this.$root.quiz_tags.b)
                  : 3 == i
                  ? (e = this.$root.quiz_tags.c)
                  : 4 == i && (e = this.$root.quiz_tags.d);
              for (var s = 0; s < e.length; s++)
                if (e[s].id == t && e[s].tag) return f.a;
              return g.a;
            },
            arrSave: function () {
              var t = this.$root.quiz_revision,
                e = void 0,
                i = [];
              1 == t
                ? (e = this.$root.quiz_tags.a)
                : 2 == t
                ? (e = this.$root.quiz_tags.b)
                : 3 == t
                ? (e = this.$root.quiz_tags.c)
                : 4 == t && (e = this.$root.quiz_tags.d);
              for (var o = 0; o < e.length; o++) e[o].tag && i.push(e[o]);
              1 == t
                ? (this.$root.quiz_tags.a = i)
                : 2 == t
                ? (this.$root.quiz_tags.b = i)
                : 3 == t
                ? (this.$root.quiz_tags.c = i)
                : 4 == t && (this.$root.quiz_tags.d = i),
                this.$root.updateSave();
            },
            FunNumQuiz: function (t) {
              p()(t).toggleClass("active");
            },
            vselected: function () {
              (this.$root.fontsizequiz = this.xselected),
                this.$root.updateSave(),
                p()("style#one").html(
                  ".fontsizequiz {font-size: " +
                    this.xselected +
                    "px!important;}"
                );
            },
            checkselected: function () {
              this.xselected = this.$root.fontsizequiz;
            },
          },
          mounted: function () {
            this.tag();
          },
          watch: {
            xselected: "vselected",
            "$root.fontsizequiz": "checkselected",
            "$root.quiz_number": function () {
              this.run(), this.tag();
            },
          },
        },
        z = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i("div", { staticClass: "m-0 p-0" }, [
              i(
                "div",
                {
                  staticClass:
                    "col-12 header d-flex flex-column flex-md-row flex-lg-row flex-xl-row py-3 px-2 justify-content-between align-items-center bg-DarkBlueOldColor p-1",
                },
                [
                  t._m(0),
                  t._v(" "),
                  i(
                    "div",
                    {
                      staticClass:
                        "mt-2 mt-md-0 mt-lg-0 mt-xl-0 d-flex flex-column align-items-start align-items-md-end align-items-lg-end align-items-xl-end col-md-6 col-lg-6 col-12",
                    },
                    [
                      t.BooleanTimer
                        ? i(
                            "p",
                            {
                              staticClass: "textquiz m-0 f-12 text-white",
                              attrs: { id: "clock" },
                              on: {
                                click: function (e) {
                                  return t.FunNumQuiz("p#clock");
                                },
                              },
                            },
                            [
                              i("i", { staticClass: "fa-regular fa-clock" }),
                              t._v(
                                "\r\n                الوقت المتبقي \r\n                "
                              ),
                              i("b", {
                                domProps: { innerHTML: t._s(t.$root.timer) },
                              }),
                            ]
                          )
                        : t._e(),
                      t._v(" "),
                      i("div", [
                        t.BooleanNumQuiz
                          ? i(
                              "p",
                              {
                                staticClass: "textquiz m-0 f-12 mt-1",
                                attrs: { id: "quiznumbers" },
                                on: {
                                  click: function (e) {
                                    return t.FunNumQuiz("p#quiznumbers");
                                  },
                                },
                              },
                              [
                                i("i", { staticClass: "fa-solid fa-scroll" }),
                                t._v(" "),
                                i("span", [t._v(t._s(t.number_page))]),
                                t._v(
                                  "\r\n                    من\r\n                    "
                                ),
                                i("span", [
                                  t._v(
                                    "\r\n                        " +
                                      t._s(
                                        t.$root.total[t.$root.quiz_revision - 1]
                                      ) +
                                      "\r\n                    "
                                  ),
                                ]),
                              ]
                            )
                          : t._e(),
                      ]),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass:
                    "col-12 downTag align-items-center justify-content-start justify-content-md-end justify-content-lg-end justify-content-xl-end bg-BlueOldColor py-2 px-4",
                },
                [
                  t.BooleanTagSave
                    ? i("div", [
                        i(
                          "button",
                          {
                            staticClass:
                              "btn cursor_pointer text-white m-0 px-3",
                            attrs: { type: "button" },
                            on: { click: t.funSave },
                          },
                          [
                            i("img", {
                              staticClass: "clock_img",
                              attrs: { src: t.tag(), alt: "img" },
                            }),
                            t._v(
                              "\r\n            تميز السؤال للمراجعة\r\n            "
                            ),
                          ]
                        ),
                        t._v(" "),
                        i(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: t.xselected,
                                expression: "xselected",
                              },
                            ],
                            staticClass:
                              "d-inline-block form-select form-select-sm rounded-0 w-auto",
                            staticStyle: {
                              "background-color": "#588cc5",
                              color: "white",
                            },
                            on: {
                              change: function (e) {
                                var i = Array.prototype.filter
                                  .call(e.target.options, function (t) {
                                    return t.selected;
                                  })
                                  .map(function (t) {
                                    return "_value" in t ? t._value : t.value;
                                  });
                                t.xselected = e.target.multiple ? i : i[0];
                              },
                            },
                          },
                          [
                            i("option", [
                              t._v(
                                "\r\n                    تغيير حجم الخط\r\n                "
                              ),
                            ]),
                            t._v(" "),
                            t._l([18, 20, 24, 26], function (e, o) {
                              return i(
                                "option",
                                {
                                  key: o,
                                  domProps: {
                                    value: e,
                                    selected: t.xselected == e,
                                  },
                                },
                                [
                                  t._v(
                                    "\r\n                    " +
                                      t._s(e) +
                                      "\r\n                "
                                  ),
                                ]
                              );
                            }),
                          ],
                          2
                        ),
                      ])
                    : t._e(),
                ]
              ),
            ]);
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "div",
                { staticClass: "col-md-6 col-lg-6 col-12 text-end" },
                [
                  e("strong", { staticClass: "m-0 increase_font" }, [
                    this._v("إختبار أكاديمية الحوت على الحاسب الآلي"),
                  ]),
                  this._v("\r\n            أحمد إبراهيم عادل\r\n        "),
                ]
              );
            },
          ],
        },
        $ = i("VU/8")(b, z, !1, null, null, null).exports,
        q = void 0,
        w = {
          xstart: function (t) {
            var e = t.minute,
              i = t.seconds;
            q = setInterval(function () {
              0 == e && 0 == i
                ? (t.timer = "00:00")
                : (i < 11
                    ? 0 == i
                      ? ((e -= 1), (i = 59))
                      : (i = "0" + (i - 1))
                    : (i -= 1),
                  (t.minute = e),
                  (t.seconds = i),
                  (t.timer = (e < 10 ? "0" + e : e) + ":" + i));
            }, 1e3);
          },
          xstop: function () {
            clearInterval(q);
          },
        },
        x = {
          name: "Header",
          props: {
            BooleanNext: Boolean,
            BooleanAfter: Boolean,
            HerePage: String,
          },
          data: function () {
            return {
              page_number: this.$root.quiz_number,
              numberQuizOrPage: this.$root.quiz_number,
            };
          },
          methods: {
            run: function () {
              this.page_number = this.$root.quiz_number;
            },
            nextlist: function () {
              var t = this.HerePage,
                e = this.page_number,
                i = this.$root.total[this.$root.quiz_revision - 1];
              (this.$root.isnext = this.$root.cookeiesRandom(22)),
                "start" == t
                  ? ((this.$root.timer = this.$root.loadtimer),
                    (this.$root.quiz_revision = 1),
                    (this.$root.quiz_faek = "separation"),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : "separation" == t
                  ? ((this.$root.timer = this.$root.loadtimer),
                    (this.$root.quiz_viwe[0] = 1),
                    (this.$root.quiz_faek = "quiz"),
                    (this.$root.faek_time.minute = this.$root.quiz_time.minute),
                    (this.$root.faek_time.seconds =
                      this.$root.quiz_time.minute),
                    (this.$root.quiz_number = this.$root.quiz_number + 1),
                    (this.$root.addtimers = !0),
                    (this.$root.checkrefrsh = !0),
                    this.$root.updateSave(),
                    this.$root.checkdate(),
                    this.$router
                      .push("/quiz/" + this.$root.app_rand)
                      .catch(function (t) {}),
                    w.xstop())
                  : "quiz" == t &&
                    ((this.$root.loader = !0),
                    e > i - 1
                      ? ((this.$root.quiz_faek = "revision"),
                        this.$root.updateSave(),
                        this.$router.push("/revision/" + this.$root.app_rand))
                      : ((this.$root.quiz_faek = "quiz"),
                        (this.$root.quiz_number = this.$root.quiz_number + 1),
                        this.$root.updateSave(),
                        this.$router
                          .push("/quiz/" + this.$root.app_rand)
                          .catch(function (t) {})));
            },
            backlist: function () {
              var t = this.HerePage;
              (this.$root.isnext = this.$root.cookeiesRandom(22)),
                "quiz" == t &&
                  ((this.$root.loader = !0),
                  (this.$root.quiz_number = this.$root.quiz_number - 1),
                  this.$root.updateSave(),
                  this.$router
                    .push("/quiz/" + this.$root.app_rand)
                    .catch(function (t) {}));
            },
          },
          watch: {
            "$root.quiz_number": function () {
              this.run();
            },
          },
        },
        y = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              {
                staticClass:
                  "row footer w-100 m-0 w-100 py-1 quiz_footer justify-content-between align-items-center bg-DarkBlueOldColor justify-content-center",
              },
              [
                i(
                  "div",
                  { staticClass: "py-0 col-4 d-flex justify-content-start" },
                  [
                    null != t.page_number && t.BooleanAfter
                      ? i(
                          "button",
                          {
                            staticClass:
                              "rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white",
                          },
                          [t._m(0)]
                        )
                      : t._e(),
                  ]
                ),
                t._v(" "),
                i(
                  "div",
                  { staticClass: "py-0 d-flex justify-content-end col-8" },
                  [
                    1 != t.page_number &&
                    null != t.page_number &&
                    t.BooleanAfter
                      ? i(
                          "button",
                          {
                            staticClass:
                              "rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link",
                            attrs: { disabled: t.$root.loader },
                            on: { click: t.backlist },
                          },
                          [t._m(1)]
                        )
                      : t._e(),
                    t._v(" "),
                    t.BooleanNext
                      ? i(
                          "button",
                          {
                            staticClass:
                              "rounded-0 border-end border-2 btn btn-link py-2 text-decoration-none text-white",
                            attrs: { disabled: t.$root.loader },
                            on: { click: t.nextlist },
                          },
                          [t._m(2)]
                        )
                      : t._e(),
                  ]
                ),
              ]
            );
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("h6", { staticClass: "cursor_pointer my-0" }, [
                e("i", { staticClass: "fa-solid fa-circle-info" }),
                this._v("\n                    المعادلات\n                "),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("h6", { staticClass: "cursor_pointer my-0" }, [
                e("i", { staticClass: "fa-solid fa-arrow-right" }),
                this._v("\n                السابق\n            "),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("h6", { staticClass: "cursor_pointer my-0" }, [
                this._v("\n                التالي\n                "),
                e("i", { staticClass: "fa-solid fa-arrow-left" }),
              ]);
            },
          ],
        },
        C = i("VU/8")(x, y, !1, null, null, null).exports,
        k = {
          render: function () {
            var t = this.$createElement,
              e = this._self._c || t;
            return e(
              "div",
              { staticClass: "loader loader--style1", attrs: { title: "0" } },
              [
                e(
                  "svg",
                  {
                    attrs: {
                      version: "1.1",
                      id: "loader-1",
                      xmlns: "http://www.w3.org/2000/svg",
                      "xmlns:xlink": "http://www.w3.org/1999/xlink",
                      x: "0px",
                      y: "0px",
                      width: "100px",
                      height: "100px",
                      viewBox: "0 0 40 40",
                      "enable-background": "new 0 0 40 40",
                      "xml:space": "preserve",
                    },
                  },
                  [
                    e("path", {
                      attrs: {
                        opacity: "0.2",
                        fill: "#000",
                        d: "M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946\n          s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634\n          c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z",
                      },
                    }),
                    this._v(" "),
                    e(
                      "path",
                      {
                        attrs: {
                          fill: "#000",
                          d: "M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0\n          C22.32,8.481,24.301,9.057,26.013,10.047z",
                        },
                      },
                      [
                        e("animateTransform", {
                          attrs: {
                            attributeType: "xml",
                            attributeName: "transform",
                            type: "rotate",
                            from: "0 20 20",
                            to: "360 20 20",
                            dur: "0.5s",
                            repeatCount: "indefinite",
                          },
                        }),
                      ],
                      1
                    ),
                  ]
                ),
              ]
            );
          },
          staticRenderFns: [],
        },
        A = i("VU/8")(null, k, !1, null, null, null).exports,
        D = { name: "Start", components: { Header: $, Footer: C, Loader: A } },
        M = {
          render: function () {
            var t = this.$createElement,
              e = this._self._c || t;
            return e(
              "div",
              { staticClass: "heyisnone" },
              [
                e("Header", {
                  attrs: {
                    BooleanTimer: !1,
                    BooleanNumQuiz: !1,
                    BooleanTagSave: !1,
                  },
                }),
                this._v(" "),
                this.$root.loader ? e("Loader") : this._e(),
                this._v(" "),
                this._m(0),
                this._v(" "),
                e("Footer", {
                  attrs: {
                    HerePage: "start",
                    BooleanNext: !0,
                    BooleanAfter: !1,
                  },
                }),
              ],
              1
            );
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "div",
                { staticClass: "col-12 p-0 position-relative bodybody" },
                [
                  e("div", { staticClass: "col-12 p-0 text-center pt-3" }, [
                    e("img", { attrs: { src: i("JSUG"), width: "300" } }),
                    this._v(" "),
                    e("h3", [
                      this._v(
                        "\n              مرحبا بك في اختبارات أكاديمية الحوت على الحاسب اآللي\n            "
                      ),
                    ]),
                    this._v(" "),
                    e("p", [
                      this._v(
                        "\n              سيتم بدء اإلختبار عند ضغط زر التالي في أسفل الشاشة\n            "
                      ),
                    ]),
                    this._v(" "),
                    e("p", [
                      this._v(
                        "\n              إضغط زر التالي للمتابعة\n            "
                      ),
                    ]),
                  ]),
                ]
              );
            },
          ],
        },
        j = i("VU/8")(D, M, !1, null, null, null).exports,
        I = i("rMyo"),
        S = i.n(I),
        B = {
          name: "Quiz",
          components: { Header: $, Footer: C },
          data: function () {
            return {
              json: S.a.data,
              minute: this.$root.sapa_time.minute,
              seconds: this.$root.sapa_time.seconds,
              timer: this.$root.timer,
            };
          },
          methods: {
            run: function () {
              w.xstart(this), (this.$root.pops = !0);
            },
          },
          mounted: function () {
            this.run();
          },
          watch: {
            timer: function () {
              if (((this.$root.timer = this.timer), "00:00" == this.timer)) {
                var t = void 0,
                  e = this.$root.quiz_viwe;
                0 == e[0]
                  ? ((this.$root.quiz_revision = 1),
                    (t = 1),
                    (this.$root.quiz_viwe[0] = 1),
                    (this.$root.quiz_total = this.$root.total[t - 1]),
                    this.$root.updateSave())
                  : 1 == e[0] && 0 == e[1]
                  ? ((this.$root.quiz_revision = 2),
                    (t = 2),
                    (this.$root.quiz_viwe[1] = 1),
                    (this.$root.quiz_total = this.$root.total[t - 1]),
                    this.$root.updateSave())
                  : 1 == e[1] && 0 == e[2]
                  ? ((this.$root.quiz_revision = 3),
                    (t = 3),
                    (this.$root.quiz_viwe[2] = 1),
                    (this.$root.quiz_total = this.$root.total[t - 1]),
                    this.$root.updateSave())
                  : 1 == e[2] &&
                    0 == e[3] &&
                    ((this.$root.quiz_revision = 4),
                    (t = 4),
                    (this.$root.quiz_viwe[3] = 1),
                    (this.$root.quiz_total = this.$root.total[t - 1]),
                    this.$root.updateSave()),
                  (this.$root.timer = this.$root.loadtimer),
                  (this.$root.quiz_faek = "quiz"),
                  (this.$root.faek_time.minute = this.$root.quiz_time.minute),
                  (this.$root.faek_time.seconds = this.$root.quiz_time.minute),
                  (this.$root.quiz_number = this.$root.quiz_number + 1),
                  (this.$root.addtimers = !0),
                  (this.$root.checkrefrsh = !0),
                  this.$root.updateSave(),
                  this.$root.checkdate(),
                  this.$router
                    .push("/quiz/" + this.$root.app_rand)
                    .catch(function (t) {}),
                  w.xstop();
              }
            },
          },
        },
        R = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              { staticClass: "heyisnone" },
              [
                i(
                  "div",
                  { staticClass: "row m-0" },
                  [
                    i("Header", {
                      attrs: {
                        BooleanTimer: !0,
                        BooleanNumQuiz: !1,
                        BooleanTagSave: !1,
                      },
                    }),
                  ],
                  1
                ),
                t._v(" "),
                i(
                  "div",
                  { staticClass: "col-12 p-0 text-end px-4 pt-3 bodybody" },
                  [
                    i("p", [
                      t._v(
                        "\n      " +
                          t._s(t.json[t.$root.quiz_revision - 1].title) +
                          "\n    "
                      ),
                    ]),
                    t._v(" "),
                    i("p", [
                      t._v(
                        "عدد الأسئلة : " +
                          t._s(t.$root.total[t.$root.quiz_revision - 1]) +
                          " سؤال"
                      ),
                    ]),
                    t._v(" "),
                    i("p", [
                      t._v(
                        "\n      الزمن الكلي للقسم :\n      " +
                          t._s(
                            (
                              (t.$root.total[t.$root.quiz_revision - 1] *
                                t.$root.seconds) /
                              60
                            ).toFixed(0)
                          ) +
                          " دقيقة\n    "
                      ),
                    ]),
                  ]
                ),
                t._v(" "),
                i("Footer", {
                  attrs: {
                    HerePage: "separation",
                    BooleanNext: !0,
                    BooleanAfter: !1,
                  },
                }),
              ],
              1
            );
          },
          staticRenderFns: [],
        },
        N = i("VU/8")(B, R, !1, null, null, null).exports,
        E = void 0,
        G = {
          xstart: function (t) {
            var e = t.date;
            E = setInterval(function () {
              var i = new Date().getTime(),
                o = e - i,
                s = Math.floor((o % 864e5) / 36e5),
                n = Math.floor((o % 36e5) / 6e4),
                a = Math.floor((o % 6e4) / 1e3);
              if (0 == s && 0 == n && 0 == a) t.timer = "00:00";
              else {
                (t.minute = n), (t.seconds = a);
                var r = (n < 10 ? "0" + n : n) + ":" + (a < 10 ? "0" + a : a);
                t.timer =
                  0 != s ? (s < 10 ? "0" + s + ":" + r : s + ":" + r) : r;
              }
            }, 1e3);
          },
          xstop: function () {
            clearInterval(E);
          },
        },
        Y = i("bv2/"),
        T = {
          name: "Single",
          components: {
            DragCol: Y.a,
            DragRow: Y.b,
            ResizeCol: Y.d,
            ResizeRow: Y.e,
            Resize: Y.c,
          },
          data: function () {
            return {
              page: 0,
              quiz: [],
              joab: [!1, !1, !1, !1],
              name: "",
              ask: "",
              option: [],
            };
          },
          methods: {
            run: function () {
              if (0 != this.$root.quiz_number) {
                var t = this.$root.quiz_revision,
                  e = this.$root.quiz_total,
                  i = this.$root.quiz_number;
                this.$root.appSave(),
                  (this.page = 1 != t ? i - 1 + e * (t - 1) : i - 1),
                  (this.quiz = this.$root.quizs),
                  (this.name = this.quiz.questions[this.page].paragraph),
                  (this.ask = this.quiz.questions[this.page].name),
                  (this.option = this.quiz.questions[this.page].options),
                  this.checkedis();
              }
            },
            setscrolldown: function () {
              p()(".drager_left").scrollHeight;
            },
            checkbox: function (t, e) {
              var i = !0,
                o = t,
                s = e,
                n = this.$root.quiz_revision,
                a = { id: t, joab: s },
                r = void 0;
              1 == n
                ? (r = this.$root.quiz_joab.a)
                : 2 == n
                ? (r = this.$root.quiz_joab.b)
                : 3 == n
                ? (r = this.$root.quiz_joab.c)
                : 4 == n && (r = this.$root.quiz_joab.d);
              for (var u = 0; u < r.length; u++)
                if (r[u].id == o) {
                  (r[u].joab = s), (i = !1);
                  break;
                }
              i && r.push(a),
                1 == n
                  ? (this.$root.quiz_joab.a = r)
                  : 2 == n
                  ? (this.$root.quiz_joab.b = r)
                  : 3 == n
                  ? (this.$root.quiz_joab.c = r)
                  : 4 == n && (this.$root.quiz_joab.d = r),
                (this.quizj = r),
                this.checkedis(),
                this.$root.updateSave();
            },
            checkedis: function () {
              this.joab = [!1, !1, !1, !1];
              var t = this.page,
                e = this.$root.quiz_revision,
                i = void 0;
              1 == e
                ? (i = this.$root.quiz_joab.a)
                : 2 == e
                ? (i = this.$root.quiz_joab.b)
                : 3 == e
                ? (i = this.$root.quiz_joab.c)
                : 4 == e && (i = this.$root.quiz_joab.d);
              for (var o = this.joab, s = 0; s < i.length; s++)
                i[s].id == t && (o[i[s].joab] = !0);
              this.joab = o;
            },
            run2: function () {
              0 != this.$root.quiz_number &&
                0 == this.$root.loader &&
                this.run();
            },
          },
          mounted: function () {
            this.run();
          },
          watch: {
            "$root.quizs.questions": function () {
              0 != this.$root.quiz_number && this.run();
            },
            "$root.isnext": function () {
              0 != this.$root.quiz_number && this.run();
            },
          },
        },
        W = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              { staticClass: "m-0 p-0" },
              [
                i("DragCol", {
                  staticStyle: { width: "100%", height: "max-content" },
                  attrs: { dir: "ltr" },
                  scopedSlots: t._u([
                    {
                      key: "left",
                      fn: function () {
                        return [
                          i("div", { staticClass: "sp_style pt-3 px-3" }, [
                            i(
                              "h4",
                              {
                                staticClass:
                                  "quiz_description_1 text-danger fontsizequiz",
                              },
                              [
                                t._v(
                                  "\r\n                استيعاب المقروء\r\n            "
                                ),
                              ]
                            ),
                            t._v(" "),
                            i(
                              "h5",
                              {
                                staticClass:
                                  "quiz_description_2 text-danger fontsizequiz",
                              },
                              [
                                t._v(
                                  "\r\n                السؤال التالي يتعلق بالنص المرفق , بعد السؤال هناك أربع اختيارات ,\r\n                واحد منها صحيح المطلوب , هو قراءة النص بعناية , ثم اختيار الإجابة\r\n                الصحيحة\r\n            "
                                ),
                              ]
                            ),
                            t._v(" "),
                            i(
                              "h5",
                              {
                                staticClass: "quiz_description_2 fontsizequiz",
                              },
                              [
                                t._v(
                                  "\r\n                " +
                                    t._s(t.name) +
                                    "\r\n            "
                                ),
                              ]
                            ),
                          ]),
                        ];
                      },
                      proxy: !0,
                    },
                    {
                      key: "right",
                      fn: function () {
                        return [
                          i(
                            "div",
                            {
                              staticClass: "sp_style pt-3 px-3",
                              on: { onscroll: t.setscrolldown },
                            },
                            [
                              i("div", { staticClass: "sp_in_sp" }, [
                                i(
                                  "h4",
                                  {
                                    staticClass:
                                      "quiz_description_1 mb-3 fontsizequiz",
                                  },
                                  [i("p", { domProps: { innerHTML: t.ask } })]
                                ),
                                t._v(" "),
                                i(
                                  "form",
                                  {
                                    ref: "anyName",
                                    staticClass: "fontsizequiz",
                                  },
                                  t._l(t.option, function (e, o) {
                                    return i(
                                      "div",
                                      {
                                        key: o,
                                        staticClass:
                                          "form-check form-group mt-1 me-4 mb-3",
                                      },
                                      [
                                        i("input", {
                                          staticClass:
                                            "form-check-input float-end ms-2",
                                          attrs: {
                                            type: "radio",
                                            name: "exampleRadios",
                                            id:
                                              "exampleRadios" +
                                              t.page +
                                              "q" +
                                              o,
                                          },
                                          domProps: {
                                            value: "option" + t.page + "q" + o,
                                            checked: t.joab[o],
                                          },
                                          on: {
                                            click: function (e) {
                                              return t.checkbox(t.page, o);
                                            },
                                          },
                                        }),
                                        t._v(" "),
                                        i(
                                          "label",
                                          {
                                            staticClass: "form-check-label",
                                            attrs: {
                                              for:
                                                "exampleRadios" +
                                                t.page +
                                                "q" +
                                                o,
                                            },
                                          },
                                          [
                                            t._v(
                                              "\r\n                            " +
                                                t._s(e.name) +
                                                "\r\n                        "
                                            ),
                                          ]
                                        ),
                                      ]
                                    );
                                  }),
                                  0
                                ),
                              ]),
                            ]
                          ),
                        ];
                      },
                      proxy: !0,
                    },
                  ]),
                }),
              ],
              1
            );
          },
          staticRenderFns: [],
        },
        L = {
          name: "Quiz",
          components: {
            Header: $,
            Single: i("VU/8")(T, W, !1, null, null, null).exports,
            Footer: C,
            Loader: A,
          },
          data: function () {
            return {
              number_page: this.$root.quiz_number,
              minute: 5,
              seconds: 5,
              date: this.$root.thatdatea,
              timer: this.$root.timer,
              plus: !1,
              plustime: "00:10",
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), t.$root.appSave();
                          case 2:
                            G.xstop(),
                              1 == t.$root.quiz_revision
                                ? ((t.date = t.$root.thatdatea),
                                  (t.$root.quiz_viwe[0] = 1))
                                : 2 == t.$root.quiz_revision
                                ? ((t.date = t.$root.thatdateb),
                                  (t.$root.quiz_viwe[1] = 1))
                                : 3 == t.$root.quiz_revision
                                ? ((t.date = t.$root.thatdatec),
                                  (t.$root.quiz_viwe[2] = 1))
                                : 4 == t.$root.quiz_revision &&
                                  ((t.date = t.$root.thatdated),
                                  (t.$root.quiz_viwe[3] = 1)),
                              (t.minute = Number(t.$root.faek_time.minute)),
                              (t.seconds = Number(t.$root.faek_time.seconds)),
                              (t.timer = t.$root.timer),
                              t.floader(),
                              G.xstart(t),
                              t.$root.updateSave(),
                              t.thistime();
                          case 11:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            floader: function () {
              var t = this;
              setInterval(function () {
                t.$root.loader = !1;
              }, 500);
            },
            nextlist: function () {
              var t = this.$root.quiz_revision;
              (this.$root.quiz_faek = "separation"),
                (this.$root.quiz_number = 0),
                1 == t
                  ? ((this.$root.quiz_revision = 2),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 2 == t
                  ? ((this.$root.quiz_revision = 3),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 3 == t
                  ? ((this.$root.quiz_revision = 4),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 4 == t &&
                    ((this.$root.quiz_faek = "end"),
                    (this.$root.quiz_revision = 5),
                    this.$root.updateSave(),
                    this.$router
                      .push({ name: "End", path: "/end" })
                      .catch(function (t) {})),
                (this.plus = !1);
            },
            dragElement: function (t) {
              var e = document.getElementById(t),
                i = 0,
                o = 0,
                s = 0,
                n = 0;
              function a(t) {
                (t = t || window.event).preventDefault(),
                  (s = t.clientX),
                  (n = t.clientY),
                  (document.onmouseup = u),
                  (document.onmousemove = r);
              }
              function r(t) {
                (t = t || window.event).preventDefault(),
                  (i = s - t.clientX),
                  (o = n - t.clientY),
                  (s = t.clientX),
                  (n = t.clientY),
                  (e.style.top = e.offsetTop - o + "px"),
                  (e.style.left = e.offsetLeft - i + "px");
              }
              function u() {
                (document.onmouseup = null), (document.onmousemove = null);
              }
              document.getElementById(e.id + "header")
                ? (document.getElementById(e.id + "header").onmousedown = a)
                : (e.onmousedown = a);
            },
            openModal: function (t) {
              p()(t).attr("class", "modal fade show"),
                p()(t).attr("style", "display: block; padding-left: 0px;");
            },
            closeModal: function (t) {
              p()(t).attr("class", "modal fade"), p()(t).attr("style", "");
            },
            thistime: function () {
              this.minute <= 0 &&
                this.seconds <= 0 &&
                (G.xstop(),
                p()("p#clock").html(
                  '<i class="fa-regular fa-clock"></i> انتهى الوقت'
                ));
            },
            poplow: function () {
              (this.$root.popsendtime = !1),
                this.$root.updateSave(),
                closeModal("#statictime");
            },
          },
          mounted: function () {
            this.run();
          },
          watch: {
            $route: "run",
            timer: function () {
              var t = this;
              "00:00" != this.timer &&
                "00:10" == this.plustime &&
                ((this.$root.faek_time.minute = this.minute),
                (this.$root.faek_time.seconds = this.seconds),
                (this.$root.timer = this.timer),
                this.minute < 5 &&
                  (this.$root.pops &&
                    this.$root.popsendtime &&
                    ((this.$root.pops = !1), this.openModal("#statictime")),
                  p()("p#clock").attr("style", "color:yellow !important;"))),
                this.minute <= 0 &&
                  this.seconds <= 0 &&
                  (G.xstop(),
                  (this.plus = !0),
                  this.plus && (this.plustime = this.timer),
                  setTimeout(function () {
                    t.nextlist();
                  }, 1e4),
                  "00:00" != this.plustime && this.openModal("#staticendtime"),
                  this.thistime());
            },
          },
        },
        H = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i("div", { staticClass: "heyisnone" }, [
              i(
                "div",
                { staticClass: "row m-0" },
                [
                  i("Header", {
                    attrs: {
                      BooleanTimer: !0,
                      BooleanNumQuiz: !0,
                      BooleanTagSave: !0,
                    },
                  }),
                  t._v(" "),
                  i(
                    "div",
                    { staticClass: "col-12 p-0 position-relative" },
                    [
                      t.$root.loader ? i("Loader") : t._e(),
                      t._v(" "),
                      i("Single"),
                    ],
                    1
                  ),
                  t._v(" "),
                  i("Footer", {
                    attrs: {
                      HerePage: "quiz",
                      BooleanNext: !0,
                      BooleanAfter: !0,
                    },
                  }),
                  t._v(" "),
                  i(
                    "div",
                    {
                      staticClass: "modal fade",
                      attrs: {
                        id: "statictime",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false",
                        tabindex: "-1",
                        "aria-labelledby": "staticBackdropLabel",
                        "aria-hidden": "true",
                      },
                      on: {
                        mousedown: function (e) {
                          return t.dragElement("statictime");
                        },
                      },
                    },
                    [
                      i(
                        "div",
                        {
                          staticClass: "modal-dialog",
                          attrs: { id: "statictimeheader" },
                        },
                        [
                          i(
                            "div",
                            { staticClass: "modal-content border-0 rounded-0" },
                            [
                              i("div", { staticClass: "modal-header py-1" }, [
                                t._m(0),
                                t._v(" "),
                                i(
                                  "button",
                                  {
                                    staticClass: "btn fs-4 p-0 text-white",
                                    attrs: { type: "button" },
                                    on: {
                                      click: function (e) {
                                        return t.closeModal("#statictime");
                                      },
                                    },
                                  },
                                  [
                                    i("i", {
                                      staticClass:
                                        "fa-regular fa-rectangle-xmark",
                                    }),
                                  ]
                                ),
                              ]),
                              t._v(" "),
                              t._m(1),
                              t._v(" "),
                              i(
                                "div",
                                {
                                  staticClass:
                                    "modal-footer justify-content-center",
                                },
                                [
                                  i(
                                    "button",
                                    {
                                      staticClass:
                                        "btn btn-secondary rounded-0 border-1 border-white",
                                      attrs: { type: "button" },
                                      on: { click: t.poplow },
                                    },
                                    [
                                      t._v(
                                        "\n                  حسناُ\n                  "
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ],
                1
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "staticendtime",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("staticendtime");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "staticendtimeheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          i("div", { staticClass: "modal-header py-1" }, [
                            t._m(2),
                            t._v(" "),
                            i(
                              "button",
                              {
                                staticClass: "btn fs-4 p-0 text-white",
                                attrs: { type: "button" },
                                on: {
                                  click: function (e) {
                                    return t.closeModal("#staticendtime");
                                  },
                                },
                              },
                              [
                                i("i", {
                                  staticClass: "fa-regular fa-rectangle-xmark",
                                }),
                              ]
                            ),
                          ]),
                          t._v(" "),
                          t._m(3),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-secondary rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (e) {
                                      return t.nextlist();
                                    },
                                  },
                                },
                                [
                                  t._v(
                                    "\n                  موافق\n                  "
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
            ]);
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h1",
                {
                  staticClass: "modal-title fs-5",
                  attrs: { id: "staticBackdropLabel" },
                },
                [
                  e("i", { staticClass: "fa-regular fa-clock" }),
                  this._v(
                    "\n                      تبقى خمس دقائق\n                  "
                  ),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("+MlX") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\n                          لديك 5 دقائق فقط لإنهاء هذا القسم\n                      "
                    ),
                  ]),
                ]),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h1",
                {
                  staticClass: "modal-title fs-5",
                  attrs: { id: "staticBackdropLabel" },
                },
                [
                  e("i", { staticClass: "fa-regular fa-clock" }),
                  this._v(
                    "\n                      انتهى الوقت\n                  "
                  ),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("+MlX") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\n                        إنتهت المدة المسموحة لحل القسم - إضغط موافق للمتابعة\n                      "
                    ),
                  ]),
                ]),
              ]);
            },
          ],
        },
        Q = i("VU/8")(L, H, !1, null, null, null).exports,
        Z = {
          name: "Header",
          props: { next: Boolean },
          data: function () {
            return { totalnone: 0, popture: !0 };
          },
          methods: {
            run: function () {
              (this.$root.totalnone = this.xspx()),
                (this.totalnone = this.xspx());
            },
            dragElement: function (t) {
              var e = document.getElementById(t),
                i = 0,
                o = 0,
                s = 0,
                n = 0;
              function a(t) {
                (t = t || window.event).preventDefault(),
                  (s = t.clientX),
                  (n = t.clientY),
                  (document.onmouseup = u),
                  (document.onmousemove = r);
              }
              function r(t) {
                (t = t || window.event).preventDefault(),
                  (i = s - t.clientX),
                  (o = n - t.clientY),
                  (s = t.clientX),
                  (n = t.clientY),
                  (e.style.top = e.offsetTop - o + "px"),
                  (e.style.left = e.offsetLeft - i + "px");
              }
              function u() {
                (document.onmouseup = null), (document.onmousemove = null);
              }
              document.getElementById(e.id + "header")
                ? (document.getElementById(e.id + "header").onmousedown = a)
                : (e.onmousedown = a);
            },
            xspx: function () {
              for (
                var t,
                  e = [],
                  i = this.$root.quiz_revision,
                  o = this.$root.quiz_total,
                  s = this.$root.quiz_total,
                  n = o * i - o;
                n < s * i;
                n++
              )
                this.vmg(n, i) && ((t = { id: n }), e.push(t));
              return (
                1 == i
                  ? (this.$root.quiz_none.a = e)
                  : 2 == i
                  ? (this.$root.quiz_none.b = e)
                  : 3 == i
                  ? (this.$root.quiz_none.c = e)
                  : 4 == i && (this.$root.quiz_none.d = e),
                e.length
              );
            },
            vmg: function (t, e) {
              var i = void 0,
                o = e;
              1 == o
                ? (i = this.$root.quiz_joab.a)
                : 2 == o
                ? (i = this.$root.quiz_joab.b)
                : 3 == o
                ? (i = this.$root.quiz_joab.c)
                : 4 == o && (i = this.$root.quiz_joab.d);
              for (var s = 0; s < i.length; s++)
                if (Number(i[s].id) == Number(t)) return !1;
              return !0;
            },
            openModal: function (t) {
              this.totalnonecheck(),
                p()(t).attr("class", "modal fade show"),
                p()(t).attr("style", "display: block; padding-left: 0px;");
            },
            closeModal: function (t) {
              p()(t).attr("class", "modal fade"), p()(t).attr("style", "");
            },
            openendmodal: function () {
              0 == this.xspx()
                ? this.openModal("#staticTowdrop")
                : this.openModal("#staticBackdrop");
            },
            endnextlist: function () {
              this.closeModal();
              var t = this.$root.quiz_revision;
              (this.$root.quiz_faek = "separation"),
                (this.$root.quiz_number = 0),
                (this.$root.timer = this.$root.loadtimer),
                1 == t
                  ? ((this.$root.quiz_revision = 2),
                    (this.$root.quiz_viwe[0] = 1),
                    (this.$root.quiz_total =
                      this.$root.total[this.$root.quiz_revision - 1]),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 2 == t
                  ? ((this.$root.quiz_revision = 3),
                    (this.$root.quiz_viwe[2] = 1),
                    (this.$root.quiz_total =
                      this.$root.total[this.$root.quiz_revision - 1]),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 3 == t
                  ? ((this.$root.quiz_revision = 4),
                    (this.$root.quiz_viwe[3] = 1),
                    (this.$root.quiz_total =
                      this.$root.total[this.$root.quiz_revision - 1]),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 4 == t &&
                    ((this.$root.quiz_faek = "end"),
                    (this.$root.quiz_revision = 5),
                    (this.$root.quiz_total = this.$root.total[0]),
                    this.$root.updateSave(),
                    this.$router.push({ name: "End", path: "/end" }));
            },
            allrevision: function () {
              (this.$root.quiz_faek = "revision_quiz"),
                (this.$root.revision = 0),
                (this.$root.quiz_number = 1),
                (this.$root.faek_total =
                  this.$root.total[this.$root.quiz_revision - 1]),
                this.$root.updateSave(),
                this.$router.push({
                  name: "Revision Quiz",
                  params: { id: this.$root.app_rand },
                });
            },
            tagsrevision: function () {
              var t = [],
                e = this.$root.quiz_revision;
              (this.$root.quiz_faek = "revision_quiz"),
                1 == e
                  ? (t = this.$root.quiz_tags.a)
                  : 2 == e
                  ? (t = this.$root.quiz_tags.b)
                  : 3 == e
                  ? (t = this.$root.quiz_tags.c)
                  : 4 == e && (t = this.$root.quiz_tags.d),
                (this.$root.revision = 2),
                (this.$root.quiz_number = 1),
                (this.$root.faek_total = t.length),
                this.$root.updateSave(),
                0 == t.length
                  ? this.openModal("#statictagsquiz")
                  : this.$router.push({
                      name: "Revision Quiz",
                      params: { id: this.$root.app_rand },
                    });
            },
            nonerevision: function () {
              var t = [],
                e = this.$root.quiz_revision;
              (this.$root.quiz_faek = "revision_quiz"),
                1 == e
                  ? (t = this.$root.quiz_none.a)
                  : 2 == e
                  ? (t = this.$root.quiz_none.b)
                  : 3 == e
                  ? (t = this.$root.quiz_none.c)
                  : 4 == e && (t = this.$root.quiz_none.d),
                (this.$root.revision = 1),
                (this.$root.quiz_number = 1),
                (this.$root.faek_total = t.length),
                this.$root.updateSave(),
                0 == t.length
                  ? this.openModal("#staticnonequiz")
                  : this.$router.push({
                      name: "Revision Quiz",
                      params: { id: this.$root.app_rand },
                    });
            },
            totalnonecheck: function () {
              this.totalnone = this.xspx();
            },
          },
          mounted: function () {
            this.run();
          },
          watch: { "this.$root.totalnone": "run", "$root.quiz_none": "run" },
        },
        F = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i("div", { staticClass: "p-0" }, [
              i(
                "div",
                {
                  staticClass:
                    "row footer w-100 m-0 w-100 py-1 px-3 quiz_footer justify-content-between align-items-center bg-DarkBlueOldColor justify-content-center position-fixed",
                },
                [
                  i(
                    "div",
                    { staticClass: "py-0 col-4 d-flex justify-content-start" },
                    [
                      i(
                        "button",
                        {
                          staticClass:
                            "rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white",
                          attrs: {
                            disabled: t.$root.loader,
                            "data-bs-toggle": "modal",
                            "data-bs-target": "#staticBackdrop",
                          },
                          on: { click: t.openendmodal },
                        },
                        [t._m(0)]
                      ),
                    ]
                  ),
                  t._v(" "),
                  i(
                    "div",
                    { staticClass: "py-0 d-flex justify-content-end col-8" },
                    [
                      i(
                        "button",
                        {
                          staticClass:
                            "rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link",
                          attrs: { disabled: t.$root.loader },
                          on: { click: t.allrevision },
                        },
                        [t._m(1)]
                      ),
                      t._v(" "),
                      i(
                        "button",
                        {
                          staticClass:
                            "rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link",
                          attrs: { disabled: t.$root.loader },
                          on: { click: t.nonerevision },
                        },
                        [t._m(2)]
                      ),
                      t._v(" "),
                      i(
                        "button",
                        {
                          staticClass:
                            "rounded-0 border-end border-2 btn btn-link py-2 text-decoration-none text-white",
                          attrs: { disabled: t.$root.loader },
                          on: { click: t.tagsrevision },
                        },
                        [t._m(3)]
                      ),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "staticBackdrop",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("staticBackdrop");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "staticBackdropheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          i("div", { staticClass: "modal-header py-1" }, [
                            i(
                              "h1",
                              {
                                staticClass: "modal-title fs-5",
                                attrs: { id: "staticBackdropLabel" },
                              },
                              [
                                t._v(
                                  "\r\n                    إنهاء المراجعة\r\n                "
                                ),
                              ]
                            ),
                            t._v(" "),
                            i(
                              "button",
                              {
                                staticClass: "btn fs-4 p-0 text-white",
                                attrs: { type: "button" },
                                on: {
                                  click: function (e) {
                                    return t.closeModal("#staticBackdrop");
                                  },
                                },
                              },
                              [
                                i("i", {
                                  staticClass: "fa-regular fa-rectangle-xmark",
                                }),
                              ]
                            ),
                          ]),
                          t._v(" "),
                          i("div", { staticClass: "modal-body row" }, [
                            t._m(4),
                            t._v(" "),
                            i("div", { staticClass: "col-11" }, [
                              i("p", [
                                t._v(
                                  '\r\n                        الرجاء التأكيد على رغبتك في إنهاء هذه\r\n                        المراجعة . إذا نقرت فوق "نعم" ، لن تكون\r\n                        هناك إمكانية للعودة إلى هذه المراجعة\r\n                        واإلجابة على األسئلة )عدد االسئلة-\r\n                        ' +
                                    t._s(t.xspx()) +
                                    "\r\n                        .التي لم تكتمل\r\n                    "
                                ),
                              ]),
                            ]),
                          ]),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn text-white rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (e) {
                                      return t.closeModal("#staticBackdrop");
                                    },
                                  },
                                },
                                [t._v("لا")]
                              ),
                              t._v(" "),
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn text-white rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (e) {
                                      t.closeModal("#staticBackdrop"),
                                        t.openModal("#staticTowdrop");
                                    },
                                  },
                                },
                                [t._v("نعم")]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "staticTowdrop",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("staticTowdrop");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "staticTowdropheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          i("div", { staticClass: "modal-header py-1" }, [
                            i(
                              "h1",
                              {
                                staticClass: "modal-title fs-5",
                                attrs: { id: "staticBackdropLabel" },
                              },
                              [
                                t._v(
                                  "\r\n                    إنهاء المراجعة\r\n                "
                                ),
                              ]
                            ),
                            t._v(" "),
                            i(
                              "button",
                              {
                                staticClass: "btn fs-4 p-0 text-white",
                                attrs: { type: "button" },
                                on: {
                                  click: function (e) {
                                    return t.closeModal("#staticTowdrop");
                                  },
                                },
                              },
                              [
                                i("i", {
                                  staticClass: "fa-regular fa-rectangle-xmark",
                                }),
                              ]
                            ),
                          ]),
                          t._v(" "),
                          t._m(5),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn text-white rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (e) {
                                      return t.closeModal("#staticTowdrop");
                                    },
                                  },
                                },
                                [t._v("لا")]
                              ),
                              t._v(" "),
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn text-white rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: { click: t.endnextlist },
                                },
                                [t._v("نعم")]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "statictagsquiz",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("statictagsquiz");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "statictagsquizheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          i("div", { staticClass: "modal-header py-1" }, [
                            i(
                              "h1",
                              {
                                staticClass: "modal-title fs-5",
                                attrs: { id: "staticBackdropLabel" },
                              },
                              [
                                t._v(
                                  "\r\n                الأسئلة المميزة بعلامة\r\n            "
                                ),
                              ]
                            ),
                            t._v(" "),
                            i(
                              "button",
                              {
                                staticClass: "btn fs-4 p-0 text-white",
                                attrs: { type: "button" },
                                on: {
                                  click: function (e) {
                                    return t.closeModal("#statictagsquiz");
                                  },
                                },
                              },
                              [
                                i("i", {
                                  staticClass: "fa-regular fa-rectangle-xmark",
                                }),
                              ]
                            ),
                          ]),
                          t._v(" "),
                          t._m(6),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn text-white rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (e) {
                                      return t.closeModal("#statictagsquiz");
                                    },
                                  },
                                },
                                [t._v("\r\n            حسناُ\r\n            ")]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "staticnonequiz",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("staticnonequiz");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "staticnonequizheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          i("div", { staticClass: "modal-header py-1" }, [
                            i(
                              "h1",
                              {
                                staticClass: "modal-title fs-5",
                                attrs: { id: "staticBackdropLabel" },
                              },
                              [
                                t._v(
                                  "\r\n                الأسئلة الغير مكتملة\r\n            "
                                ),
                              ]
                            ),
                            t._v(" "),
                            i(
                              "button",
                              {
                                staticClass: "btn fs-4 p-0 text-white",
                                attrs: { type: "button" },
                                on: {
                                  click: function (e) {
                                    return t.closeModal("#staticnonequiz");
                                  },
                                },
                              },
                              [
                                i("i", {
                                  staticClass: "fa-regular fa-rectangle-xmark",
                                }),
                              ]
                            ),
                          ]),
                          t._v(" "),
                          t._m(7),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn text-white rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (e) {
                                      return t.closeModal("#staticnonequiz");
                                    },
                                  },
                                },
                                [t._v("\r\n            حسناُ\r\n            ")]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
            ]);
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("h6", { staticClass: "cursor_pointer my-0" }, [
                e("i", { staticClass: "fa-solid fa-arrow-right-from-bracket" }),
                this._v("\r\n                إنهاء المراجعة\r\n            "),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("h6", { staticClass: "cursor_pointer my-0" }, [
                e("i", { staticClass: "fa-solid fa-bars" }),
                this._v("\r\n                مراجعة الكل\r\n            "),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("h6", { staticClass: "cursor_pointer my-0" }, [
                e("i", { staticClass: "fa-regular fa-circle-xmark" }),
                this._v(
                  "\r\n                مراجعة الغير مكتمل\r\n            "
                ),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("h6", { staticClass: "cursor_pointer my-0" }, [
                e("i", { staticClass: "fa-solid fa-flag" }),
                this._v(
                  "\r\n                مراجعة المميز بعلامة\r\n            "
                ),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "col-1" }, [
                e("img", { attrs: { src: i("lk7M") } }),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("lk7M") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\r\n                        هل أنت متأكد أنك تريد إنهاء هذه\r\n                        المراجعة؟\r\n                    "
                    ),
                  ]),
                ]),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("+MlX") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\r\n                    ليس هناك إي اسئلة مميزة بعلامة لمراجعتها\r\n                "
                    ),
                  ]),
                ]),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("+MlX") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\r\n                    ليس هناك إي اسئلة غير مكتملة لمراجعتها\r\n                "
                    ),
                  ]),
                ]),
              ]);
            },
          ],
        },
        U = i("VU/8")(Z, F, !1, null, null, null).exports,
        O = i("I9NY"),
        P = i.n(O),
        J = {
          name: "Revision",
          components: { Header: $, Footer: U, Loader: A },
          data: function () {
            return {
              TgImage: g.a,
              TsImage: P.a,
              page: this.$route.params.id,
              minute: 5,
              seconds: 5,
              date: this.$root.thatdatea,
              timer: this.$root.timer,
              plus: !1,
              plustime: "00:10",
              quiz_joab: [],
              quiz_revision: 0,
              totalnone: 0,
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), t.$root.appSave();
                          case 2:
                            G.xstop(),
                              1 == t.$root.quiz_revision
                                ? ((t.date = t.$root.thatdatea),
                                  (t.$root.quiz_viwe[0] = 1))
                                : 2 == t.$root.quiz_revision
                                ? ((t.date = t.$root.thatdateb),
                                  (t.$root.quiz_viwe[1] = 1))
                                : 3 == t.$root.quiz_revision
                                ? ((t.date = t.$root.thatdatec),
                                  (t.$root.quiz_viwe[2] = 1))
                                : 4 == t.$root.quiz_revision &&
                                  ((t.date = t.$root.thatdated),
                                  (t.$root.quiz_viwe[3] = 1)),
                              (t.minute = Number(t.$root.faek_time.minute)),
                              (t.seconds = Number(t.$root.faek_time.seconds)),
                              (t.timer = t.$root.timer),
                              t.floader(),
                              G.xstart(t),
                              (t.quiz_revision = t.$root.quiz_revision),
                              (t.$root.quiz_number = 1),
                              (t.$root.faek_total = t.$root.quiz_total),
                              t.xsp(),
                              t.$root.updateSave(),
                              t.thistime();
                          case 15:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            rnp: function (t) {
              var e = this.$root.quiz_revision,
                i = this.$root.quiz_total;
              return 1 != e ? t - 1 + i * (e - 1) : t - 1;
            },
            floader: function () {
              var t = this;
              setInterval(function () {
                t.$root.loader = !1;
              }, 2e3);
            },
            oop: function (t) {
              var e = void 0,
                i = this.$root.quiz_revision;
              1 == i
                ? (e = this.$root.quiz_joab.a)
                : 2 == i
                ? (e = this.$root.quiz_joab.b)
                : 3 == i
                ? (e = this.$root.quiz_joab.c)
                : 4 == i && (e = this.$root.quiz_joab.d);
              for (var o = 0; o < e.length; o++) if (e[o].id == t) return "";
              return "غير مكتمل";
            },
            vmg: function (t) {
              var e = void 0,
                i = this.$root.quiz_revision;
              1 == i
                ? (e = this.$root.quiz_joab.a)
                : 2 == i
                ? (e = this.$root.quiz_joab.b)
                : 3 == i
                ? (e = this.$root.quiz_joab.c)
                : 4 == i && (e = this.$root.quiz_joab.d);
              for (var o = 0; o < e.length; o++) if (e[o].id == t) return !1;
              return !0;
            },
            xsp: function () {
              for (
                var t,
                  e = [],
                  i = this.$root.quiz_revision,
                  o = this.$root.quiz_total,
                  s = this.$root.quiz_total,
                  n = o * i - o;
                n < (4 == i ? this.ddv() : s * i);
                n++
              )
                this.vmg(n) && ((t = { id: n }), e.push(t));
              1 == i
                ? (this.$root.quiz_none.a = e)
                : 2 == i
                ? (this.$root.quiz_none.b = e)
                : 3 == i
                ? (this.$root.quiz_none.c = e)
                : 4 == i && (this.$root.quiz_none.d = e),
                this.$root.updateSave(),
                this.tnc();
            },
            xspx: function () {
              for (
                var t,
                  e = [],
                  i = this.$root.quiz_revision,
                  o = this.$root.quiz_total,
                  s = this.$root.quiz_total,
                  n = o * i - o;
                n < (4 == i ? this.ddv() : s * i);
                n++
              )
                this.vmg(n) && ((t = { id: n }), e.push(t));
              return (
                1 == i
                  ? (this.$root.quiz_none.a = e)
                  : 2 == i
                  ? (this.$root.quiz_none.b = e)
                  : 3 == i
                  ? (this.$root.quiz_none.c = e)
                  : 4 == i && (this.$root.quiz_none.d = e),
                e.length
              );
            },
            ddv: function () {
              return (
                this.$root.total[0] +
                this.$root.total[1] +
                this.$root.total[2] +
                this.$root.total[3]
              );
            },
            otg: function (t) {
              var e = void 0,
                i = this.$root.quiz_revision;
              1 == i
                ? (e = this.$root.quiz_tags.a)
                : 2 == i
                ? (e = this.$root.quiz_tags.b)
                : 3 == i
                ? (e = this.$root.quiz_tags.c)
                : 4 == i && (e = this.$root.quiz_tags.d);
              for (var o = 0; o < e.length; o++)
                if (e[o].id == t && e[o].tag) return this.TsImage;
              return this.TgImage;
            },
            uod: function (t) {
              var e = void 0,
                i = this.$root.quiz_revision;
              1 == i
                ? (e = this.$root.quiz_tags.a)
                : 2 == i
                ? (e = this.$root.quiz_tags.b)
                : 3 == i
                ? (e = this.$root.quiz_tags.c)
                : 4 == i && (e = this.$root.quiz_tags.d);
              for (var o = 0; o < e.length; o++)
                if (e[o].id == t && e[o].tag) return !0;
              return !1;
            },
            ueq: function () {
              for (
                var t,
                  e = [],
                  i = this.$root.quiz_revision,
                  o = this.$root.quiz_total,
                  s = o * i - o;
                s < o * i;
                s++
              )
                this.uod(s) && ((t = { id: s }), e.push(t));
              1 == i
                ? (this.$root.quiz_tags.a = e)
                : 2 == i
                ? (this.$root.quiz_tags.b = e)
                : 3 == i
                ? (this.$root.quiz_tags.c = e)
                : 4 == i && (this.$root.quiz_tags.d = e);
            },
            btn: function (t) {
              (this.$root.quiz_faek = "revision_quiz"),
                (this.$root.revision = 0),
                (this.$root.quiz_number = t),
                (this.$root.faek_total =
                  this.$root.total[this.$root.quiz_revision - 1]),
                this.$root.updateSave(),
                this.$router.push({
                  name: "Revision Quiz",
                  params: { id: this.$root.app_rand },
                });
            },
            nextlist: function () {
              var t = this.$root.quiz_revision;
              (this.$root.quiz_faek = "separation"),
                (this.$root.quiz_number = 0),
                1 == t
                  ? ((this.$root.quiz_revision = 2),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 2 == t
                  ? ((this.$root.quiz_revision = 3),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 3 == t
                  ? ((this.$root.quiz_revision = 4),
                    this.$root.updateSave(),
                    this.$router
                      .push("/separation/" + this.$root.app_rand)
                      .catch(function (t) {}))
                  : 4 == t &&
                    ((this.$root.quiz_faek = "end"),
                    (this.$root.quiz_revision = 5),
                    this.$root.updateSave(),
                    this.$router
                      .push({ name: "End", path: "/end" })
                      .catch(function (t) {})),
                (this.plus = !1);
            },
            dragElement: function (t) {
              var e = document.getElementById(t),
                i = 0,
                o = 0,
                s = 0,
                n = 0;
              function a(t) {
                (t = t || window.event).preventDefault(),
                  (s = t.clientX),
                  (n = t.clientY),
                  (document.onmouseup = u),
                  (document.onmousemove = r);
              }
              function r(t) {
                (t = t || window.event).preventDefault(),
                  (i = s - t.clientX),
                  (o = n - t.clientY),
                  (s = t.clientX),
                  (n = t.clientY),
                  (e.style.top = e.offsetTop - o + "px"),
                  (e.style.left = e.offsetLeft - i + "px");
              }
              function u() {
                (document.onmouseup = null), (document.onmousemove = null);
              }
              document.getElementById(e.id + "header")
                ? (document.getElementById(e.id + "header").onmousedown = a)
                : (e.onmousedown = a);
            },
            openModal: function (t) {
              p()(t).attr("class", "modal fade show"),
                p()(t).attr("style", "display: block; padding-left: 0px;");
            },
            closeModal: function (t) {
              p()(t).attr("class", "modal fade"), p()(t).attr("style", "");
            },
            thistime: function () {
              this.minute <= 0 &&
                this.seconds <= 0 &&
                (G.xstop(),
                p()("p#clock").html(
                  '<i class="fa-regular fa-clock"></i> انتهى الوقت'
                ));
            },
            tnc: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  var i;
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            1 == (i = t.$root.quiz_revision)
                              ? t.$root.quiz_none.a
                              : 2 == i
                              ? t.$root.quiz_none.b
                              : 3 == i
                              ? t.$root.quiz_none.c
                              : 4 == i && t.$root.quiz_none.d,
                              (t.totalnone = t.xspx());
                          case 3:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
          },
          mounted: function () {
            this.run();
          },
          created: function () {
            this.run();
          },
          watch: {
            totalnone: function () {
              this.$root.totalnone = this.totalnone;
            },
            "$root.quiz_number": "run",
            timer: function () {
              var t = this;
              "00:00" != this.timer &&
                "00:10" == this.plustime &&
                ((this.$root.faek_time.minute = this.minute),
                (this.$root.faek_time.seconds = this.seconds),
                (this.$root.timer = this.timer),
                this.minute < 5 &&
                  (this.$root.pops &&
                    this.$root.popsendtime &&
                    ((this.$root.pops = !1), this.openModal("#statictime")),
                  p()("p#clock").attr("style", "color:yellow !important;"))),
                this.minute <= 0 &&
                  this.seconds <= 0 &&
                  (G.xstop(),
                  (this.plus = !0),
                  this.plus && (this.plustime = this.timer),
                  setTimeout(function () {
                    t.nextlist();
                  }, 1e4),
                  "00:00" != this.plustime && this.openModal("#staticendtime"),
                  this.thistime());
            },
          },
        },
        V = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i("div", { staticClass: "heyisnone" }, [
              i(
                "div",
                { staticClass: "row m-0" },
                [
                  i("Header", {
                    attrs: {
                      BooleanTimer: !0,
                      BooleanNumQuiz: !1,
                      BooleanTagSave: !1,
                    },
                  }),
                  t._v(" "),
                  i("div"),
                  t._v(" "),
                  i(
                    "div",
                    {
                      staticClass:
                        "col-12 p-0 position-relative overflow-hidden",
                    },
                    [
                      this.$root.loader ? i("Loader") : t._e(),
                      t._v(" "),
                      i(
                        "div",
                        { staticClass: "row mb-6 revision-cards" },
                        [
                          i("div", { staticClass: "col-12 p-0" }, [
                            i("h5", { staticClass: "text-center py-2" }, [
                              t._v(
                                "\n                        قسم المراجعة\n                    "
                              ),
                            ]),
                            t._v(" "),
                            i(
                              "div",
                              {
                                staticClass:
                                  "backGrd py-2 px-4 text-end text-white px-4",
                              },
                              [
                                t._v(
                                  "\n                        إرشادات\n                    "
                                ),
                              ]
                            ),
                            t._v(" "),
                            t._m(0),
                            t._v(" "),
                            i(
                              "div",
                              {
                                staticClass:
                                  "backGrd py-2 px-4 text-end text-white",
                              },
                              [
                                t._v(
                                  "\n                        الباب \n                        " +
                                    t._s(t.quiz_revision) +
                                    "\n                        جزء الحالي\n\n                        "
                                ),
                                i("div", { staticClass: "float-start" }, [
                                  t._v(
                                    "\n                            (غير مكتمل/غير مرئي " +
                                      t._s(t.xspx()) +
                                      " )\n                        "
                                  ),
                                ]),
                              ]
                            ),
                          ]),
                          t._v(" "),
                          t._l(
                            t.$root.total[t.quiz_revision - 1],
                            function (e) {
                              return i(
                                "button",
                                {
                                  key: e,
                                  staticClass:
                                    "quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (i) {
                                      return t.btn(e);
                                    },
                                  },
                                },
                                [
                                  i("img", { attrs: { src: t.otg(t.rnp(e)) } }),
                                  t._v(
                                    "\n                    سؤال " +
                                      t._s(e) +
                                      "\n                    "
                                  ),
                                  i(
                                    "div",
                                    { staticClass: "text-danger float-start" },
                                    [
                                      t._v(
                                        "\n                        " +
                                          t._s(t.oop(t.rnp(e))) +
                                          "\n                    "
                                      ),
                                    ]
                                  ),
                                ]
                              );
                            }
                          ),
                        ],
                        2
                      ),
                    ],
                    1
                  ),
                  t._v(" "),
                  i("Footer"),
                ],
                1
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "statictime",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("statictime");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "statictimeheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          i("div", { staticClass: "modal-header py-1" }, [
                            t._m(1),
                            t._v(" "),
                            i(
                              "button",
                              {
                                staticClass: "btn fs-4 p-0 text-white",
                                attrs: { type: "button" },
                                on: {
                                  click: function (e) {
                                    return t.closeModal("#statictime");
                                  },
                                },
                              },
                              [
                                i("i", {
                                  staticClass: "fa-regular fa-rectangle-xmark",
                                }),
                              ]
                            ),
                          ]),
                          t._v(" "),
                          t._m(2),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-secondary rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (e) {
                                      return t.closeModal("#statictime");
                                    },
                                  },
                                },
                                [
                                  t._v(
                                    "\n                حسناُ\n                "
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "staticendtime",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("staticendtime");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "staticendtimeheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          i("div", { staticClass: "modal-header py-1" }, [
                            t._m(3),
                            t._v(" "),
                            i(
                              "button",
                              {
                                staticClass: "btn fs-4 p-0 text-white",
                                attrs: { type: "button" },
                                on: {
                                  click: function (e) {
                                    return t.closeModal("#staticendtime");
                                  },
                                },
                              },
                              [
                                i("i", {
                                  staticClass: "fa-regular fa-rectangle-xmark",
                                }),
                              ]
                            ),
                          ]),
                          t._v(" "),
                          t._m(4),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-secondary rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: {
                                    click: function (e) {
                                      return t.nextlist();
                                    },
                                  },
                                },
                                [
                                  t._v(
                                    "\n                موافق\n                "
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
            ]);
          },
          staticRenderFns: [
            function () {
              var t = this,
                e = t.$createElement,
                i = t._self._c || e;
              return i("div", { staticClass: "text-end py-2 px-2 mx-4" }, [
                i("p", [
                  t._v(
                    "\n                            فيما يلي ملخص لإجابتك يمكنك مراجعة أسئلتك بثلاث (3) طرق مختلفة\n                        "
                  ),
                ]),
                t._v(" "),
                i("p", [
                  t._v(
                    "\n                            الأزرار الموجودة في الركن السفلي الأيسر تطابق هذه الخيارات:\n                        "
                  ),
                ]),
                t._v(" "),
                i("ul", [
                  i("li", [
                    t._v(
                      "\n                                قم بمراحعة كل أسئلتك و إجاباتك\n                            "
                    ),
                  ]),
                  t._v(" "),
                  i("li", [
                    t._v(
                      "\n                                قم بمراجعة أسئلتك الغير مكتملة\n                            "
                    ),
                  ]),
                  t._v(" "),
                  i("li", [
                    t._v(
                      "\n                                قم بمراجعة الأسئلة المميزة بعلامة المراجعة\n                            "
                    ),
                  ]),
                ]),
                t._v(" "),
                i("p", [
                  t._v(
                    "\n                            يمكنك ايضا النقر فوق رقم سؤال لربطه مباشرة بموقعه في الاختبار\n                        "
                  ),
                ]),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h1",
                {
                  staticClass: "modal-title fs-5",
                  attrs: { id: "staticBackdropLabel" },
                },
                [
                  e("i", { staticClass: "fa-regular fa-clock" }),
                  this._v(
                    "\n                    تبقى خمس دقائق\n                "
                  ),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("+MlX") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\n                        لديك 5 دقائق فقط لإنهاء هذا القسم\n                    "
                    ),
                  ]),
                ]),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h1",
                {
                  staticClass: "modal-title fs-5",
                  attrs: { id: "staticBackdropLabel" },
                },
                [
                  e("i", { staticClass: "fa-regular fa-clock" }),
                  this._v(
                    "\n                    انتهى الوقت\n                "
                  ),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("+MlX") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\n                      إنتهت المدة المسموحة لحل القسم - إضغط موافق للمتابعة\n                    "
                    ),
                  ]),
                ]),
              ]);
            },
          ],
        },
        X = i("VU/8")(J, V, !1, null, null, null).exports,
        K = {
          name: "Header",
          props: {
            BooleanTimer: Boolean,
            BooleanNumQuiz: Boolean,
            BooleanTagSave: Boolean,
          },
          data: function () {
            return {
              TgImage: f.a,
              TsImage: g.a,
              number_page: this.$root.quiz_number,
              feak_total: this.$root.faek_total,
              xselected: 18,
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            (t.number_page = t.$root.quiz_number),
                              (t.xselected = t.$root.fontsizequiz),
                              t.arrSave();
                          case 3:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            funSave: function () {
              var t = !0,
                e = this.$root.faek_num,
                i = { id: e, tag: !0 },
                o = void 0,
                s = this.$root.quiz_revision;
              1 == s
                ? (o = this.$root.quiz_tags.a)
                : 2 == s
                ? (o = this.$root.quiz_tags.b)
                : 3 == s
                ? (o = this.$root.quiz_tags.c)
                : 4 == s && (o = this.$root.quiz_tags.d);
              for (var n = 0; n < o.length; n++)
                if (o[n].id == e) {
                  o[n].tag ? (o[n].tag = !1) : (o[n].tag = !0), (t = !1);
                  break;
                }
              t && o.push(i),
                1 == s
                  ? (this.$root.quiz_tags.a = o)
                  : 2 == s
                  ? (this.$root.quiz_tags.b = o)
                  : 3 == s
                  ? (this.$root.quiz_tags.c = o)
                  : 4 == s && (this.$root.quiz_tags.d = o),
                this.arrSave();
            },
            tag: function () {
              var t = this.$root.faek_num,
                e = void 0,
                i = this.$root.quiz_revision;
              1 == i
                ? (e = this.$root.quiz_tags.a)
                : 2 == i
                ? (e = this.$root.quiz_tags.b)
                : 3 == i
                ? (e = this.$root.quiz_tags.c)
                : 4 == i && (e = this.$root.quiz_tags.d);
              for (var o = 0; o < e.length; o++)
                if (e[o].id == t && e[o].tag) return f.a;
              return g.a;
            },
            arrSave: function () {
              var t = this.$root.quiz_revision,
                e = void 0,
                i = [];
              1 == t
                ? (e = this.$root.quiz_tags.a)
                : 2 == t
                ? (e = this.$root.quiz_tags.b)
                : 3 == t
                ? (e = this.$root.quiz_tags.c)
                : 4 == t && (e = this.$root.quiz_tags.d);
              for (var o = 0; o < e.length; o++) e[o].tag && i.push(e[o]);
              (i = i),
                1 == t
                  ? (this.$root.quiz_tags.a = i)
                  : 2 == t
                  ? (this.$root.quiz_tags.b = i)
                  : 3 == t
                  ? (this.$root.quiz_tags.c = i)
                  : 4 == t && (this.$root.quiz_tags.d = i),
                this.$root.updateSave();
            },
            FunNumQuiz: function (t) {
              p()(t).toggleClass("active");
            },
            vselected: function () {
              (this.$root.fontsizequiz = this.xselected),
                p()("style#one").html(
                  ".fontsizequiz {font-size: " +
                    this.xselected +
                    "px!important;}"
                ),
                this.$root.updateSave();
            },
            checkselected: function () {
              this.xselected = this.$root.fontsizequiz;
            },
          },
          mounted: function () {
            this.tag();
          },
          watch: {
            xselected: "vselected",
            "$root.fontsizequiz": "checkselected",
            "$root.quiz_number": function () {
              this.run(), this.tag(), this.vselected();
            },
          },
        },
        tt = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i("div", { staticClass: "m-0 p-0" }, [
              i(
                "div",
                {
                  staticClass:
                    "col-12 header d-flex flex-column flex-md-row flex-lg-row flex-xl-row py-3 px-2 justify-content-between align-items-center bg-DarkBlueOldColor p-1",
                },
                [
                  t._m(0),
                  t._v(" "),
                  i(
                    "div",
                    {
                      staticClass:
                        "mt-2 mt-md-0 mt-lg-0 mt-xl-0 d-flex flex-column align-items-start align-items-md-end align-items-lg-end align-items-xl-end col-md-6 col-lg-6 col-12",
                    },
                    [
                      t.BooleanTimer
                        ? i(
                            "p",
                            {
                              staticClass: "textquiz m-0 f-12 text-white",
                              attrs: { id: "clock" },
                              on: {
                                click: function (e) {
                                  return t.FunNumQuiz("p#clock");
                                },
                              },
                            },
                            [
                              i("i", { staticClass: "fa-regular fa-clock" }),
                              t._v(
                                "\n                الوقت المتبقي \n                "
                              ),
                              i("b", {
                                domProps: { innerHTML: t._s(t.$root.timer) },
                              }),
                            ]
                          )
                        : t._e(),
                      t._v(" "),
                      i("div", [
                        t.BooleanNumQuiz
                          ? i(
                              "p",
                              {
                                staticClass: "textquiz m-0 f-12 mt-1",
                                attrs: { id: "quiznumbers" },
                                on: {
                                  click: function (e) {
                                    return t.FunNumQuiz("p#quiznumbers");
                                  },
                                },
                              },
                              [
                                i("i", { staticClass: "fa-solid fa-scroll" }),
                                t._v(" "),
                                i("span", [t._v(t._s(t.number_page))]),
                                t._v(
                                  "\n                    من\n                    "
                                ),
                                i("span", [
                                  t._v(
                                    "\n                        " +
                                      t._s(t.feak_total) +
                                      "\n                    "
                                  ),
                                ]),
                              ]
                            )
                          : t._e(),
                      ]),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass:
                    "col-12 downTag align-items-center justify-content-start justify-content-md-end justify-content-lg-end justify-content-xl-end bg-BlueOldColor py-2 px-4",
                },
                [
                  t.BooleanTagSave
                    ? i("div", [
                        i(
                          "button",
                          {
                            staticClass:
                              "btn cursor_pointer text-white m-0 px-3 fontsizequiz",
                            attrs: { type: "button" },
                            on: { click: t.funSave },
                          },
                          [
                            i("img", {
                              staticClass: "clock_img",
                              attrs: { src: t.tag(), alt: "img" },
                            }),
                            t._v(
                              "\n            تميز السؤال للمراجعة\n            "
                            ),
                          ]
                        ),
                        t._v(" "),
                        i(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: t.xselected,
                                expression: "xselected",
                              },
                            ],
                            staticClass:
                              "d-inline-block form-select form-select-sm rounded-0 w-auto",
                            staticStyle: {
                              "background-color": "#588cc5",
                              color: "white",
                            },
                            on: {
                              change: function (e) {
                                var i = Array.prototype.filter
                                  .call(e.target.options, function (t) {
                                    return t.selected;
                                  })
                                  .map(function (t) {
                                    return "_value" in t ? t._value : t.value;
                                  });
                                t.xselected = e.target.multiple ? i : i[0];
                              },
                            },
                          },
                          [
                            i("option", [
                              t._v(
                                "\n                    تغيير حجم الخط\n                "
                              ),
                            ]),
                            t._v(" "),
                            t._l([18, 20, 24, 26], function (e, o) {
                              return i(
                                "option",
                                {
                                  key: o,
                                  domProps: {
                                    value: e,
                                    selected: t.xselected == e,
                                  },
                                },
                                [
                                  t._v(
                                    "\n                    " +
                                      t._s(e) +
                                      "\n                "
                                  ),
                                ]
                              );
                            }),
                          ],
                          2
                        ),
                      ])
                    : t._e(),
                ]
              ),
            ]);
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "div",
                {
                  staticClass: "col-md-6 col-lg-6 col-12 text-end fontsizequiz",
                },
                [
                  e("strong", { staticClass: "m-0 increase_font" }, [
                    this._v("إختبار أكاديمية الحوت على الحاسب الآلي"),
                  ]),
                  this._v("\n        أحمد إبراهيم عادل\n        "),
                ]
              );
            },
          ],
        },
        et = i("VU/8")(K, tt, !1, null, null, null).exports,
        it = {
          name: "Single",
          components: {
            DragCol: Y.a,
            DragRow: Y.b,
            ResizeCol: Y.d,
            ResizeRow: Y.e,
            Resize: Y.c,
          },
          data: function () {
            return {
              page: this.$root.quiz_number,
              quiz: this.$root.quizs,
              joab: [!1, !1, !1, !1],
              number_quiz: 0,
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  var i, o, s;
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), t.$root.appSave();
                          case 2:
                            (i = t.$root.revision),
                              (t.page = t.$root.quiz_number - 1),
                              (t.quiz = t.$root.quizs),
                              (o = t.$root.quiz_revision),
                              (s = t.$root.quiz_total),
                              t.checkedis(),
                              1 == i
                                ? t.quizs_none()
                                : 2 == i
                                ? t.quizs_tags()
                                : 1 != o
                                ? ((t.number_quiz =
                                    t.$root.quiz_number - 1 + s * (o - 1)),
                                  (t.$root.faek_num =
                                    t.$root.quiz_number - 1 + s * (o - 1)))
                                : ((t.number_quiz = t.$root.quiz_number - 1),
                                  (t.$root.faek_num = t.$root.quiz_number - 1)),
                              t.$root.updateSave();
                          case 10:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            quizs_tags: function () {
              var t = void 0,
                e = this.page,
                i = this.$root.quiz_revision;
              1 == i
                ? (t = this.$root.quiz_tags.a)
                : 2 == i
                ? (t = this.$root.quiz_tags.b)
                : 3 == i
                ? (t = this.$root.quiz_tags.c)
                : 4 == i && (t = this.$root.quiz_tags.d),
                (this.number_quiz = t[e].id),
                (this.$root.faek_num = t[e].id);
            },
            quizs_none: function () {
              var t = void 0,
                e = this.page,
                i = this.$root.quiz_revision;
              1 == i
                ? (t = this.$root.quiz_none.a)
                : 2 == i
                ? (t = this.$root.quiz_none.b)
                : 3 == i
                ? (t = this.$root.quiz_none.c)
                : 4 == i && (t = this.$root.quiz_none.d),
                (this.number_quiz = t[e].id),
                (this.$root.faek_num = t[e].id);
            },
            checkbox: function (t, e) {
              var i = !0,
                o = t,
                s = e,
                n = this.$root.quiz_revision,
                a = { id: t, joab: s },
                r = void 0;
              1 == n
                ? (r = this.$root.quiz_joab.a)
                : 2 == n
                ? (r = this.$root.quiz_joab.b)
                : 3 == n
                ? (r = this.$root.quiz_joab.c)
                : 4 == n && (r = this.$root.quiz_joab.d);
              for (var u = 0; u < r.length; u++)
                if (r[u].id == o) {
                  (r[u].joab = s), (i = !1);
                  break;
                }
              i && r.push(a),
                1 == n
                  ? (this.$root.quiz_joab.a = r)
                  : 2 == n
                  ? (this.$root.quiz_joab.b = r)
                  : 3 == n
                  ? (this.$root.quiz_joab.c = r)
                  : 4 == n && (this.$root.quiz_joab.d = r),
                this.checkedis(),
                this.$root.updateSave();
            },
            checkedis: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  var i, o, s, n, r;
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), [!1, !1, !1, !1];
                          case 2:
                            for (
                              t.joab = e.sent,
                                i = t.number_quiz,
                                o = t.$root.quiz_revision,
                                s = void 0,
                                1 == o
                                  ? (s = t.$root.quiz_joab.a)
                                  : 2 == o
                                  ? (s = t.$root.quiz_joab.b)
                                  : 3 == o
                                  ? (s = t.$root.quiz_joab.c)
                                  : 4 == o && (s = t.$root.quiz_joab.d),
                                n = t.joab,
                                r = 0;
                              r < s.length;
                              r++
                            )
                              s[r].id == i && (n[s[r].joab] = !0);
                            t.joab = n;
                          case 10:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
          },
          mounted: function () {
            this.run();
          },
          watch: { "$root.quiz_number": "run" },
        },
        ot = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              { staticClass: "m-0 p-0" },
              [
                i("DragCol", {
                  staticStyle: { width: "100%", height: "max-content" },
                  attrs: { dir: "ltr" },
                  scopedSlots: t._u([
                    {
                      key: "left",
                      fn: function () {
                        return [
                          i(
                            "div",
                            { staticClass: "sp_style pt-3 px-3 fontsizequiz" },
                            [
                              i(
                                "h4",
                                {
                                  staticClass:
                                    "quiz_description_1 text-danger fontsizequiz",
                                },
                                [
                                  t._v(
                                    "\n                    استيعاب المقروء\n                "
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "h5",
                                {
                                  staticClass:
                                    "quiz_description_2 text-danger fontsizequiz",
                                },
                                [
                                  t._v(
                                    "\n                    السؤال التالي يتعلق بالنص المرفق , بعد السؤال هناك أربع اختيارات ,\n                    واحد منها صحيح المطلوب , هو قراءة النص بعناية , ثم اختيار الإجابة\n                    الصحيحة\n                "
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "h5",
                                {
                                  staticClass:
                                    "quiz_description_2 fontsizequiz",
                                },
                                [
                                  t._v(
                                    "\n                    " +
                                      t._s(
                                        t.quiz.questions[t.number_quiz]
                                          .paragraph
                                      ) +
                                      "\n                "
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ];
                      },
                      proxy: !0,
                    },
                    {
                      key: "right",
                      fn: function () {
                        return [
                          i(
                            "div",
                            { staticClass: "sp_style pt-3 px-3 fontsizequiz" },
                            [
                              i("div", { staticClass: "sp_in_sp" }, [
                                i(
                                  "h4",
                                  { staticClass: "quiz_description_1 mb-3" },
                                  [
                                    i("p", {
                                      domProps: {
                                        innerHTML:
                                          t.quiz.questions[t.number_quiz].name,
                                      },
                                    }),
                                  ]
                                ),
                                t._v(" "),
                                i(
                                  "form",
                                  { ref: "anyName" },
                                  t._l(
                                    t.quiz.questions[t.number_quiz].options,
                                    function (e, o) {
                                      return i(
                                        "div",
                                        {
                                          key: o,
                                          staticClass:
                                            "form-check form-group mt-1 me-4 mb-3",
                                        },
                                        [
                                          i("input", {
                                            staticClass:
                                              "form-check-input float-end ms-2",
                                            attrs: {
                                              type: "radio",
                                              name: "exampleRadios",
                                              id:
                                                "exampleRadios" +
                                                t.number_quiz +
                                                "q" +
                                                o,
                                            },
                                            domProps: {
                                              value:
                                                "option" +
                                                t.number_quiz +
                                                "q" +
                                                o,
                                              checked: t.joab[o],
                                            },
                                            on: {
                                              click: function (e) {
                                                return t.checkbox(
                                                  t.number_quiz,
                                                  o
                                                );
                                              },
                                            },
                                          }),
                                          t._v(" "),
                                          i(
                                            "label",
                                            {
                                              staticClass: "form-check-label",
                                              attrs: {
                                                for:
                                                  "exampleRadios" +
                                                  t.number_quiz +
                                                  "q" +
                                                  o,
                                              },
                                            },
                                            [
                                              t._v(
                                                "\n                                " +
                                                  t._s(e.name) +
                                                  "\n                            "
                                              ),
                                            ]
                                          ),
                                        ]
                                      );
                                    }
                                  ),
                                  0
                                ),
                              ]),
                            ]
                          ),
                        ];
                      },
                      proxy: !0,
                    },
                  ]),
                }),
              ],
              1
            );
          },
          staticRenderFns: [],
        },
        st = i("VU/8")(it, ot, !1, null, null, null).exports,
        nt = {
          name: "Header",
          props: {
            BooleanNext: Boolean,
            BooleanAfter: Boolean,
            HerePage: String,
          },
          data: function () {
            return {
              page_number: this.$root.quiz_number,
              numberQuizOrPage: this.$root.quiz_number,
            };
          },
          methods: {
            run: function () {
              this.page_number = this.$root.quiz_number;
            },
            end_revision: function () {
              (this.$root.quiz_faek = "revision"),
                this.$root.updateSave(),
                this.$router
                  .push({
                    name: "Revision",
                    params: { id: this.$root.app_rand },
                  })
                  .catch(function (t) {});
            },
            nextlist: function () {
              var t = this.page_number,
                e = this.$root.faek_total;
              (this.$root.loader = !0),
                t > e - 1
                  ? this.$router
                      .push({
                        name: "Revision",
                        params: { id: this.$root.app_rand },
                      })
                      .catch(function (t) {})
                  : ((this.$root.quiz_number = this.$root.quiz_number + 1),
                    this.$router
                      .push({
                        name: "Revision Quiz",
                        params: { id: this.$root.app_rand },
                      })
                      .catch(function (t) {})),
                this.$root.updateSave();
            },
            backlist: function () {
              (this.$root.loader = !0),
                (this.$root.quiz_number = this.$root.quiz_number - 1),
                this.$router
                  .push({
                    name: "Revision Quiz",
                    params: { id: this.$root.app_rand },
                  })
                  .catch(function (t) {}),
                this.$root.updateSave();
            },
          },
          watch: {
            "$root.quiz_number": function () {
              this.run();
            },
          },
        },
        at = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              {
                staticClass:
                  "row footer w-100 m-0 w-100 py-1 px-3 quiz_footer justify-content-between align-items-center bg-DarkBlueOldColor justify-content-center",
              },
              [
                i(
                  "div",
                  { staticClass: "py-0 col-4 d-flex justify-content-start" },
                  [
                    t._m(0),
                    t._v(" "),
                    i(
                      "button",
                      {
                        staticClass:
                          "rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white",
                        attrs: { disabled: this.$root.loader },
                        on: { click: t.end_revision },
                      },
                      [t._m(1)]
                    ),
                  ]
                ),
                t._v(" "),
                i(
                  "div",
                  { staticClass: "py-0 d-flex justify-content-end col-8" },
                  [
                    1 != t.page_number && null != t.page_number
                      ? i(
                          "button",
                          {
                            staticClass:
                              "rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link",
                            attrs: { disabled: this.$root.loader },
                            on: { click: t.backlist },
                          },
                          [t._m(2)]
                        )
                      : t._e(),
                    t._v(" "),
                    i(
                      "button",
                      {
                        staticClass:
                          "rounded-0 border-end border-2 btn btn-link py-2 text-decoration-none text-white",
                        attrs: { disabled: t.$root.loader },
                        on: { click: t.nextlist },
                      },
                      [t._m(3)]
                    ),
                  ]
                ),
              ]
            );
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "button",
                {
                  staticClass:
                    "rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white",
                },
                [
                  e("h6", { staticClass: "cursor_pointer my-0 fontsizequiz" }, [
                    e("i", { staticClass: "fa-solid fa-circle-info" }),
                    this._v(
                      "\n                    المعادلات\n                "
                    ),
                  ]),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h6",
                { staticClass: "cursor_pointer my-0 fontsizequiz" },
                [
                  this._v(
                    "\n                العودة للمراجعة\n                "
                  ),
                  e("i", {
                    staticClass: "fa-solid fa-arrow-right-from-bracket",
                  }),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h6",
                { staticClass: "cursor_pointer my-0 fontsizequiz" },
                [
                  e("i", { staticClass: "fa-solid fa-arrow-right" }),
                  this._v("\n                السابق\n            "),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h6",
                { staticClass: "cursor_pointer my-0 fontsizequiz" },
                [
                  this._v("\n                التالي\n                "),
                  e("i", { staticClass: "fa-solid fa-arrow-left" }),
                ]
              );
            },
          ],
        },
        rt = {
          name: "Quiz",
          components: {
            Header: et,
            Single: st,
            Footer: i("VU/8")(nt, at, !1, null, null, null).exports,
            Loader: A,
          },
          data: function () {
            return {
              number_page: this.$root.quiz_number,
              minute: 5,
              seconds: this.$root.faek_time.seconds,
              date: this.$root.thatdatea,
              timer: this.$root.timer,
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), G.xstop();
                          case 2:
                            return (e.next = 4), t.$root.appSave();
                          case 4:
                            1 == t.$root.quiz_revision
                              ? (t.date = t.$root.thatdatea)
                              : 2 == t.$root.quiz_revision
                              ? (t.date = t.$root.thatdateb)
                              : 3 == t.$root.quiz_revision
                              ? (t.date = t.$root.thatdatec)
                              : 4 == t.$root.quiz_revision &&
                                (t.date = t.$root.thatdated),
                              t.floader(),
                              G.xstart(t),
                              t.$root.updateSave(),
                              t.thistime();
                          case 9:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            floader: function () {
              var t = this;
              setInterval(function () {
                t.$root.loader = !1;
              }, 500);
            },
            nextlist: function () {
              if ("00:00" == this.timer) {
                G.xstop();
                var t = this.$root.quiz_revision;
                (this.$root.quiz_faek = "separation"),
                  (this.$root.quiz_number = 0),
                  1 == t
                    ? ((this.$root.quiz_revision = 2),
                      this.$root.updateSave(),
                      this.$router
                        .push("/separation/" + this.$root.app_rand)
                        .catch(function (t) {}))
                    : 2 == t
                    ? ((this.$root.quiz_revision = 3),
                      this.$root.updateSave(),
                      this.$router
                        .push("/separation/" + this.$root.app_rand)
                        .catch(function (t) {}))
                    : 3 == t
                    ? ((this.$root.quiz_revision = 4),
                      this.$root.updateSave(),
                      this.$router
                        .push("/separation/" + this.$root.app_rand)
                        .catch(function (t) {}))
                    : 4 == t &&
                      ((this.$root.quiz_faek = "end"),
                      (this.$root.quiz_revision = 5),
                      this.$root.updateSave(),
                      this.$router
                        .push({ name: "End", path: "/end" })
                        .catch(function (t) {}));
              }
            },
            dragElement: function (t) {
              var e = document.getElementById(t),
                i = 0,
                o = 0,
                s = 0,
                n = 0;
              function a(t) {
                (t = t || window.event).preventDefault(),
                  (s = t.clientX),
                  (n = t.clientY),
                  (document.onmouseup = u),
                  (document.onmousemove = r);
              }
              function r(t) {
                (t = t || window.event).preventDefault(),
                  (i = s - t.clientX),
                  (o = n - t.clientY),
                  (s = t.clientX),
                  (n = t.clientY),
                  (e.style.top = e.offsetTop - o + "px"),
                  (e.style.left = e.offsetLeft - i + "px");
              }
              function u() {
                (document.onmouseup = null), (document.onmousemove = null);
              }
              document.getElementById(e.id + "header")
                ? (document.getElementById(e.id + "header").onmousedown = a)
                : (e.onmousedown = a);
            },
            openModal: function (t) {
              p()(t).attr("class", "modal fade show"),
                p()(t).attr("style", "display: block; padding-left: 0px;");
            },
            closeModal: function (t) {
              p()(t).attr("class", "modal fade"), p()(t).attr("style", "");
            },
            thistime: function () {
              0 == this.minute &&
                0 == this.seconds &&
                (G.xstop(),
                p()("p#clock").html(
                  '<i class="fa-regular fa-clock"></i> انتهى الوقت'
                ));
            },
            poplow: function () {
              (this.$root.popsendtime = !1),
                this.$root.updateSave(),
                closeModal("#statictime");
            },
          },
          mounted: function () {
            this.run();
          },
          watch: {
            "$root.quiz_number": "run",
            timer: function () {
              (this.$root.faek_time.minute = this.minute),
                (this.$root.faek_time.seconds = this.seconds),
                (this.$root.timer = this.timer),
                this.minute < 5 &&
                  (this.$root.pops &&
                    this.$root.popsendtime &&
                    ((this.$root.pops = !1), this.openModal("#statictime")),
                  this.thistime(),
                  p()("p#clock").attr("style", "color:yellow !important;")),
                "00:00" == this.timer && this.openModal("#staticendtime"),
                this.$root.updateSave();
            },
          },
        },
        ut = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i("div", { staticClass: "heyisnone" }, [
              i(
                "div",
                { staticClass: "row m-0" },
                [
                  i("Header", {
                    attrs: {
                      BooleanTimer: !0,
                      BooleanNumQuiz: !0,
                      BooleanTagSave: !0,
                    },
                  }),
                  t._v(" "),
                  i(
                    "div",
                    { staticClass: "col-12 p-0 position-relative" },
                    [
                      t.$root.loader ? i("Loader") : t._e(),
                      t._v(" "),
                      i("Single"),
                    ],
                    1
                  ),
                  t._v(" "),
                  i("Footer", {
                    attrs: {
                      HerePage: "quiz",
                      BooleanNext: !0,
                      BooleanAfter: !0,
                    },
                  }),
                ],
                1
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "statictime",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("statictime");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "statictimeheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          t._m(0),
                          t._v(" "),
                          t._m(1),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-secondary rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: { click: t.poplow },
                                },
                                [
                                  t._v(
                                    "\n                حسناُ\n                "
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass: "modal fade",
                  attrs: {
                    id: "staticendtime",
                    "data-bs-backdrop": "static",
                    "data-bs-keyboard": "false",
                    tabindex: "-1",
                    "aria-labelledby": "staticBackdropLabel",
                    "aria-hidden": "true",
                  },
                  on: {
                    mousedown: function (e) {
                      return t.dragElement("staticendtime");
                    },
                  },
                },
                [
                  i(
                    "div",
                    {
                      staticClass: "modal-dialog",
                      attrs: { id: "staticendtimeheader" },
                    },
                    [
                      i(
                        "div",
                        { staticClass: "modal-content border-0 rounded-0" },
                        [
                          t._m(2),
                          t._v(" "),
                          t._m(3),
                          t._v(" "),
                          i(
                            "div",
                            {
                              staticClass:
                                "modal-footer justify-content-center",
                            },
                            [
                              i(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-secondary rounded-0 border-1 border-white",
                                  attrs: { type: "button" },
                                  on: { click: t.nextlist },
                                },
                                [
                                  t._v(
                                    "\n                موافق\n                "
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
            ]);
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-header py-1" }, [
                e(
                  "h1",
                  {
                    staticClass: "modal-title fs-5",
                    attrs: { id: "staticBackdropLabel" },
                  },
                  [
                    e("i", { staticClass: "fa-regular fa-clock" }),
                    this._v(
                      "\n                    تبقى خمس دقائق\n                "
                    ),
                  ]
                ),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("+MlX") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\n                        لديك 5 دقائق فقط لإنهاء هذا القسم\n                    "
                    ),
                  ]),
                ]),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-header py-1" }, [
                e(
                  "h1",
                  {
                    staticClass: "modal-title fs-5",
                    attrs: { id: "staticBackdropLabel" },
                  },
                  [
                    e("i", { staticClass: "fa-regular fa-clock" }),
                    this._v(
                      "\n                    انتهى الوقت\n                "
                    ),
                  ]
                ),
              ]);
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e("div", { staticClass: "modal-body row" }, [
                e("div", { staticClass: "col-1" }, [
                  e("img", { attrs: { src: i("+MlX") } }),
                ]),
                this._v(" "),
                e("div", { staticClass: "col-11" }, [
                  e("p", [
                    this._v(
                      "\n                      إنتهت المدة المسموحة لحل القسم - إضغط موافق للمتابعة\n                    "
                    ),
                  ]),
                ]),
              ]);
            },
          ],
        },
        ct = i("VU/8")(rt, ut, !1, null, null, null).exports,
        lt = {
          name: "Revision",
          components: { Header: $, Footer: U, Loader: A },
          data: function () {
            return {
              TgImage: g.a,
              TsImage: P.a,
              page: this.$route.params.id,
              minute: 5,
              seconds: 5,
              date: this.$root.thatdatea,
              timer: this.$root.timer,
              plus: !1,
              plustime: "00:10",
              quiz_joab: [],
              quiz_revision: 0,
              totalnone: 0,
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), t.$root.appSave();
                          case 2:
                            G.xstop(),
                              t.floader(),
                              (t.$root.quiz_number = 1),
                              (t.$root.faek_total = t.$root.quiz_total),
                              t.xsp(),
                              t.$root.updateSave();
                          case 8:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            rnp: function (t, e) {
              var i = e,
                o = this.$root.quiz_total;
              return 1 != i ? t - 1 + o * (i - 1) : t - 1;
            },
            floader: function () {
              var t = this;
              setInterval(function () {
                t.$root.loader = !1;
              }, 2e3);
            },
            check_quiz: function (t, e) {
              var i = [],
                o = e,
                s = this.$root.quizs;
              1 == o
                ? (i = this.$root.quiz_joab.a)
                : 2 == o
                ? (i = this.$root.quiz_joab.b)
                : 3 == o
                ? (i = this.$root.quiz_joab.c)
                : 4 == o && (i = this.$root.quiz_joab.d);
              for (var n = 0; n < i.length; n++)
                if (
                  Number(i[n].id) == Number(t) &&
                  s.questions[n].options[i[n].joab].is_true
                )
                  return '<i class="fa-solid fa-check" style="float: right;color:green"></i>';
              return '<i class="fa-solid fa-xmark" style="float: right;color:red"></i>';
            },
            tcquiz: function (t) {
              var e = [],
                i = 0,
                o = t,
                s = this.$root.quizs;
              1 == o
                ? (e = this.$root.quiz_joab.a)
                : 2 == o
                ? (e = this.$root.quiz_joab.b)
                : 3 == o
                ? (e = this.$root.quiz_joab.c)
                : 4 == o && (e = this.$root.quiz_joab.d);
              for (var n = 0; n < e.length; n++)
                1 == Boolean(s.questions[n].options[e[n].joab].is_true) && i++;
              return i;
            },
            xtotalfalse: function (t) {
              var e = [],
                i = 0,
                o = t,
                s = this.$root.quizs;
              1 == o
                ? (e = this.$root.quiz_joab.a)
                : 2 == o
                ? (e = this.$root.quiz_joab.b)
                : 3 == o
                ? (e = this.$root.quiz_joab.c)
                : 4 == o && (e = this.$root.quiz_joab.d);
              for (var n = 0; n < e.length; n++)
                1 != Boolean(s.questions[n].options[e[n].joab].is_true) && i++;
              return i;
            },
            oop: function (t, e) {
              var i = void 0,
                o = e;
              1 == o
                ? (i = this.$root.quiz_joab.a)
                : 2 == o
                ? (i = this.$root.quiz_joab.b)
                : 3 == o
                ? (i = this.$root.quiz_joab.c)
                : 4 == o && (i = this.$root.quiz_joab.d);
              for (var s = 0; s < i.length; s++)
                if (Number(i[s].id) == Number(t)) return "";
              return "غير مكتمل";
            },
            vmg: function (t, e) {
              var i = void 0,
                o = e;
              1 == o
                ? (i = this.$root.quiz_joab.a)
                : 2 == o
                ? (i = this.$root.quiz_joab.b)
                : 3 == o
                ? (i = this.$root.quiz_joab.c)
                : 4 == o && (i = this.$root.quiz_joab.d);
              for (var s = 0; s < i.length; s++)
                if (Number(i[s].id) == Number(t)) return !1;
              return !0;
            },
            xsp: function () {
              for (
                var t,
                  e = [],
                  i = this.$root.quiz_revision,
                  o = this.$root.quiz_total,
                  s = this.$root.quiz_total,
                  n = o * i - o;
                n < (4 == i ? this.ddv() : s * i);
                n++
              )
                this.vmg(n, i) && ((t = { id: n }), e.push(t));
              1 == i
                ? (this.$root.quiz_none.a = e)
                : 2 == i
                ? (this.$root.quiz_none.b = e)
                : 3 == i
                ? (this.$root.quiz_none.c = e)
                : 4 == i && (this.$root.quiz_none.d = e),
                this.$root.updateSave();
            },
            xspx: function (t) {
              for (
                var e,
                  i = [],
                  o = t,
                  s = this.$root.quiz_total,
                  n = this.$root.quiz_total,
                  a = s * o - s;
                a < (4 == o ? this.ddv() : n * o);
                a++
              )
                this.vmg(a, o) && ((e = { id: a }), i.push(e));
              return (
                1 == o
                  ? (this.$root.quiz_none.a = i)
                  : 2 == o
                  ? (this.$root.quiz_none.b = i)
                  : 3 == o
                  ? (this.$root.quiz_none.c = i)
                  : 4 == o && (this.$root.quiz_none.d = i),
                i
              );
            },
            ddv: function () {
              return (
                this.$root.total[0] +
                this.$root.total[1] +
                this.$root.total[2] +
                this.$root.total[3]
              );
            },
            otg: function (t, e) {
              var i = void 0,
                o = e;
              1 == o
                ? (i = this.$root.quiz_tags.a)
                : 2 == o
                ? (i = this.$root.quiz_tags.b)
                : 3 == o
                ? (i = this.$root.quiz_tags.c)
                : 4 == o && (i = this.$root.quiz_tags.d);
              for (var s = 0; s < i.length; s++)
                if (i[s].id == t && i[s].tag) return this.TsImage;
              return this.TgImage;
            },
            xtotaltags: function (t) {
              var e = void 0,
                i = 0,
                o = t;
              1 == o
                ? (e = this.$root.quiz_tags.a)
                : 2 == o
                ? (e = this.$root.quiz_tags.b)
                : 3 == o
                ? (e = this.$root.quiz_tags.c)
                : 4 == o && (e = this.$root.quiz_tags.d);
              for (var s = 0; s < e.length; s++) 1 == Boolean(e[s].tag) && i++;
              return i;
            },
            uod: function (t, e) {
              var i = void 0,
                o = e;
              1 == o
                ? (i = this.$root.quiz_tags.a)
                : 2 == o
                ? (i = this.$root.quiz_tags.b)
                : 3 == o
                ? (i = this.$root.quiz_tags.c)
                : 4 == o && (i = this.$root.quiz_tags.d);
              for (var s = 0; s < i.length; s++)
                if (i[s].id == t && i[s].tag) return !0;
              return !1;
            },
            ueq: function () {
              for (
                var t,
                  e = [],
                  i = this.$root.quiz_revision,
                  o = this.$root.quiz_total,
                  s = o * i - o;
                s < o * i;
                s++
              )
                this.uod(s, i) && ((t = { id: s }), e.push(t));
              1 == i
                ? (this.$root.quiz_tags.a = e)
                : 2 == i
                ? (this.$root.quiz_tags.b = e)
                : 3 == i
                ? (this.$root.quiz_tags.c = e)
                : 4 == i && (this.$root.quiz_tags.d = e);
            },
            btn: function (t, e) {
              (this.$root.quiz_faek = "end_quiz"),
                (this.$root.rev_faek = e),
                (this.$root.revision = 0),
                (this.$root.quiz_number = t),
                (this.$root.faek_total = this.$root.total[e - 1]),
                this.$root.updateSave(),
                this.$router
                  .push({
                    name: "EndQuiz",
                    params: { id: this.$root.app_rand },
                  })
                  .catch(function (t) {});
            },
            openModal: function (t) {
              p()(t).attr("class", "modal fade show"),
                p()(t).attr("style", "display: block; padding-left: 0px;");
            },
            closeModal: function (t) {
              p()(t).attr("class", "modal fade"), p()(t).attr("style", "");
            },
            xtotalnone: function (t) {
              return this.xspx(t).length;
            },
          },
          mounted: function () {
            this.run();
          },
          created: function () {
            this.run();
          },
          watch: {
            totalnone: function () {
              this.$root.totalnone = this.totalnone;
            },
            "$root.quiz_number": "run",
          },
        },
        dt = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i("div", { staticClass: "heyisnone" }, [
              i(
                "div",
                { staticClass: "row m-0" },
                [
                  i("Header", {
                    attrs: {
                      BooleanTimer: !1,
                      BooleanNumQuiz: !1,
                      BooleanTagSave: !1,
                    },
                  }),
                  t._v(" "),
                  i("div"),
                  t._v(" "),
                  i(
                    "div",
                    {
                      staticClass:
                        "col-12 p-0 position-relative overflow-hidden",
                    },
                    [
                      this.$root.loader ? i("Loader") : t._e(),
                      t._v(" "),
                      i("div", { staticClass: "row mb-6 revision-cards" }, [
                        i(
                          "div",
                          { staticClass: "col-12 p-0" },
                          [
                            i("h3", { staticClass: "text-center py-2" }, [
                              t._v(
                                "\n                        شكراً لك\n                    "
                              ),
                            ]),
                            t._v(" "),
                            i("div", { staticClass: "row" }, [
                              i(
                                "div",
                                {
                                  staticClass:
                                    "backGrd py-2 px-4 text-end text-white",
                                },
                                [
                                  t._v(
                                    "\n                            الاحصائيات ونتيجة النهائية\n                        "
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "button",
                                {
                                  staticClass:
                                    "quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2",
                                  attrs: { type: "button" },
                                },
                                [
                                  t._v(
                                    "\n                            عدد الاسئلة الأختبار\n                            "
                                  ),
                                  i(
                                    "div",
                                    { staticClass: "text-danger float-start" },
                                    [
                                      t._v(
                                        "\n                                ( " +
                                          t._s(
                                            t.$root.total[0] +
                                              t.$root.total[1] +
                                              t.$root.total[2] +
                                              t.$root.total[3]
                                          ) +
                                          " )\n                            "
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "button",
                                {
                                  staticClass:
                                    "quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2",
                                  attrs: { type: "button" },
                                },
                                [
                                  t._v(
                                    "\n                            غير مكتمل\n                            "
                                  ),
                                  i(
                                    "div",
                                    { staticClass: "text-danger float-start" },
                                    [
                                      t._v(
                                        "\n                                ( " +
                                          t._s(
                                            t.xtotalnone(1) +
                                              t.xtotalnone(2) +
                                              t.xtotalnone(3) +
                                              t.xtotalnone(4)
                                          ) +
                                          " )\n                            "
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "button",
                                {
                                  staticClass:
                                    "quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2",
                                  attrs: { type: "button" },
                                },
                                [
                                  t._v(
                                    "\n                            الأجابات الصحيحة\n                            "
                                  ),
                                  i(
                                    "div",
                                    { staticClass: "text-danger float-start" },
                                    [
                                      t._v(
                                        "\n                                ( " +
                                          t._s(
                                            t.tcquiz(1) +
                                              t.tcquiz(2) +
                                              t.tcquiz(3) +
                                              t.tcquiz(4)
                                          ) +
                                          " )\n                            "
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "button",
                                {
                                  staticClass:
                                    "quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2",
                                  attrs: { type: "button" },
                                },
                                [
                                  t._v(
                                    "\n                            الأجابات الخاطئة\n                            "
                                  ),
                                  i(
                                    "div",
                                    { staticClass: "text-danger float-start" },
                                    [
                                      t._v(
                                        "\n                                ( " +
                                          t._s(
                                            t.xtotalfalse(1) +
                                              t.xtotalfalse(2) +
                                              t.xtotalfalse(3) +
                                              t.xtotalfalse(4)
                                          ) +
                                          " )\n                            "
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "button",
                                {
                                  staticClass:
                                    "quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2",
                                  attrs: { type: "button" },
                                },
                                [
                                  t._v(
                                    "\n                            الأسئلة المميزة بالعلامة\n                            "
                                  ),
                                  i(
                                    "div",
                                    { staticClass: "text-danger float-start" },
                                    [
                                      t._v(
                                        "\n                                ( " +
                                          t._s(
                                            t.xtotaltags(1) +
                                              t.xtotaltags(2) +
                                              t.xtotaltags(3) +
                                              t.xtotaltags(4)
                                          ) +
                                          " )\n                            "
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                              t._v(" "),
                              t._m(0),
                            ]),
                            t._v(" "),
                            i("hr"),
                            t._v(" "),
                            t._l(4, function (e) {
                              return i(
                                "div",
                                { key: e },
                                [
                                  i(
                                    "div",
                                    {
                                      staticClass:
                                        "backGrd py-2 px-4 text-end text-white",
                                    },
                                    [
                                      t._v(
                                        "\n                                الباب \n                                " +
                                          t._s(e) +
                                          "\n                                جزء الحالي\n\n                                "
                                      ),
                                      i("div", { staticClass: "float-start" }, [
                                        t._v(
                                          "\n                                    (غير مكتمل/غير مرئي " +
                                            t._s(t.xtotalnone(e)) +
                                            " )\n                                "
                                        ),
                                      ]),
                                    ]
                                  ),
                                  t._v(" "),
                                  t._l(t.$root.total[e - 1], function (o) {
                                    return i(
                                      "button",
                                      {
                                        key: o,
                                        staticClass:
                                          "quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2",
                                        attrs: { type: "button" },
                                        on: {
                                          click: function (i) {
                                            return t.btn(o, e);
                                          },
                                        },
                                      },
                                      [
                                        i("div", {
                                          staticClass: "float-end",
                                          staticStyle: { width: "25px" },
                                          domProps: {
                                            innerHTML: t.check_quiz(
                                              t.rnp(o, e),
                                              e
                                            ),
                                          },
                                        }),
                                        t._v(" "),
                                        i("img", {
                                          attrs: { src: t.otg(t.rnp(o, e), e) },
                                        }),
                                        t._v(
                                          "\n                            سؤال " +
                                            t._s(o) +
                                            "\n                            "
                                        ),
                                        i(
                                          "div",
                                          {
                                            staticClass:
                                              "text-danger float-start",
                                          },
                                          [
                                            t._v(
                                              "\n                                " +
                                                t._s(t.oop(t.rnp(o, e), e)) +
                                                "\n                            "
                                            ),
                                          ]
                                        ),
                                      ]
                                    );
                                  }),
                                  t._v(" "),
                                  i(
                                    "div",
                                    {
                                      staticClass:
                                        "quizmobi btn rounded-0 col-12 text-end py-2 px-4 border-bottom border-start border-2",
                                      staticStyle: { background: "#dee2e6" },
                                    },
                                    [
                                      i(
                                        "b",
                                        {
                                          staticClass: "text-success float-end",
                                        },
                                        [
                                          t._v(
                                            "\n                                الأجابات الصحيحة : " +
                                              t._s(t.tcquiz(e)) +
                                              "\n                            "
                                          ),
                                        ]
                                      ),
                                      t._v(" "),
                                      i(
                                        "b",
                                        {
                                          staticClass:
                                            "text-danger float-start",
                                        },
                                        [
                                          t._v(
                                            "\n                                الأجابات الخاطئة : " +
                                              t._s(t.xtotalfalse(e)) +
                                              "\n                            "
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                  t._v(" "),
                                  i("hr"),
                                ],
                                2
                              );
                            }),
                          ],
                          2
                        ),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
            ]);
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "button",
                {
                  staticClass:
                    "quizmobi btn rounded-0 col-12 col-md-4 text-end py-2 px-4 border-bottom border-start border-2",
                  attrs: { type: "button" },
                },
                [
                  this._v(
                    "\n                            عدد الأقسام\n                            "
                  ),
                  e("div", { staticClass: "text-danger float-start" }, [
                    this._v(
                      "\n                                ( 4 )\n                            "
                    ),
                  ]),
                ]
              );
            },
          ],
        },
        ht = i("VU/8")(lt, dt, !1, null, null, null).exports,
        mt = {
          name: "Header",
          props: {
            BooleanTimer: Boolean,
            BooleanNumQuiz: Boolean,
            BooleanTagSave: Boolean,
          },
          data: function () {
            return {
              TgImage: f.a,
              TsImage: g.a,
              number_page: this.$root.quiz_number,
              feak_total: this.$root.faek_total,
              xselected: 18,
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            (t.number_page = t.$root.quiz_number),
                              (t.xselected = t.$root.fontsizequiz),
                              t.arrSave();
                          case 3:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            funSave: function () {
              var t = !0,
                e = this.$root.faek_num,
                i = { id: e, tag: !0 },
                o = void 0,
                s = this.$root.rev_faek;
              1 == s
                ? (o = this.$root.quiz_tags.a)
                : 2 == s
                ? (o = this.$root.quiz_tags.b)
                : 3 == s
                ? (o = this.$root.quiz_tags.c)
                : 4 == s && (o = this.$root.quiz_tags.d);
              for (var n = 0; n < o.length; n++)
                if (o[n].id == e) {
                  o[n].tag ? (o[n].tag = !1) : (o[n].tag = !0), (t = !1);
                  break;
                }
              t && o.push(i),
                1 == s
                  ? (this.$root.quiz_tags.a = o)
                  : 2 == s
                  ? (this.$root.quiz_tags.b = o)
                  : 3 == s
                  ? (this.$root.quiz_tags.c = o)
                  : 4 == s && (this.$root.quiz_tags.d = o),
                this.arrSave();
            },
            tag: function () {
              var t = this.$root.faek_num,
                e = void 0,
                i = this.$root.rev_faek;
              1 == i
                ? (e = this.$root.quiz_tags.a)
                : 2 == i
                ? (e = this.$root.quiz_tags.b)
                : 3 == i
                ? (e = this.$root.quiz_tags.c)
                : 4 == i && (e = this.$root.quiz_tags.d);
              for (var o = 0; o < e.length; o++)
                if (e[o].id == t && e[o].tag) return f.a;
              return g.a;
            },
            arrSave: function () {
              var t = this.$root.rev_faek,
                e = void 0,
                i = [];
              1 == t
                ? (e = this.$root.quiz_tags.a)
                : 2 == t
                ? (e = this.$root.quiz_tags.b)
                : 3 == t
                ? (e = this.$root.quiz_tags.c)
                : 4 == t && (e = this.$root.quiz_tags.d);
              for (var o = 0; o < e.length; o++) e[o].tag && i.push(e[o]);
              (i = i),
                1 == t
                  ? (this.$root.quiz_tags.a = i)
                  : 2 == t
                  ? (this.$root.quiz_tags.b = i)
                  : 3 == t
                  ? (this.$root.quiz_tags.c = i)
                  : 4 == t && (this.$root.quiz_tags.d = i),
                this.$root.updateSave();
            },
            FunNumQuiz: function (t) {
              p()(t).toggleClass("active");
            },
            vselected: function () {
              (this.$root.fontsizequiz = this.xselected),
                p()("style#one").html(
                  ".fontsizequiz {font-size: " +
                    this.xselected +
                    "px!important;}"
                ),
                this.$root.updateSave();
            },
            checkselected: function () {
              this.xselected = this.$root.fontsizequiz;
            },
          },
          mounted: function () {
            this.tag();
          },
          watch: {
            xselected: "vselected",
            "$root.fontsizequiz": "checkselected",
            "$root.quiz_number": function () {
              this.run(), this.tag(), this.vselected();
            },
          },
        },
        pt = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i("div", { staticClass: "m-0 p-0" }, [
              i(
                "div",
                {
                  staticClass:
                    "col-12 header d-flex flex-column flex-md-row flex-lg-row flex-xl-row py-3 px-2 justify-content-between align-items-center bg-DarkBlueOldColor p-1",
                },
                [
                  t._m(0),
                  t._v(" "),
                  i(
                    "div",
                    {
                      staticClass:
                        "mt-2 mt-md-0 mt-lg-0 mt-xl-0 d-flex flex-column align-items-start align-items-md-end align-items-lg-end align-items-xl-end col-md-6 col-lg-6 col-12",
                    },
                    [
                      i("p", { staticClass: "textquiz m-0 f-12 text-white" }, [
                        t._v(
                          "\n            القسم : " +
                            t._s(t.$root.rev_faek) +
                            "\n        "
                        ),
                      ]),
                      t._v(" "),
                      i("div", [
                        t.BooleanNumQuiz
                          ? i(
                              "p",
                              {
                                staticClass: "textquiz m-0 f-12 mt-1",
                                attrs: { id: "quiznumbers" },
                                on: {
                                  click: function (e) {
                                    return t.FunNumQuiz("p#quiznumbers");
                                  },
                                },
                              },
                              [
                                i("i", { staticClass: "fa-solid fa-scroll" }),
                                t._v(" "),
                                i("span", [t._v(t._s(t.number_page))]),
                                t._v(
                                  "\n                    من\n                    "
                                ),
                                i("span", [
                                  t._v(
                                    "\n                        " +
                                      t._s(t.feak_total) +
                                      "\n                    "
                                  ),
                                ]),
                              ]
                            )
                          : t._e(),
                      ]),
                    ]
                  ),
                ]
              ),
              t._v(" "),
              i(
                "div",
                {
                  staticClass:
                    "col-12 downTag align-items-center justify-content-start justify-content-md-end justify-content-lg-end justify-content-xl-end bg-BlueOldColor py-2 px-4",
                },
                [
                  t.BooleanTagSave
                    ? i("div", [
                        i(
                          "button",
                          {
                            staticClass:
                              "btn cursor_pointer text-white m-0 px-3 fontsizequiz",
                            attrs: { type: "button" },
                            on: { click: t.funSave },
                          },
                          [
                            i("img", {
                              staticClass: "clock_img",
                              attrs: { src: t.tag(), alt: "img" },
                            }),
                            t._v(
                              "\n            تميز السؤال للمراجعة\n            "
                            ),
                          ]
                        ),
                        t._v(" "),
                        i(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: t.xselected,
                                expression: "xselected",
                              },
                            ],
                            staticClass:
                              "d-inline-block form-select form-select-sm rounded-0 w-auto",
                            staticStyle: {
                              "background-color": "#588cc5",
                              color: "white",
                            },
                            on: {
                              change: function (e) {
                                var i = Array.prototype.filter
                                  .call(e.target.options, function (t) {
                                    return t.selected;
                                  })
                                  .map(function (t) {
                                    return "_value" in t ? t._value : t.value;
                                  });
                                t.xselected = e.target.multiple ? i : i[0];
                              },
                            },
                          },
                          [
                            i("option", [
                              t._v(
                                "\n                    تغيير حجم الخط\n                "
                              ),
                            ]),
                            t._v(" "),
                            t._l([18, 20, 24, 26], function (e, o) {
                              return i(
                                "option",
                                {
                                  key: o,
                                  domProps: {
                                    value: e,
                                    selected: t.xselected == e,
                                  },
                                },
                                [
                                  t._v(
                                    "\n                    " +
                                      t._s(e) +
                                      "\n                "
                                  ),
                                ]
                              );
                            }),
                          ],
                          2
                        ),
                      ])
                    : t._e(),
                ]
              ),
            ]);
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "div",
                {
                  staticClass: "col-md-6 col-lg-6 col-12 text-end fontsizequiz",
                },
                [
                  e("strong", { staticClass: "m-0 increase_font" }, [
                    this._v("إختبار أكاديمية الحوت على الحاسب الآلي"),
                  ]),
                  this._v("\n        أحمد إبراهيم عادل\n        "),
                ]
              );
            },
          ],
        },
        vt = i("VU/8")(mt, pt, !1, null, null, null).exports,
        ft = {
          name: "Single",
          components: {
            DragCol: Y.a,
            DragRow: Y.b,
            ResizeCol: Y.d,
            ResizeRow: Y.e,
            Resize: Y.c,
          },
          data: function () {
            return {
              page: this.$root.quiz_number,
              quiz: this.$root.quizs,
              joab: [!1, !1, !1, !1],
              number_quiz: 0,
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  var i, o, s;
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), t.$root.appSave();
                          case 2:
                            (i = t.$root.revision),
                              (t.page = t.$root.quiz_number - 1),
                              (t.quiz = t.$root.quizs),
                              (o = t.$root.rev_faek),
                              (s = t.$root.quiz_total),
                              t.checkedis(),
                              1 == i
                                ? t.quizs_none()
                                : 2 == i
                                ? t.quizs_tags()
                                : 1 != o
                                ? ((t.number_quiz =
                                    t.$root.quiz_number - 1 + s * (o - 1)),
                                  (t.$root.faek_num =
                                    t.$root.quiz_number - 1 + s * (o - 1)))
                                : ((t.number_quiz = t.$root.quiz_number - 1),
                                  (t.$root.faek_num = t.$root.quiz_number - 1)),
                              t.$root.updateSave();
                          case 10:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            rnp: function (t) {
              var e = this.$root.rev_faek,
                i = this.$root.total[e - 1];
              return 1 != e ? t + (i * e - 1) : t;
            },
            check_quiz: function (t) {
              var e = this.number_quiz;
              if (this.$root.quizs.questions[e].options[t].is_true)
                return '<i class="fa-solid fa-check" style="float: right;color:green"></i>';
            },
            quizs_tags: function () {
              var t = void 0,
                e = this.page,
                i = this.$root.rev_faek;
              1 == i
                ? (t = this.$root.quiz_tags.a)
                : 2 == i
                ? (t = this.$root.quiz_tags.b)
                : 3 == i
                ? (t = this.$root.quiz_tags.c)
                : 4 == i && (t = this.$root.quiz_tags.d),
                (this.number_quiz = t[e].id),
                (this.$root.faek_num = t[e].id);
            },
            quizs_none: function () {
              var t = void 0,
                e = this.page,
                i = this.$root.rev_faek;
              1 == i
                ? (t = this.$root.quiz_none.a)
                : 2 == i
                ? (t = this.$root.quiz_none.b)
                : 3 == i
                ? (t = this.$root.quiz_none.c)
                : 4 == i && (t = this.$root.quiz_none.d),
                (this.number_quiz = t[e].id),
                (this.$root.faek_num = t[e].id);
            },
            checkedis: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  var i, o, s, n, r;
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), [!1, !1, !1, !1];
                          case 2:
                            for (
                              t.joab = e.sent,
                                i = t.number_quiz,
                                o = t.$root.rev_faek,
                                s = void 0,
                                1 == o
                                  ? (s = t.$root.quiz_joab.a)
                                  : 2 == o
                                  ? (s = t.$root.quiz_joab.b)
                                  : 3 == o
                                  ? (s = t.$root.quiz_joab.c)
                                  : 4 == o && (s = t.$root.quiz_joab.d),
                                n = t.joab,
                                r = 0;
                              r < s.length;
                              r++
                            )
                              s[r].id == i && (n[s[r].joab] = !0);
                            t.joab = n;
                          case 10:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
          },
          mounted: function () {
            this.run();
          },
          watch: { "$root.quiz_number": "run" },
        },
        _t = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              { staticClass: "m-0 p-0" },
              [
                i("DragCol", {
                  staticStyle: { width: "100%", height: "max-content" },
                  attrs: { dir: "ltr" },
                  scopedSlots: t._u([
                    {
                      key: "left",
                      fn: function () {
                        return [
                          i(
                            "div",
                            { staticClass: "sp_style pt-3 px-3 fontsizequiz" },
                            [
                              i(
                                "h4",
                                {
                                  staticClass:
                                    "quiz_description_1 text-danger fontsizequiz",
                                },
                                [
                                  t._v(
                                    "\n                    استيعاب المقروء\n                "
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "h5",
                                {
                                  staticClass:
                                    "quiz_description_2 text-danger fontsizequiz",
                                },
                                [
                                  t._v(
                                    "\n                    السؤال التالي يتعلق بالنص المرفق , بعد السؤال هناك أربع اختيارات ,\n                    واحد منها صحيح المطلوب , هو قراءة النص بعناية , ثم اختيار الإجابة\n                    الصحيحة\n                "
                                  ),
                                ]
                              ),
                              t._v(" "),
                              i(
                                "h5",
                                {
                                  staticClass:
                                    "quiz_description_2 fontsizequiz",
                                },
                                [
                                  t._v(
                                    "\n                    " +
                                      t._s(
                                        t.quiz.questions[t.number_quiz]
                                          .paragraph
                                      ) +
                                      "\n                "
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ];
                      },
                      proxy: !0,
                    },
                    {
                      key: "right",
                      fn: function () {
                        return [
                          i(
                            "div",
                            { staticClass: "sp_style pt-3 px-3 fontsizequiz" },
                            [
                              i("div", { staticClass: "sp_in_sp" }, [
                                i(
                                  "h4",
                                  { staticClass: "quiz_description_1 mb-3" },
                                  [
                                    i("p", {
                                      domProps: {
                                        innerHTML:
                                          t.quiz.questions[t.number_quiz].name,
                                      },
                                    }),
                                  ]
                                ),
                                t._v(" "),
                                i(
                                  "form",
                                  { ref: "anyName" },
                                  t._l(
                                    t.quiz.questions[t.number_quiz].options,
                                    function (e, o) {
                                      return i(
                                        "div",
                                        {
                                          key: o,
                                          staticClass:
                                            "form-check form-group mt-1 me-4 mb-3",
                                        },
                                        [
                                          i("input", {
                                            staticClass:
                                              "form-check-input float-end ms-2",
                                            attrs: {
                                              type: "radio",
                                              disabled: !0,
                                              name: "exampleRadios",
                                              id:
                                                "exampleRadios" +
                                                t.number_quiz +
                                                "q" +
                                                o,
                                            },
                                            domProps: {
                                              value:
                                                "option" +
                                                t.number_quiz +
                                                "q" +
                                                o,
                                              checked: t.joab[o],
                                            },
                                          }),
                                          t._v(" "),
                                          i(
                                            "label",
                                            {
                                              staticClass: "form-check-label",
                                              attrs: {
                                                for:
                                                  "exampleRadios" +
                                                  t.number_quiz +
                                                  "q" +
                                                  o,
                                              },
                                            },
                                            [
                                              t._v(
                                                "\n                                " +
                                                  t._s(e.name) +
                                                  "\n                                "
                                              ),
                                              null != t.check_quiz(o)
                                                ? i("div", {
                                                    staticClass: "float-start",
                                                    domProps: {
                                                      innerHTML:
                                                        t.check_quiz(o),
                                                    },
                                                  })
                                                : t._e(),
                                            ]
                                          ),
                                        ]
                                      );
                                    }
                                  ),
                                  0
                                ),
                              ]),
                            ]
                          ),
                        ];
                      },
                      proxy: !0,
                    },
                  ]),
                }),
              ],
              1
            );
          },
          staticRenderFns: [],
        },
        gt = i("VU/8")(ft, _t, !1, null, null, null).exports,
        bt = {
          name: "Header",
          props: {
            BooleanNext: Boolean,
            BooleanAfter: Boolean,
            HerePage: String,
          },
          data: function () {
            return {
              page_number: this.$root.quiz_number,
              numberQuizOrPage: this.$root.quiz_number,
            };
          },
          methods: {
            run: function () {
              this.page_number = this.$root.quiz_number;
            },
            end_revision: function () {
              (this.$root.quiz_faek = "end"),
                this.$root.updateSave(),
                this.$router.push({ name: "End", path: "/end" });
            },
            nextlist: function () {
              var t = this.page_number,
                e = this.$root.faek_total;
              (this.$root.loader = !0),
                t > e - 1
                  ? this.$router
                      .push({ name: "End", path: "/end" })
                      .catch(function (t) {})
                  : ((this.$root.quiz_number = this.$root.quiz_number + 1),
                    this.$router
                      .push({
                        name: "EndQuiz",
                        params: { id: this.$root.app_rand },
                      })
                      .catch(function (t) {})),
                this.$root.updateSave();
            },
            backlist: function () {
              (this.$root.loader = !0),
                (this.$root.quiz_number = this.$root.quiz_number - 1),
                this.$router
                  .push({
                    name: "EndQuiz",
                    params: { id: this.$root.app_rand },
                  })
                  .catch(function (t) {}),
                this.$root.updateSave();
            },
          },
          watch: {
            "$root.quiz_number": function () {
              this.run();
            },
          },
        },
        zt = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              {
                staticClass:
                  "row footer w-100 m-0 w-100 py-1 px-3 quiz_footer justify-content-between align-items-center bg-DarkBlueOldColor justify-content-center",
              },
              [
                i(
                  "div",
                  { staticClass: "py-0 col-4 d-flex justify-content-start" },
                  [
                    t._m(0),
                    t._v(" "),
                    i(
                      "button",
                      {
                        staticClass:
                          "rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white",
                        attrs: { disabled: this.$root.loader },
                        on: { click: t.end_revision },
                      },
                      [t._m(1)]
                    ),
                  ]
                ),
                t._v(" "),
                i(
                  "div",
                  { staticClass: "py-0 d-flex justify-content-end col-8" },
                  [
                    1 != t.page_number && null != t.page_number
                      ? i(
                          "button",
                          {
                            staticClass:
                              "rounded-0 border-end ps-3 border-2 py-2 text-decoration-none text-white ms-2 btn btn-link",
                            attrs: { disabled: this.$root.loader },
                            on: { click: t.backlist },
                          },
                          [t._m(2)]
                        )
                      : t._e(),
                    t._v(" "),
                    i(
                      "button",
                      {
                        staticClass:
                          "rounded-0 border-end border-2 btn btn-link py-2 text-decoration-none text-white",
                        attrs: { disabled: t.$root.loader },
                        on: { click: t.nextlist },
                      },
                      [t._m(3)]
                    ),
                  ]
                ),
              ]
            );
          },
          staticRenderFns: [
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "button",
                {
                  staticClass:
                    "rounded-0 border-start border-2 btn btn-link py-2 text-decoration-none text-white",
                },
                [
                  e("h6", { staticClass: "cursor_pointer my-0 fontsizequiz" }, [
                    e("i", { staticClass: "fa-solid fa-circle-info" }),
                    this._v(
                      "\n                    المعادلات\n                "
                    ),
                  ]),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h6",
                { staticClass: "cursor_pointer my-0 fontsizequiz" },
                [
                  this._v("\n                العودة للنتيجة\n                "),
                  e("i", {
                    staticClass: "fa-solid fa-arrow-right-from-bracket",
                  }),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h6",
                { staticClass: "cursor_pointer my-0 fontsizequiz" },
                [
                  e("i", { staticClass: "fa-solid fa-arrow-right" }),
                  this._v("\n                السابق\n            "),
                ]
              );
            },
            function () {
              var t = this.$createElement,
                e = this._self._c || t;
              return e(
                "h6",
                { staticClass: "cursor_pointer my-0 fontsizequiz" },
                [
                  this._v("\n                التالي\n                "),
                  e("i", { staticClass: "fa-solid fa-arrow-left" }),
                ]
              );
            },
          ],
        },
        $t = {
          name: "EndQuiz",
          components: {
            Header: vt,
            Single: gt,
            Footer: i("VU/8")(bt, zt, !1, null, null, null).exports,
            Loader: A,
          },
          data: function () {
            return { number_page: this.$root.quiz_number };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), t.$root.appSave();
                          case 2:
                            1 == t.$root.quiz_revision
                              ? (t.date = t.$root.thatdatea)
                              : 2 == t.$root.quiz_revision
                              ? (t.date = t.$root.thatdateb)
                              : 3 == t.$root.quiz_revision
                              ? (t.date = t.$root.thatdatec)
                              : 4 == t.$root.quiz_revision &&
                                (t.date = t.$root.thatdated),
                              t.floader(),
                              t.$root.updateSave();
                          case 5:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            floader: function () {
              var t = this;
              setInterval(function () {
                t.$root.loader = !1;
              }, 500);
            },
            dragElement: function (t) {
              var e = document.getElementById(t),
                i = 0,
                o = 0,
                s = 0,
                n = 0;
              function a(t) {
                (t = t || window.event).preventDefault(),
                  (s = t.clientX),
                  (n = t.clientY),
                  (document.onmouseup = u),
                  (document.onmousemove = r);
              }
              function r(t) {
                (t = t || window.event).preventDefault(),
                  (i = s - t.clientX),
                  (o = n - t.clientY),
                  (s = t.clientX),
                  (n = t.clientY),
                  (e.style.top = e.offsetTop - o + "px"),
                  (e.style.left = e.offsetLeft - i + "px");
              }
              function u() {
                (document.onmouseup = null), (document.onmousemove = null);
              }
              document.getElementById(e.id + "header")
                ? (document.getElementById(e.id + "header").onmousedown = a)
                : (e.onmousedown = a);
            },
            openModal: function (t) {
              p()(t).attr("class", "modal fade show"),
                p()(t).attr("style", "display: block; padding-left: 0px;");
            },
            closeModal: function (t) {
              p()(t).attr("class", "modal fade"), p()(t).attr("style", "");
            },
            poplow: function () {
              (this.$root.popsendtime = !1),
                this.$root.updateSave(),
                closeModal("#statictime");
            },
          },
          mounted: function () {
            this.run();
          },
          watch: { "$root.quiz_number": "run" },
        },
        qt = {
          render: function () {
            var t = this.$createElement,
              e = this._self._c || t;
            return e("div", { staticClass: "heyisnone" }, [
              e(
                "div",
                { staticClass: "row m-0" },
                [
                  e("Header", {
                    attrs: {
                      BooleanTimer: !1,
                      BooleanNumQuiz: !0,
                      BooleanTagSave: !0,
                    },
                  }),
                  this._v(" "),
                  e(
                    "div",
                    { staticClass: "col-12 p-0 position-relative" },
                    [
                      this.$root.loader ? e("Loader") : this._e(),
                      this._v(" "),
                      e("Single"),
                    ],
                    1
                  ),
                  this._v(" "),
                  e("Footer", {
                    attrs: {
                      HerePage: "quiz",
                      BooleanNext: !0,
                      BooleanAfter: !0,
                    },
                  }),
                ],
                1
              ),
            ]);
          },
          staticRenderFns: [],
        },
        wt = i("VU/8")($t, qt, !1, null, null, null).exports;
      c.a.use(h.a);
      var xt = new h.a({
          mode: "history",
          routes: [
            { path: "/", name: "Start", component: j },
            { path: "/:str", name: "Start tow", component: j },
            { path: "/separation/:id", name: "Separation", component: N },
            { path: "/quiz/:id", name: "Quiz", component: Q },
            { path: "/revision/:id", name: "Revision", component: X },
            { path: "/revision/:id", name: "Revision Quiz", component: ct },
            { path: "/end", name: "End", component: ht },
            { path: "/end/:id", name: "EndQuiz", component: wt },
          ],
        }),
        yt = i("mtWM"),
        Ct = i("ZQ6q"),
        kt = i.n(Ct);
      i("xfsg"), i("qb6w"), i("Q0/0");
      (c.a.config.productionTip = !1),
        new c.a({
          el: "#app",
          router: xt,
          components: { App: d },
          template: "<App/>",
          data: function () {
            return {
              appid: "63b58009c3b56b6177be8d60",
              page_total: 15,
              quizs: [],
              quiz_joab: { a: [], b: [], c: [], d: [] },
              quiz_tags: { a: [], b: [], c: [], d: [] },
              quiz_none: { a: [], b: [], c: [], d: [] },
              seconds: 90,
              sapa_time: { minute: 0, seconds: 10 },
              quiz_time: { minute: 5, seconds: 2 },
              quiz_number: 0,
              quiz_revision: 1,
              faek_total: 12,
              faek_num: 0,
              revision: 0,
              loader: !1,
              pops: !0,
              timer: "00:00",
              loadtimer: '<i class="fas fa-sync fa-spin"></i>',
              faek_time: { minute: 6, seconds: 6 },
              app_rand: "",
              quiz_faek: "start",
              fontsizequiz: 18,
              checkrefrsh: !1,
              thatdatea: 0,
              thatdateb: 0,
              thatdatec: 0,
              thatdated: 0,
              addtimers: !1,
              popsendtime: !0,
              quiz_total: 0,
              total: [0, 0, 0, 0],
              random: "",
              totalnone: 0,
              quiz_viwe: [0, 0, 0, 0],
              isnext: "",
              rev_faek: 0,
            };
          },
          methods: {
            run: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (e.next = 2), t.appSave();
                          case 2:
                            return (
                              (t.random = t.cookeiesRandom(22)),
                              (t.timer = t.loadtimer),
                              (t.loader = !0),
                              (e.next = 7),
                              yt.a
                                .get(
                                  "//ahmedapi.alhutacademy.com/quiz/63b58009c3b56b6177be8d60"
                                )
                                .then(
                                  (function () {
                                    var e = u()(
                                      a.a.mark(function e(i) {
                                        return a.a.wrap(
                                          function (e) {
                                            for (;;)
                                              switch ((e.prev = e.next)) {
                                                case 0:
                                                  (t.quizs = i.data),
                                                    (t.loader = !1),
                                                    t.totaler();
                                                case 3:
                                                case "end":
                                                  return e.stop();
                                              }
                                          },
                                          e,
                                          t
                                        );
                                      })
                                    );
                                    return function (t) {
                                      return e.apply(this, arguments);
                                    };
                                  })()
                                )
                            );
                          case 7:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            appSave: function () {
              var t = this;
              return u()(
                a.a.mark(function e() {
                  var i, o, n, r, u;
                  return a.a.wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            if (kt.a.get("appquiz")) {
                              e.next = 21;
                              break;
                            }
                            (i = t.appid),
                              xt.push("/" + i).catch(function (t) {}),
                              kt.a.set("appquiz", i, { expires: 360 }),
                              kt.a.set("quiz_faek", t.quiz_faek, {
                                expires: 360,
                              }),
                              kt.a.set("quiz_joab", s()(t.quiz_joab), {
                                expires: 360,
                              }),
                              kt.a.set("quiz_tags", s()(t.quiz_tags), {
                                expires: 360,
                              }),
                              kt.a.set("quiz_none", s()(t.quiz_none), {
                                expires: 360,
                              }),
                              kt.a.set("quiz_number", t.quiz_number, {
                                expires: 360,
                              }),
                              kt.a.set("quiz_revision", t.quiz_revision, {
                                expires: 360,
                              }),
                              kt.a.set("faek_total", t.faek_total, {
                                expires: 360,
                              }),
                              kt.a.set("faek_num", t.faek_num, {
                                expires: 360,
                              }),
                              kt.a.set("faek_time", s()(t.faek_time), {
                                expires: 360,
                              }),
                              kt.a.set("timer", t.timer, { expires: 360 }),
                              kt.a.set("revision", t.revision, {
                                expires: 360,
                              }),
                              kt.a.set("fontsizequiz", t.fontsizequiz, {
                                expires: 360,
                              }),
                              kt.a.set("popsendtime", t.popsendtime, {
                                expires: 360,
                              }),
                              kt.a.set("quiz_viwe", s()(t.quiz_viwe), {
                                expires: 360,
                              }),
                              (e.next = 55);
                            break;
                          case 21:
                            return (
                              (o = String(kt.a.get("appquiz"))),
                              (t.app_rand = o),
                              (t.quiz_faek = String(kt.a.get("quiz_faek"))),
                              (e.next = 26),
                              JSON.parse(Array(kt.a.get("quiz_joab")))
                            );
                          case 26:
                            return (
                              (t.quiz_joab = e.sent),
                              (e.next = 29),
                              JSON.parse(Array(kt.a.get("quiz_tags")))
                            );
                          case 29:
                            return (
                              (t.quiz_tags = e.sent),
                              (e.next = 32),
                              JSON.parse(Array(kt.a.get("quiz_none")))
                            );
                          case 32:
                            return (
                              (t.quiz_none = e.sent),
                              (t.quiz_number = Number(kt.a.get("quiz_number"))),
                              (t.quiz_revision = Number(
                                kt.a.get("quiz_revision")
                              )),
                              (t.faek_total = Number(kt.a.get("faek_total"))),
                              (t.faek_num = Number(kt.a.get("faek_num"))),
                              (e.next = 39),
                              JSON.parse(Array(kt.a.get("faek_time")))
                            );
                          case 39:
                            return (
                              (t.faek_time = e.sent),
                              (t.timer = String(kt.a.get("timer"))),
                              (t.revision = Number(kt.a.get("revision"))),
                              (t.fontsizequiz = Number(
                                kt.a.get("fontsizequiz")
                              )),
                              (t.popsendtime = Number(kt.a.get("popsendtime"))),
                              (e.next = 46),
                              JSON.parse(Array(kt.a.get("quiz_viwe")))
                            );
                          case 46:
                            (t.quiz_viwe = e.sent),
                              (t.thatdatea = Number(kt.a.get("thatdatea"))),
                              (t.thatdateb = Number(kt.a.get("thatdateb"))),
                              (t.thatdatec = Number(kt.a.get("thatdatec"))),
                              (t.thatdated = Number(kt.a.get("thatdated"))),
                              (n = new Date().getTime()),
                              t.checkrefrsh ||
                                ("end" != t.quiz_faek &&
                                  (n > t.thatdatea + 15e3 &&
                                  n < t.thatdateb + 15e3
                                    ? ((t.$root.quiz_revision = 2),
                                      (t.$root.quiz_faek = "separation"),
                                      (t.$root.quiz_number = 0),
                                      t.$root.updateSave(),
                                      t.$root.checkdate(),
                                      xt
                                        .push("/separation/" + o)
                                        .catch(function (t) {}))
                                    : n > t.thatdateb + 15e3 &&
                                      n < t.thatdatec + 15e3
                                    ? ((t.$root.quiz_revision = 3),
                                      (t.$root.quiz_faek = "separation"),
                                      (t.$root.quiz_number = 0),
                                      t.$root.updateSave(),
                                      t.$root.checkdate(),
                                      xt
                                        .push("/separation/" + o)
                                        .catch(function (t) {}))
                                    : n > t.thatdatec + 15e3 &&
                                      n < t.thatdated + 15e3
                                    ? ((t.$root.quiz_revision = 4),
                                      (t.$root.quiz_faek = "separation"),
                                      (t.$root.quiz_number = 0),
                                      t.$root.updateSave(),
                                      t.$root.checkdate(),
                                      xt
                                        .push("/separation/" + o)
                                        .catch(function (t) {}))
                                    : n > t.thatdated + 15e3 &&
                                      ((t.$root.quiz_faek = "end"),
                                      (t.$root.quiz_number = 0),
                                      t.$root.updateSave(),
                                      xt.push("/end").catch(function (t) {})))),
                              (r = t.fontsizequiz),
                              p()("style#one").html(
                                ".fontsizequiz {font-size: " +
                                  r +
                                  "px!important;}"
                              );
                          case 55:
                            return (e.next = 57), String(kt.a.get("appquiz"));
                          case 57:
                            (u = e.sent),
                              "start" == t.quiz_faek
                                ? xt.push("/" + u).catch(function (t) {})
                                : "end" == t.quiz_faek &&
                                  xt
                                    .push({ name: "End", path: "/end" })
                                    .catch(function (t) {});
                          case 59:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    t
                  );
                })
              )();
            },
            updateSave: function () {
              if (
                (kt.a.set("quiz_faek", this.quiz_faek),
                kt.a.set("quiz_joab", s()(this.quiz_joab)),
                kt.a.set("quiz_tags", s()(this.quiz_tags)),
                kt.a.set("quiz_none", s()(this.quiz_none)),
                this.checkrefrsh)
              ) {
                if (this.addtimers) {
                  var t = new Date().getTime();
                  (this.thatdatea = this.addMinutes(
                    t,
                    this.seconds * this.quiz_total * 1
                  )),
                    (this.thatdateb = this.addMinutes(
                      t,
                      this.seconds * this.quiz_total * 2
                    )),
                    (this.thatdatec = this.addMinutes(
                      t,
                      this.seconds * this.quiz_total * 3
                    )),
                    (this.thatdated = this.addMinutes(
                      t,
                      this.seconds * this.quiz_total * 4
                    )),
                    kt.a.set("thatdatea", this.thatdatea, { expires: 360 }),
                    kt.a.set("thatdateb", this.thatdateb, { expires: 360 }),
                    kt.a.set("thatdatec", this.thatdatec, { expires: 360 }),
                    kt.a.set("thatdated", this.thatdated, { expires: 360 }),
                    (this.addtimers = !1);
                }
                kt.a.set("quiz_number", this.quiz_number),
                  kt.a.set("popsendtime", this.popsendtime),
                  kt.a.set("fontsizequiz", this.fontsizequiz),
                  kt.a.set("faek_total", this.faek_total),
                  "revision" != this.quiz_faek &&
                    "quiz" != this.quiz_faek &&
                    "end" != this.quiz_faek &&
                    kt.a.set("quiz_revision", this.quiz_revision),
                  kt.a.set("faek_num", this.faek_num),
                  kt.a.set("faek_time", s()(this.faek_time)),
                  kt.a.set("quiz_viwe", s()(this.quiz_viwe));
              }
              kt.a.set("timer", this.timer),
                kt.a.set("revision", this.revision),
                (this.checkrefrsh = !0),
                this.appSave();
            },
            checkdate: function () {
              var t = this.$root.quiz_revision,
                e = new Date().getTime();
              2 == t
                ? ((this.thatdateb = this.addMinutes(
                    e,
                    this.seconds * this.quiz_total * 1
                  )),
                  (this.thatdatec = this.addMinutes(
                    e,
                    this.seconds * this.quiz_total * 2
                  )),
                  (this.thatdated = this.addMinutes(
                    e,
                    this.seconds * this.quiz_total * 3
                  )),
                  kt.a.set("thatdateb", this.thatdateb),
                  kt.a.set("thatdatec", this.thatdatec),
                  kt.a.set("thatdated", this.thatdated))
                : 3 == t
                ? ((this.thatdatec = this.addMinutes(
                    e,
                    this.seconds * this.quiz_total * 1
                  )),
                  (this.thatdated = this.addMinutes(
                    e,
                    this.seconds * this.quiz_total * 2
                  )),
                  kt.a.set("thatdatec", this.thatdatec),
                  kt.a.set("thatdated", this.thatdated))
                : 4 == t &&
                  ((this.thatdated = this.addMinutes(
                    e,
                    this.seconds * this.quiz_total * 1
                  )),
                  kt.a.set("thatdated", this.thatdated));
            },
            cookeiesRandom: function (t) {
              for (
                var e = "",
                  i =
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
                  o = i.length,
                  s = 0;
                s < t;

              )
                (e += i.charAt(Math.floor(Math.random() * o))), (s += 1);
              return e;
            },
            addMinutes: function (t, e) {
              return new Date(t + 1e3 * e).getTime();
            },
            getmin: function (t) {
              var e = t - new Date().getTime();
              return Math.floor((e % 36e5) / 6e4);
            },
            totaler: function () {
              this.quiz_total = this.page_total;
              var t = this.quiz_total,
                e = 4 * t - this.quizs.questions.length;
              this.total = [t, t, t, t - e];
            },
          },
          mounted: function () {
            this.run();
          },
          watch: { $route: "run" },
        });
    },
    "Q0/0": function (t, e) {},
    Vz2c: function (t, e) {},
    YQMY: function (t, e, i) {
      "use strict";
      var o = {
          name: "ResizeCol",
          props: {
            sliderWidth: { type: Number, default: 20 },
            width: { type: Number, default: 400 },
            height: { type: String, default: "400px" },
            sliderColor: { type: String, default: "#6f808d" },
            sliderBgColor: { type: String, default: "#1f2e3a" },
            sliderHoverColor: { type: String, default: "#6f808d" },
            sliderBgHoverColor: { type: String, default: "#16222a" },
          },
          data: function () {
            return { reWidth: this.width, isDragging: !1 };
          },
          methods: {
            mobileResizeCol: function (t) {
              (t = t || window.event).stopPropagation();
              var e = t.changedTouches[0].clientX,
                i = this.reWidth,
                o = 0,
                s = 0,
                n = this;
              (this.isDragging = !0),
                this.$emit("isDragging", this.isDragging),
                (document.ontouchmove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).stopPropagation(),
                    (o = t.changedTouches[0].clientX),
                    (s = parseInt(i - (e - o))) <= 20
                      ? (n.reWidth = 20)
                      : (n.reWidth = s);
                  n.$emit("dragging", n.reWidth);
                }),
                (document.ontouchend = function () {
                  (n.isDragging = !1),
                    n.$emit("isDragging", n.isDragging),
                    (document.ontouchmove = null),
                    (document.ontouchend = null);
                });
            },
            resizeCol: function (t) {
              (t = t || window.event).preventDefault(), t.stopPropagation();
              var e = t.clientX,
                i = this.reWidth,
                o = 0,
                s = 0,
                n = this;
              (this.isDragging = !0),
                this.$emit("isDragging", this.isDragging),
                (document.onmousemove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).preventDefault(),
                    t.stopPropagation(),
                    (o = t.clientX),
                    (s = parseInt(i - (e - o))) <= 20
                      ? (n.reWidth = 20)
                      : (n.reWidth = s);
                  n.$emit("dragging", n.reWidth);
                }),
                (document.onmouseup = function () {
                  (n.isDragging = !1),
                    n.$emit("isDragging", n.isDragging),
                    (document.onmouseup = null),
                    (document.onmousemove = null);
                });
            },
          },
        },
        s = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              {
                staticClass: "resize_col",
                style: { width: t.reWidth + "px", height: t.height },
              },
              [
                i(
                  "div",
                  { staticClass: "resize_col_body" },
                  [t._t("default")],
                  2
                ),
                t._v(" "),
                i("div", {
                  staticClass: "slider_col",
                  style: { width: t.sliderWidth + "px" },
                  on: {
                    "&touchstart": function (e) {
                      return t.mobileResizeCol.apply(null, arguments);
                    },
                    mousedown: t.resizeCol,
                  },
                }),
              ]
            );
          },
          staticRenderFns: [],
        };
      var n = i("VU/8")(
        o,
        s,
        !1,
        function (t) {
          i("o3pi");
        },
        null,
        null
      );
      e.a = n.exports;
    },
    ZKuW: function (t, e, i) {
      "use strict";
      var o = {
          name: "DragRow",
          props: {
            topPercent: { type: Number, default: 50 },
            sliderWidth: { type: Number, default: 20 },
            width: { type: String, default: "400px" },
            height: { type: String, default: "400px" },
            sliderColor: { type: String, default: "#6f808d" },
            sliderBgColor: { type: String, default: "#1f2e3a" },
            sliderHoverColor: { type: String, default: "#6f808d" },
            sliderBgHoverColor: { type: String, default: "#16222a" },
          },
          data: function () {
            return { top: this.topPercent, isDragging: !1 };
          },
          methods: {
            mobileDragRow: function (t) {
              (document.body.style.overflow = "hidden"),
                (document.body.style.overscrollBehaviorY = "contain"),
                (t = t || window.event).stopPropagation();
              var e = t.changedTouches[0].clientY,
                i = this.top,
                o = 0,
                s = 0,
                n = this.$refs.container.offsetHeight,
                a = this;
              (this.isDragging = !0),
                this.$emit("isDragging", this.isDragging),
                (document.ontouchmove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).stopPropagation(),
                    (o = t.changedTouches[0].clientY);
                  var r = parseFloat((((e - o) / n) * 100).toFixed(3));
                  (s = i - r) <= 0 ? (a.top = 0) : (a.top = s >= 100 ? 100 : s);
                  a.$emit("dragging", a.top);
                }),
                (document.ontouchend = function () {
                  (a.isDragging = !1),
                    a.$emit("isDragging", a.isDragging),
                    (document.body.style.overflow = ""),
                    (document.body.style.overscrollBehaviorY = ""),
                    (document.ontouchmove = null),
                    (document.ontouchend = null);
                });
            },
            dragRow: function (t) {
              (t = t || window.event).preventDefault(), t.stopPropagation();
              var e = t.clientY,
                i = this.top,
                o = 0,
                s = 0,
                n = this.$refs.container.offsetHeight,
                a = this;
              (this.isDragging = !0),
                this.$emit("isDragging", this.isDragging),
                (document.onmousemove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).stopPropagation(),
                    (o = t.clientY);
                  var r = parseFloat((((e - o) / n) * 100).toFixed(3));
                  (s = i - r) <= 0 ? (a.top = 0) : (a.top = s >= 100 ? 100 : s);
                  a.$emit("dragging", a.top);
                }),
                (document.onmouseup = function () {
                  (a.isDragging = !1),
                    a.$emit("isDragging", a.isDragging),
                    (document.onmouseup = null),
                    (document.onmousemove = null);
                });
            },
          },
        },
        s = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              {
                ref: "container",
                staticClass: "drager_row",
                style: { width: t.width, height: t.height },
              },
              [
                i(
                  "div",
                  { staticClass: "drager_top", style: { height: t.top + "%" } },
                  [i("div", [t._t("top")], 2)]
                ),
                t._v(" "),
                i("div", {
                  staticClass: "slider_row",
                  style: {
                    height: t.sliderWidth + "px",
                    marginTop: -t.sliderWidth / 2 + "px",
                    marginBottom: -t.sliderWidth / 2 + "px",
                  },
                  on: {
                    "&touchstart": function (e) {
                      return t.mobileDragRow.apply(null, arguments);
                    },
                    mousedown: t.dragRow,
                  },
                }),
                t._v(" "),
                i(
                  "div",
                  {
                    staticClass: "drager_bottom",
                    style: { height: 100 - t.top + "%" },
                  },
                  [i("div", [t._t("bottom")], 2)]
                ),
              ]
            );
          },
          staticRenderFns: [],
        };
      var n = i("VU/8")(
        o,
        s,
        !1,
        function (t) {
          i("LVeW");
        },
        null,
        null
      );
      e.a = n.exports;
    },
    j8xc: function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAYAAADE6YVjAAAACXBIWXMAAAsTAAALEwEAmpwYAAAF8WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNi4wLWMwMDMgNzkuMTY0NTI3LCAyMDIwLzEwLzE1LTE3OjQ4OjMyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjIuMSAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIzLTAxLTEyVDIwOjE3OjA5KzAyOjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIzLTAxLTEyVDIwOjE3OjA5KzAyOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMy0wMS0xMlQyMDoxNzowOSswMjowMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo2MjAxNGExMC0yMWU4LTE4NDQtOGMyYS1jMGYwYWJmMmU0ODIiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo2NzQ4ODg3Mi05ZTJiLWQ4NDItYjRiNC03NzZiMTcyNGEwOTkiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDphZDRkNWY3Zi1hZjI4LTA5NGQtYTQ5Mi1iMzQyZGNmNDVlY2IiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmFkNGQ1ZjdmLWFmMjgtMDk0ZC1hNDkyLWIzNDJkY2Y0NWVjYiIgc3RFdnQ6d2hlbj0iMjAyMy0wMS0xMlQyMDoxNzowOSswMjowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDIyLjEgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo2MjAxNGExMC0yMWU4LTE4NDQtOGMyYS1jMGYwYWJmMmU0ODIiIHN0RXZ0OndoZW49IjIwMjMtMDEtMTJUMjA6MTc6MDkrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMi4xIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6FK45wAAABX0lEQVRIie3VsUscQRjG4UexSJdSbfMH2AhaGEGwMkawCaRJoQbSuJ3lZZfdgIWFELaKCMG0sQtoJSLmGkEUG7GxsRIriyCiuCluimNznkpOBfGFl9n9hm9+M9/OzLYVReG+1X7vBHRc15FFSR8mMIxOnGILS3Ge/mqSV43zdKA+1taoXFmU/MCHJpNbw5c4TzdKeV3YifO0+zYreRfaeXzHEV7iPabUVjecRUkVVVygF0N4UR7s2nIFVXAWnk8xh6/4jDEMBDfVTZBGOg/wCl4HSAe2sdoqSL1+BzfVg2zhpwO56ZuMYhCvcIxNrOCklZCfpfep0C5iRm1b/xekUDtoyzhUu1re4C0+Bn/DEi4xflfIfpjpepyn9ffOYhYlPZjFCD4F1+vqtpD+OE8vGnXEebqXRckY+jCJnjDOARaQ/5NUFEVLnU7Hu+XY0zknz5BHh/wpBxr+41utBynXXx+snOsCtKX3AAAAAElFTkSuQmCC";
    },
    lk7M: function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAYuSURBVHjaYvz//z/DQAKAACIbnfZhUDzmyaAEZDIBMSO55gAEEBM5mi74MjSyMzHc42FluAt0RBtQiINcswACiJkcn7MyMawT1GVg4BRnYPj3hsGGl5Vh69FXDG+A0n9JNQ8ggEh2NRsTw3xmoH8lXSAYxA6QZZgElOIlx0MAAcREYtAHAiPbHmYxzCHAqDCZZ80QAlTCSWp6AAggkhzAyMjQzwEMdkFLPQYGs9NgDGKDxHQFGWqASviAmJUUMwECiImUhAf0mryUK1CLQi0wyYlBMJANEgMmSsktzgxVQKVcpJgLEEDMxCY8FmDcCwE9K+IdzsAgHg8U/Q/BbFIMbFzPGH4/u8rA+o5Bg4uFYdfx1wyviU2QAAFElAOy1RkmsHIymMuG8TIwa09kOH7qOcOWLacZzpy5w/Dnzz8GWTUrBg7WtQwfL/xil2JjEF50l2EHUNtPqCvxAoAAIuiA874MjszAuBezY2Lgcy5lePfHlGHv3gvA9MDIwMTExPD06RsGAWEZBjE5QYb/748w/H/CoKElwHBp+1OGO0DtfwiZDxBABOOKCWg5myADg5iXCgODUCDDjx9fwOKgIvzfv39g9ocPH8ByYl7KDCC1ZiIMtdAEyULIfIAAYiKQ8BKBCU9f0gdISuQA8x0bAxvbf7DlMAeAsLAwG1iOQTKDAaSWk5lBfZkdQwI0W+K1AyCAcEpe8mMQAPq+j1sZ6BVLO2BmNwaK/mAQEWFlYGb+D4z7P3AsIwNK+N/AavjMTRlAerT4GSr9ZBlkCWVLgADC6YB//xkagJSATDTQcNE4YCHwH+wAEJaX52X49esXGAsIsDKws/8Gin8HqgEmfLEYBpkoNlDU8WZpMFQAJbjxpTWAAGLCle2ABuSL2ANzmYI7kAB55CvEEiCWkmIFpoUfDD9//gSzIXIg/JmBgV2SgU3elgGkV4qTISZXg0EHKMGOq4QECCAmnOU9MPbE/IQZGPjdkCwA4S8MsrJMDN+/f2f49u0bg4oKG8Rihk9QDGQL2jOI+fIwgMyIVGToBQry4AoFgABiwlnehwJ1SDgD0zEvwmAw/sIgKPgTiP8zfP36lUFZ+T+SPIh+D9TDCdRrzgAyg1A9ARBALFjLe1mQJySAsWcCFHmHxa3/gAnvL8Pfv6Bs+AFa6IEwKC38gmR/bi0GQbvTDG/2f2LQ/QeuJzZCC6dfyPYBBBAzenkPjHt/uQxgNCh6AH0iBI33H1D8HZLagWxFRUYGbW0WBm7uH/CogdDfIGxGoF3MTAwcwo8ZPh9j4PWWYeBYdp/hMNQB8BISIICYkbMdMIBWCNmAyns5YJViADXsJzzxQfjfwRaxsX3HYjkyGxglLOwMbAJvGH6//sHA+pxB4/E3hjW3PzF8RC4hAQKICSnbTWDhYuAXCwZGE5cqNOjfQjEy+y3Dtm0PGdzdLzJYWJxjmD37Hg61HyCYS4JBLBhYGHAz8BZpMTSjZ0uAAGJGKe/9QIWOJFC1MFrQf0PCXxmSkl4wvH37A1wOHDv2kSEg4B8DHx9CHhFaQMz0D5gbfjH8B6r9f5tBQ0eA4eK2pwx3YaEAEEAs0PK+nk2UgUHYB5in2UA55g3Ubdhy6X9g9vsCzAH/gInwL7go/v//LzRa/4ITKAQjsdmBVaQPE8P7Q/8YDH4zFAEF90HTwm+AAGIGlfegQkcmF5hPlICWMzMi+fwHUkgg0oCg4C+GzZt/gYvh4ODfDOHhP+GJExMD5Rh/MTCx/mdgE/vH8P04g5S9OMPbNQ8ZLoAcABBAjBf9GB7w6DDIK7WAfMcPVMwCza7I+D+U/gcPBQT+h8ZmgPr+Pyr+DwmRe8AM+e4Sw3PTLQxmQIFXAAHEAmpmMQOTxderQCuYYMHGCC4QoCUDSvBD62I4+z88yJHF0S1HqAfZBWq+QVvRHwACiOXHX4ZpDCcZsj6dBFrFDAwyJma45YzIDkHqwv1HdggMg9QhWcQArbJRGkVQ5v0vDKuhCYwJIIBApnOU6TAYirAzaP76x8ACzI5kd7OIAVc/MDxb+YDhIaTMZngNEECMUJewQ8tqVkr6eUSC/9AyG5SqfwIEEHJEM5LbvyMDwFMuQAAxDnT3HCDAAN6sBt/v91SLAAAAAElFTkSuQmCC";
    },
    o3pi: function (t, e) {},
    oAf7: function (t, e) {},
    qb6w: function (t, e) {},
    rMyo: function (t, e) {
      t.exports = {
        data: [
          { title: "القسم الأول" },
          { title: "القسم الثاني" },
          { title: "القسم الثالث" },
          { title: "القسم الرابع" },
        ],
      };
    },
    toIH: function (t, e, i) {
      "use strict";
      var o = {
          name: "DragCol",
          props: {
            leftPercent: { type: Number, default: 50 },
            sliderWidth: { type: Number, default: 20 },
            width: { type: String, default: "400px" },
            height: { type: String, default: "400px" },
            sliderColor: { type: String, default: "#6f808d" },
            sliderBgColor: { type: String, default: "#1f2e3a" },
            sliderHoverColor: { type: String, default: "#6f808d" },
            sliderBgHoverColor: { type: String, default: "#16222a" },
          },
          data: function () {
            return { left: this.leftPercent, isDragging: !1 };
          },
          methods: {
            mobileDragCol: function (t) {
              (t = t || window.event).stopPropagation();
              var e = t.changedTouches[0].clientX,
                i = this.left,
                o = 0,
                s = 0,
                n = this.$refs.container.offsetWidth,
                a = this;
              (this.isDragging = !0),
                this.$emit("isDragging", this.isDragging),
                (document.ontouchmove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).stopPropagation(),
                    (o = t.changedTouches[0].clientX);
                  var r = parseFloat((((e - o) / n) * 100).toFixed(3));
                  (s = i - r) <= 0
                    ? (a.left = 0)
                    : (a.left = s >= 100 ? 100 : s);
                  a.$emit("dragging", a.left);
                }),
                (document.ontouchend = function () {
                  (a.isDragging = !1),
                    a.$emit("isDragging", a.isDragging),
                    (document.ontouchmove = null),
                    (document.ontouchend = null);
                });
            },
            dragCol: function (t) {
              (t = t || window.event).preventDefault(), t.stopPropagation();
              var e = t.clientX,
                i = this.left,
                o = 0,
                s = 0,
                n = this.$refs.container.offsetWidth,
                a = this;
              (this.isDragging = !0),
                this.$emit("isDragging", this.isDragging),
                (document.onmousemove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).preventDefault(),
                    t.stopPropagation(),
                    (o = t.clientX);
                  var r = parseFloat((((e - o) / n) * 100).toFixed(3));
                  (s = i - r) <= 0
                    ? (a.left = 0)
                    : (a.left = s >= 100 ? 100 : s);
                  a.$emit("dragging", a.left);
                }),
                (document.onmouseup = function () {
                  (a.isDragging = !1),
                    a.$emit("isDragging", a.isDragging),
                    (document.onmouseup = null),
                    (document.onmousemove = null);
                });
            },
          },
        },
        s = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              {
                ref: "container",
                staticClass: "drager_col",
                style: { width: t.width, height: t.height },
              },
              [
                i(
                  "div",
                  {
                    staticClass: "drager_left",
                    style: { width: t.left + "%" },
                  },
                  [i("div", [t._t("left")], 2)]
                ),
                t._v(" "),
                i("div", {
                  staticClass: "slider_col",
                  style: {
                    width: t.sliderWidth + "px",
                    marginLeft: -t.sliderWidth / 2 + "px",
                    marginRight: -t.sliderWidth / 2 + "px",
                  },
                  on: {
                    "&touchstart": function (e) {
                      return t.mobileDragCol.apply(null, arguments);
                    },
                    mousedown: t.dragCol,
                  },
                }),
                t._v(" "),
                i(
                  "div",
                  {
                    staticClass: "drager_right",
                    style: { width: 100 - t.left + "%" },
                  },
                  [i("div", [t._t("right")], 2)]
                ),
              ]
            );
          },
          staticRenderFns: [],
        };
      var n = i("VU/8")(
        o,
        s,
        !1,
        function (t) {
          i("Jyjj");
        },
        null,
        null
      );
      e.a = n.exports;
    },
    wKqJ: function (t, e, i) {
      "use strict";
      var o = {
          name: "ResizeRow",
          props: {
            sliderWidth: { type: Number, default: 20 },
            height: { type: Number, default: 400 },
            width: { type: String, default: "400px" },
            sliderColor: { type: String, default: "#6f808d" },
            sliderBgColor: { type: String, default: "#1f2e3a" },
            sliderHoverColor: { type: String, default: "#6f808d" },
            sliderBgHoverColor: { type: String, default: "#16222a" },
          },
          data: function () {
            return { reHeight: this.height, isDragging: !1 };
          },
          methods: {
            mobileResizeRow: function (t) {
              (document.body.style.overflow = "hidden"),
                (document.body.style.overscrollBehaviorY = "contain"),
                (t = t || window.event).stopPropagation();
              var e = t.changedTouches[0].clientY,
                i = this.reHeight,
                o = 0,
                s = 0,
                n = this;
              (this.isDragging = !0),
                this.$emit("isDragging", this.isDragging),
                (document.ontouchmove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).stopPropagation(),
                    (o = t.changedTouches[0].clientY),
                    (s = parseInt(i - (e - o))) <= 20
                      ? (n.reHeight = 20)
                      : (n.reHeight = s);
                  n.$emit("dragging", n.reHeight);
                }),
                (document.ontouchend = function () {
                  (n.isDragging = !1),
                    n.$emit("isDragging", n.isDragging),
                    (document.body.style.overflow = ""),
                    (document.body.style.overscrollBehaviorY = ""),
                    (document.ontouchmove = null),
                    (document.ontouchend = null);
                });
            },
            resizeRow: function (t) {
              (t = t || window.event).preventDefault(), t.stopPropagation();
              var e = t.clientY,
                i = this.reHeight,
                o = 0,
                s = 0,
                n = this;
              (this.isDragging = !0),
                this.$emit("isDragging", this.isDragging),
                (document.onmousemove = function (t) {
                  if (this.time && Date.now() - this.time < 40) return;
                  (this.time = Date.now()),
                    (t = t || window.event).preventDefault(),
                    t.stopPropagation(),
                    (o = t.clientY),
                    (s = parseInt(i - (e - o))) <= 20
                      ? (n.reHeight = 20)
                      : (n.reHeight = s);
                  n.$emit("dragging", n.reHeight);
                }),
                (document.onmouseup = function () {
                  (n.isDragging = !1),
                    n.$emit("isDragging", n.isDragging),
                    (document.onmouseup = null),
                    (document.onmousemove = null);
                });
            },
          },
        },
        s = {
          render: function () {
            var t = this,
              e = t.$createElement,
              i = t._self._c || e;
            return i(
              "div",
              {
                staticClass: "resize_row",
                style: { height: t.reHeight + "px", width: t.width },
              },
              [
                i(
                  "div",
                  { staticClass: "resize_row_body" },
                  [t._t("default")],
                  2
                ),
                t._v(" "),
                i("div", {
                  staticClass: "slider_row",
                  style: { height: t.sliderWidth + "px" },
                  on: {
                    "&touchstart": function (e) {
                      return t.mobileResizeRow.apply(null, arguments);
                    },
                    mousedown: t.resizeRow,
                  },
                }),
              ]
            );
          },
          staticRenderFns: [],
        };
      var n = i("VU/8")(
        o,
        s,
        !1,
        function (t) {
          i("Vz2c");
        },
        null,
        null
      );
      e.a = n.exports;
    },
    xfsg: function (t, e) {},
  },
  ["NHnr"]
);
//# sourceMappingURL=app.3d73bc84128f51e61ad4.js.map
