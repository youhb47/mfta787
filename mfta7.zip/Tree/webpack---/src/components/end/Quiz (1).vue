var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"heyisnone"},[_c('div',{staticClass:"row m-0"},[_c('Header',{attrs:{"BooleanTimer":false,"BooleanNumQuiz":true,"BooleanTagSave":true}}),_vm._v(" "),_c('div',{staticClass:"col-12 p-0 position-relative"},[(_vm.$root.loader)?_c('Loader'):_vm._e(),_vm._v(" "),_c('Single')],1),_vm._v(" "),_c('Footer',{attrs:{"HerePage":"quiz","BooleanNext":true,"BooleanAfter":true}})],1)])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-63411e96","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/end/Quiz.vue
// module id = null
// module chunks = 