var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"heyisnone"},[_c('div',{staticClass:"row m-0"},[_c('Header',{attrs:{"BooleanTimer":true,"BooleanNumQuiz":false,"BooleanTagSave":false}})],1),_vm._v(" "),_c('div',{staticClass:"col-12 p-0 text-end px-4 pt-3 bodybody"},[_c('p',[_vm._v("\n      "+_vm._s(_vm.json[_vm.$root.quiz_revision-1].title)+"\n    ")]),_vm._v(" "),_c('p',[_vm._v("عدد الأسئلة : "+_vm._s(_vm.$root.total[_vm.$root.quiz_revision-1])+" سؤال")]),_vm._v(" "),_c('p',[_vm._v("\n      الزمن الكلي للقسم :\n      "+_vm._s(((_vm.$root.total[_vm.$root.quiz_revision-1] * _vm.$root.seconds) / 60).toFixed(0))+" دقيقة\n    ")])]),_vm._v(" "),_c('Footer',{attrs:{"HerePage":"separation","BooleanNext":true,"BooleanAfter":false}})],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-87fabea2","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/Separation.vue
// module id = null
// module chunks = 