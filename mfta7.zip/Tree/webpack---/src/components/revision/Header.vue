<template>
    <div class="m-0 p-0">
        <div class="
            col-12
            header
            d-flex
            flex-column flex-md-row flex-lg-row flex-xl-row
            py-3
            px-2
            justify-content-between
            align-items-center
            bg-DarkBlueOldColor
            p-1
            ">
            <div class="col-md-6 col-lg-6 col-12 text-end fontsizequiz">
            <strong class="m-0 increase_font">إختبار أكاديمية الحوت على الحاسب الآلي</strong>
            أحمد إبراهيم عادل
            </div>
            <div class="
                mt-2 mt-md-0 mt-lg-0 mt-xl-0
                d-flex
                flex-column
                align-items-start
                align-items-md-end
                align-items-lg-end
                align-items-xl-end
                col-md-6 col-lg-6 col-12
            ">
                <p id="clock" class="textquiz m-0 f-12 text-white" v-if="BooleanTimer"
                @click="FunNumQuiz('p#clock')">
                    <i class="fa-regular fa-clock"></i>
                    الوقت المتبقي 
                    <b v-html="$root.timer"></b>
                </p>
                <div>
                    <p id="quiznumbers" class="textquiz m-0 f-12 mt-1" v-if="BooleanNumQuiz"
                    @click="FunNumQuiz('p#quiznumbers')">
                        <i class="fa-solid fa-scroll"></i>
                        <span>{{ number_page }}</span>
                        من
                        <span>
                            {{ feak_total }}
                        </span>
                    </p>
                </div>
            </div>
        </div>
    
        <div class="
            col-12
            downTag
            align-items-center
            justify-content-start
            justify-content-md-end
            justify-content-lg-end
            justify-content-xl-end
            bg-BlueOldColor
            py-2
            px-4
            ">
            <div v-if="BooleanTagSave">
                <button type="button" class="btn cursor_pointer text-white m-0 px-3 fontsizequiz" @click="funSave">
                <img :src="tag()" alt="img" class="clock_img" />
                تميز السؤال للمراجعة
                </button>
                <select v-model="xselected" class="d-inline-block form-select form-select-sm rounded-0 w-auto" 
                style="background-color: #588cc5; color: white;">
                    <option>
                        تغيير حجم الخط
                    </option>
                    <option v-for="(i, v) of [18, 20, 24, 26]" :key="v" :value="i" :selected="xselected == i ? true : false">
                        {{ i }}
                    </option>
                </select>
            </div>
        </div>
    </div>
    </template>
    
    
    <script>
    import jQuery from 'jquery'
    import TgImage from "@/assets/icon/14.png";
    import TsImage from "@/assets/icon/15.png";
    
    export default {
        name: "Header",
        props: {
            BooleanTimer: Boolean,
            BooleanNumQuiz: Boolean,
            BooleanTagSave: Boolean,
        },
        data() {
            return {
                TgImage: TgImage,
                TsImage: TsImage,
                number_page : this.$root.quiz_number,
                feak_total: this.$root.faek_total,
                xselected: 18,
            };
        },
        methods: {
            async run () {
                // this.$root.appSave()
                this.number_page = this.$root.quiz_number
                this.xselected = this.$root.fontsizequiz
                this.arrSave()
            },
            funSave() {
            let ishere = true
            let np = this.$root.faek_num
            let arr = {id: np, tag: true};
            let tags;
            let rev = this.$root.quiz_revision
            if (rev == 1) {
                tags = this.$root.quiz_tags.a
            } else if (rev == 2) {
                tags = this.$root.quiz_tags.b
            } else if (rev == 3) {
                tags = this.$root.quiz_tags.c
            } else if (rev == 4) {
                tags = this.$root.quiz_tags.d
            }
    
            for (let key = 0; key < tags.length; key++) {
                if (tags[key].id == np) {
                    if (tags[key].tag) {
                        tags[key].tag = false
                    } else {
                        tags[key].tag = true
                    }
                    ishere = false
                    break;
                }
            }
    
            if (ishere) {
                tags.push(arr);
            }
            
            if (rev == 1) {
                this.$root.quiz_tags.a = tags
            } else if (rev == 2) {
                this.$root.quiz_tags.b = tags
            } else if (rev == 3) {
                this.$root.quiz_tags.c = tags
            } else if (rev == 4) {
                this.$root.quiz_tags.d = tags
            }
            this.arrSave()
            },
            tag() {
                let np = this.$root.faek_num
                let tags;
                let rev = this.$root.quiz_revision
                if (rev == 1) {
                    tags = this.$root.quiz_tags.a
                } else if (rev == 2) {
                    tags = this.$root.quiz_tags.b
                } else if (rev == 3) {
                    tags = this.$root.quiz_tags.c
                } else if (rev == 4) {
                    tags = this.$root.quiz_tags.d
                }
                for (let key = 0; key < tags.length; key++) {
                    if(tags[key].id == np) {
                        if (tags[key].tag) {
                            return TgImage
                        }
                    }
                }
                return TsImage
            },
        arrSave() {
        let rev = this.$root.quiz_revision
        let tags, arr = [];
        if (rev == 1) {
            tags = this.$root.quiz_tags.a
        } else if (rev == 2) {
            tags = this.$root.quiz_tags.b
        } else if (rev == 3) {
            tags = this.$root.quiz_tags.c
        } else if (rev == 4) {
            tags = this.$root.quiz_tags.d
        }

        for (let key = 0; key < tags.length; key++) {
            if (tags[key].tag) {
                arr.push(tags[key])
            }
        }
        arr = arr
        if (rev == 1) {
            this.$root.quiz_tags.a = arr
        } else if (rev == 2) {
            this.$root.quiz_tags.b = arr
        } else if (rev == 3) {
            this.$root.quiz_tags.c = arr
        } else if (rev == 4) {
            this.$root.quiz_tags.d = arr
        }
        this.$root.updateSave()
        },
        FunNumQuiz(event) {
            let elemant = jQuery(event)
            elemant.toggleClass('active')
        },
        vselected() {
            this.$root.fontsizequiz = this.xselected
            jQuery('style#one').html('.fontsizequiz {font-size: ' + this.xselected + 'px!important;}');
            this.$root.updateSave()
        },
        checkselected() {
            this.xselected = this.$root.fontsizequiz
        }
        },
        mounted() {
            this.tag()
        },
        watch: {
            'xselected': 'vselected',
            '$root.fontsizequiz': 'checkselected',
            '$root.quiz_number': function(){
                this.run()
                this.tag()
                this.vselected()
            }
        }
    };
    </script>


// WEBPACK FOOTER //
// src/components/revision/Header.vue