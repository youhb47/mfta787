<template>
  <div class="heyisnone">
    <div class="row m-0">
      <!-- b header -->
      <Header
        :BooleanTimer="true"
        :BooleanNumQuiz="false"
        :BooleanTagSave="false"
      />
      <!-- e header -->
    </div>

    <div class="col-12 p-0 text-end px-4 pt-3 bodybody">
      <!--  -->
      <p>
        {{ json[$root.quiz_revision-1].title }}
      </p>
      <p>عدد الأسئلة : {{ $root.total[$root.quiz_revision-1] }} سؤال</p>
      <p>
        الزمن الكلي للقسم :
        {{ (($root.total[$root.quiz_revision-1] * $root.seconds) / 60).toFixed(0) }} دقيقة
      </p>
    </div>

    <Footer HerePage="separation" :BooleanNext="true" :BooleanAfter="false" />
  </div>
</template>
  
<script>
import xtimer from "../xtimer";
import json from "./../assets/revision.json";
import Header from "./aps/Header";
import Footer from "./aps/Footer";

export default {
  name: "Quiz",
  components: {
    Header,
    Footer,
  },
  data() {
    return {
      json: json.data,
      minute  : this.$root.sapa_time.minute,
      seconds : this.$root.sapa_time.seconds,
      timer   : this.$root.timer
    };
  },
  methods: {
    run() {
      xtimer.xstart(this);
      this.$root.pops = true
    },
  },
  mounted() {
    this.run();
  },
  watch: {
    'timer': function() { 
        this.$root.timer = this.timer
        if (this.timer == '00:00') {
            let vbt;
            let qr = this.$root.quiz_viwe;
            if(qr[0] == 0) {
                this.$root.quiz_revision = 1
                vbt = 1
                this.$root.quiz_viwe[0] = 1
                this.$root.quiz_total = this.$root.total[vbt-1]
                this.$root.updateSave()
            } else if(qr[0] == 1 && qr[1] == 0) {
                this.$root.quiz_revision = 2
                vbt = 2
                this.$root.quiz_viwe[1] = 1
                this.$root.quiz_total = this.$root.total[vbt-1]
                this.$root.updateSave()
            } else if(qr[1] == 1 && qr[2] == 0) {
                this.$root.quiz_revision = 3
                vbt = 3
                this.$root.quiz_viwe[2] = 1
                this.$root.quiz_total = this.$root.total[vbt-1]
                this.$root.updateSave()
            } else if(qr[2] == 1 && qr[3] == 0) {
                this.$root.quiz_revision = 4
                vbt = 4
                this.$root.quiz_viwe[3] = 1
                this.$root.quiz_total = this.$root.total[vbt-1]
                this.$root.updateSave()
            }
            this.$root.timer = this.$root.loadtimer
            this.$root.quiz_faek = "quiz"
            this.$root.faek_time.minute  = this.$root.quiz_time.minute
            this.$root.faek_time.seconds = this.$root.quiz_time.minute
            this.$root.quiz_number = (this.$root.quiz_number + 1)
            this.$root.addtimers = true
            this.$root.checkrefrsh = true
            this.$root.updateSave()
            this.$root.checkdate()
            this.$router.push('/quiz/' + this.$root.app_rand).catch(err => {})
            xtimer.xstop();
        }
    }
  }
};
</script>


// WEBPACK FOOTER //
// src/components/Separation.vue